﻿using Antlr4.Runtime;
using Antlr4.Runtime.Misc;
using Antlr4.Runtime.Tree;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace MiniLangCompiler
{
    public class VariableInfo
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public string InitValue { get; set; }
        public int Line { get; set; }
        public bool IsConst { get; set; }
        public bool IsGlobal { get; set; }
    }

    public class FunctionInfo
    {
        public string Name { get; set; }
        public string ReturnType { get; set; }
        public List<ParameterInfo> Parameters { get; set; } = new List<ParameterInfo>();
        public List<VariableInfo> LocalVariables { get; set; } = new List<VariableInfo>();
        public List<ControlStructure> ControlStructures { get; set; } = new List<ControlStructure>();
        public bool IsRecursive { get; set; }
        public bool IsMain { get; set; }
        public int Line { get; set; }
        public bool HasReturn { get; set; }
    }

    public class ParameterInfo
    {
        public string Type { get; set; }
        public string Name { get; set; }
    }

    public class ControlStructure
    {
        public string Type { get; set; }
        public int Line { get; set; }
    }
    public class SemanticAnalyzer : MiniLangBaseVisitor<object>
    {
        public List<VariableInfo> GlobalVariables { get; } = new List<VariableInfo>();
        public List<FunctionInfo> Functions { get; } = new List<FunctionInfo>();
        public List<string> Errors { get; } = new List<string>();

        private FunctionInfo currentFunction = null;
        private Dictionary<string, FunctionInfo> functionTable = new Dictionary<string, FunctionInfo>();
        private Dictionary<string, VariableInfo> globalVarTable = new Dictionary<string, VariableInfo>();
        private Dictionary<string, VariableInfo> localVarTable = new Dictionary<string, VariableInfo>();

        public override object VisitProgram([NotNull] MiniLangParser.ProgramContext context)
        {

            foreach (var child in context.children)
            {
                if (child is MiniLangParser.GlobalDeclarationContext globalDecl)
                {
                    VisitGlobalDeclaration(globalDecl);
                }
                else if (child is MiniLangParser.FunctionDeclarationContext funcDecl)
                {
                    CollectFunctionSignature(funcDecl);
                }
            }

            var mainFunctions = Functions.Where(f => f.Name == "main").ToList();
            if (mainFunctions.Count == 0)
                Errors.Add("Eroare semantica: Programul trebuie sa contina o functie 'main'.");
            else if (mainFunctions.Count > 1)
                Errors.Add("Eroare semantica: Unicitate main incalcata - exista mai multe functii 'main'.");

            foreach (var child in context.children)
            {
                if (child is MiniLangParser.FunctionDeclarationContext funcDecl)
                {
                    VisitFunctionDeclaration(funcDecl);
                }
            }

            return null;
        }

        private void CollectFunctionSignature(MiniLangParser.FunctionDeclarationContext context)
        {
            var funcInfo = new FunctionInfo
            {
                Name = context.ID().GetText(),
                ReturnType = context.type().GetText(),
                Line = context.Start.Line,
                IsMain = context.ID().GetText() == "main"
            };

            if (context.parameterList() != null)
            {
                foreach (var param in context.parameterList().parameter())
                {
                    funcInfo.Parameters.Add(new ParameterInfo
                    {
                        Type = param.type().GetText(),
                        Name = param.ID().GetText()
                    });
                }
            }

            string signature = GetFunctionSignature(funcInfo);
            if (functionTable.ContainsKey(signature))
                Errors.Add("Eroare semantica, linia {funcInfo.Line}: Functia '{funcInfo.Name}' cu aceiasi parametri este deja definita.");
            else
            {
                functionTable[signature] = funcInfo;
                Functions.Add(funcInfo);
            }
        }

        public override object VisitFunctionDeclaration([NotNull] MiniLangParser.FunctionDeclarationContext context)
        {
            string funcName = context.ID().GetText();
            currentFunction = Functions.FirstOrDefault(f => f.Name == funcName && f.Line == context.Start.Line);
            if (currentFunction == null) return null;

            localVarTable.Clear();
            foreach (var param in currentFunction.Parameters)
                localVarTable[param.Name] = new VariableInfo { Name = param.Name, Type = param.Type, IsGlobal = false };

            VisitFunctionBody(context.functionBody());

            if (currentFunction.ReturnType != "void" && !currentFunction.HasReturn)
                Errors.Add("Eroare semantica, linia {currentFunction.Line}: Functia '{currentFunction.Name}' ({currentFunction.ReturnType}) necesită 'return'.");

            currentFunction = null;
            return null;
        }

        private string GetExpressionType(MiniLangParser.ExpressionContext context) => GetAssignmentType(context.assignmentExpression());

        private string GetAssignmentType(MiniLangParser.AssignmentExpressionContext context)
        {
            if (context.assignmentOperator() != null) return GetLogicalOrType(context.logicalOrExpression());
            return GetLogicalOrType(context.logicalOrExpression());
        }

        private string GetLogicalOrType(MiniLangParser.LogicalOrExpressionContext context) =>
            context.logicalAndExpression().Length > 1 ? "int" : GetLogicalAndType(context.logicalAndExpression(0));

        private string GetLogicalAndType(MiniLangParser.LogicalAndExpressionContext context) =>
            context.equalityExpression().Length > 1 ? "int" : GetEqualityType(context.equalityExpression(0));

        private string GetEqualityType(MiniLangParser.EqualityExpressionContext context) =>
            context.relationalExpression().Length > 1 ? "int" : GetRelationalType(context.relationalExpression(0));

        private string GetRelationalType(MiniLangParser.RelationalExpressionContext context) =>
            context.additiveExpression().Length > 1 ? "int" : GetAdditiveType(context.additiveExpression(0));

        private string GetAdditiveType(MiniLangParser.AdditiveExpressionContext context)
        {
            var types = context.multiplicativeExpression().Select(GetMultiplicativeType).ToList();
            if (types.Contains("double")) return "double";
            if (types.Contains("float")) return "float";
            if (types.Contains("string")) return "string";
            return "int";
        }

        private string GetMultiplicativeType(MiniLangParser.MultiplicativeExpressionContext context)
        {
            var types = context.unaryExpression().Select(GetUnaryType).ToList();
            if (types.Contains("double")) return "double";
            if (types.Contains("float")) return "float";
            return "int";
        }

        private string GetUnaryType(MiniLangParser.UnaryExpressionContext context) =>
            context.postfixExpression() != null ? GetPostfixType(context.postfixExpression()) : GetUnaryType(context.unaryExpression());

        private string GetPostfixType(MiniLangParser.PostfixExpressionContext context) => GetPrimaryType(context.primaryExpression());

        private string GetPrimaryType(MiniLangParser.PrimaryExpressionContext context)
        {
            if (context.ID() != null) return GetVariableInfo(context.ID().GetText())?.Type ?? "unknown";
            if (context.literal() != null)
            {
                var lit = context.literal();
                if (lit.NUMBER() != null) return "int";
                if (lit.FLOAT_NUMBER() != null) return "double";
                if (lit.STRING_LITERAL() != null) return "string";
            }
            if (context.functionCall() != null)
            {
                var fName = context.functionCall().ID().GetText();
                return Functions.FirstOrDefault(f => f.Name == fName)?.ReturnType ?? "unknown";
            }
            if (context.expression() != null) return GetExpressionType(context.expression());
            return "unknown";
        }

        private bool AreCompatible(string expected, string actual)
        {
            if (expected == actual) return true;
            if (expected == "double" && (actual == "int" || actual == "float")) return true;
            if (expected == "float" && actual == "int") return true;
            return false;
        }

        public override object VisitFunctionCall([NotNull] MiniLangParser.FunctionCallContext context)
        {
            string name = context.ID().GetText();
            var args = context.argumentList()?.expression();
            int argCount = args?.Length ?? 0;

            var targetFunc = Functions.FirstOrDefault(f => f.Name == name);
            if (targetFunc == null)
            {
                Errors.Add($"Eroare semantica, linia {context.Start.Line}: Functia '{name}' nu este definita.");
                return null;
            }

            if (name == "main") Errors.Add($"Eroare semantica, linia {context.Start.Line}: Functia 'main' nu poate fi apelata (recursivitate interzisa).");
            if (currentFunction != null && name == currentFunction.Name) currentFunction.IsRecursive = true;

            if (argCount != targetFunc.Parameters.Count)
            {
                Errors.Add($"Eroare semantica, linia {context.Start.Line}: Functia '{name}' asteapta {targetFunc.Parameters.Count} argumente, nu {argCount}.");
            }
            else if (args != null)
            {
                for (int i = 0; i < argCount; i++)
                {
                    string actType = GetExpressionType(args[i]);
                    string expType = targetFunc.Parameters[i].Type;
                    if (!AreCompatible(expType, actType))
                        Errors.Add($"Eroare semantica, linia {context.Start.Line}: Argumentul {i + 1} tip invalid. Asteptat: {expType}, Primit: {actType}.");
                }
            }
            return null;
        }

        public override object VisitAssignmentExpression([NotNull] MiniLangParser.AssignmentExpressionContext context)
        {
            if (context.assignmentOperator() != null)
            {
                string varName = ExtractIdentifier(context.logicalOrExpression());
                if (varName != null)
                {
                    var info = GetVariableInfo(varName);
                    if (info == null) Errors.Add($"Eroare semantica, linia {context.Start.Line}: Variabila '{varName}' nedeclarata.");
                    else if (info.IsConst) Errors.Add($"Eroare semantica, linia {context.Start.Line}: Atribuire interzisa la constanta '{varName}'.");
                    else
                    {
                        string exprType = GetAssignmentType(context.assignmentExpression());
                        if (!AreCompatible(info.Type, exprType))
                            Errors.Add($"Eroare semantica, linia {context.Start.Line}: Incompatibilitate tip la atribuire ('{info.Type}' <- '{exprType}').");
                    }
                }
            }
            return base.VisitAssignmentExpression(context);
        }

        public override object VisitReturnStatement([NotNull] MiniLangParser.ReturnStatementContext context)
        {
            if (currentFunction != null)
            {
                currentFunction.HasReturn = true;
                string retType = context.expression() != null ? GetExpressionType(context.expression()) : "void";
                if (!AreCompatible(currentFunction.ReturnType, retType))
                    Errors.Add($"Eroare semantica, linia {context.Start.Line}: Return invalid. Functia returneaza {currentFunction.ReturnType}, nu {retType}.");
            }
            return base.VisitReturnStatement(context);
        }

        private VariableInfo GetVariableInfo(string name) => localVarTable.ContainsKey(name) ? localVarTable[name] : (globalVarTable.ContainsKey(name) ? globalVarTable[name] : null);
        private string GetFunctionSignature(FunctionInfo f) => $"{f.Name}({string.Join(",", f.Parameters.Select(p => p.Type))})";

        private VariableInfo ExtractVariableInfo(MiniLangParser.VariableDeclarationContext ctx, bool global) => new VariableInfo
        {
            Name = ctx.ID().GetText(),
            Type = ctx.type().GetText(),
            Line = ctx.Start.Line,
            IsConst = ctx.CONST() != null,
            IsGlobal = global,
            InitValue = ctx.expression()?.GetText()
        };

        public override object VisitVariableDeclaration([NotNull] MiniLangParser.VariableDeclarationContext context)
        {
            bool isGlobal = currentFunction == null;
            var info = ExtractVariableInfo(context, isGlobal);

            var table = isGlobal ? globalVarTable : localVarTable;
            if (table.ContainsKey(info.Name))
            {
                Errors.Add($"Eroare semantica, linia {info.Line}: Variabila '{info.Name}' duplicata.");
            }
            else
            {
                table[info.Name] = info;
                if (isGlobal) GlobalVariables.Add(info); else currentFunction.LocalVariables.Add(info);
            }

            if (info.InitValue != null)
            {
                string valType = GetExpressionType(context.expression());
                if (!AreCompatible(info.Type, valType))
                    Errors.Add($"Eroare semantica, linia {info.Line}: Tip incompatibil la initializare: {info.Type} vs {valType}.");
            }
            return null;
        }

        public override object VisitIfStatement(MiniLangParser.IfStatementContext context)
        {
            currentFunction?.ControlStructures.Add(new ControlStructure { Type = context.ELSE() != null ? "if-else" : "if", Line = context.Start.Line });
            return base.VisitIfStatement(context);
        }
        public override object VisitWhileStatement(MiniLangParser.WhileStatementContext context)
        {
            currentFunction?.ControlStructures.Add(new ControlStructure { Type = "while", Line = context.Start.Line });
            return base.VisitWhileStatement(context);
        }
        public override object VisitForStatement(MiniLangParser.ForStatementContext context)
        {
            currentFunction?.ControlStructures.Add(new ControlStructure { Type = "for", Line = context.Start.Line });
            return base.VisitForStatement(context);
        }

        private string ExtractIdentifier(ParserRuleContext ctx)
        {
            if (ctx is MiniLangParser.PrimaryExpressionContext p && p.ID() != null) return p.ID().GetText();
            foreach (var child in ctx.children ?? Enumerable.Empty<IParseTree>())
            {
                if (child is ParserRuleContext prc)
                {
                    var res = ExtractIdentifier(prc);
                    if (res != null) return res;
                }
            }
            return null;
        }
    }
}