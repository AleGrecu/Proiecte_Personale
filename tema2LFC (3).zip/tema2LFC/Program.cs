﻿using Antlr4.Runtime;
using Antlr4.Runtime.Tree;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MiniLangCompiler
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Mini-Limbaj Compiler ===\n");

            string inputFile;
            if (args.Length > 0)
            {
                inputFile = args[0];
            }
            else
            {
                Console.Write("Introdu calea catre fisierul sursa: ");
                inputFile = Console.ReadLine();
            }

            if (!File.Exists(inputFile))
            {
                Console.WriteLine($"Eroare: Fisierul '{inputFile}' nu exista!");
                return;
            }

            try
            {
                string sourceCode = File.ReadAllText(inputFile);
                Console.WriteLine($"Fisier citit: {inputFile}\n");

                var inputStream = new AntlrInputStream(sourceCode);

                var lexer = new MiniLangLexer(inputStream);

                var lexerErrorListener = new LexerErrorListener();
                lexer.RemoveErrorListeners();
                lexer.AddErrorListener(lexerErrorListener);

                var tokenStream = new CommonTokenStream(lexer);
                tokenStream.Fill();

                SaveTokenList(tokenStream, "tokens.txt");
                Console.WriteLine("Lista de unitati lexicale salvata in 'tokens.txt'");

                var parser = new MiniLangParser(tokenStream);

                var parserErrorListener = new CustomErrorListener();
                parser.RemoveErrorListeners();
                parser.AddErrorListener(parserErrorListener);

                var tree = parser.program();

                var allErrors = new List<string>();
                allErrors.AddRange(lexerErrorListener.Errors);
                allErrors.AddRange(parserErrorListener.Errors);

                if (allErrors.Count > 0)
                {
                    Console.WriteLine("\n Erori detectate la nivel lexical/sintactic:");
                    SaveErrors(allErrors, "errors.txt");
                    Console.WriteLine("Erori salvate în 'errors.txt'\n");

                    foreach (var error in allErrors)
                    {
                        Console.WriteLine($"  - {error}");
                    }
                    return;
                }

                var analyzer = new SemanticAnalyzer();
                analyzer.Visit(tree);

                if (analyzer.Errors.Count > 0)
                {
                    Console.WriteLine("\n Erori semantice detectate:");
                    SaveErrors(analyzer.Errors, "errors.txt");
                    Console.WriteLine("Erori salvate in 'errors.txt'\n");

                    foreach (var error in analyzer.Errors)
                    {
                        Console.WriteLine($"  - {error}");
                    }
                }
                else
                {
                    Console.WriteLine("Nu au fost detectate erori semantice!");
                }

                SaveGlobalVariables(analyzer.GlobalVariables, "global_variables.txt");
                Console.WriteLine("Lista de variabile globale salvata în 'global_variables.txt'");

                SaveFunctions(analyzer.Functions, "functions.txt");
                Console.WriteLine("Lista de functii salvata in 'functions.txt'");

                Console.WriteLine("\n=== Compilare finalizata cu succes! ===");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\nEroare neasteptata: {ex.Message}");
                Console.WriteLine(ex.StackTrace);
            }

            Console.WriteLine("\nApasa orice tasta pentru a inchide...");
            Console.ReadKey();
        }

        static void SaveTokenList(CommonTokenStream tokenStream, string filename)
        {
            using (var writer = new StreamWriter(filename))
            {
                writer.WriteLine("=== LISTA DE UNITĂȚI LEXICALE ===\n");
                writer.WriteLine($"{"Token",-20} {"Lexema",-30} {"Linie",-10}");
                writer.WriteLine(new string('-', 60));

                foreach (var token in tokenStream.GetTokens())
                {
                    if (token.Type == TokenConstants.EOF) break;

                    string tokenName = MiniLangLexer.DefaultVocabulary.GetSymbolicName(token.Type) ?? "UNKNOWN";
                    string lexeme = token.Text.Replace("\n", "\\n").Replace("\r", "\\r").Replace("\t", "\\t");

                    if (lexeme.Length > 28)
                        lexeme = lexeme.Substring(0, 25) + "...";

                    writer.WriteLine($"{tokenName,-20} {lexeme,-30} {token.Line,-10}");
                }
            }
        }

        static void SaveGlobalVariables(List<VariableInfo> variables, string filename)
        {
            using (var writer = new StreamWriter(filename))
            {
                writer.WriteLine("=== LISTA DE VARIABILE GLOBALE ===\n");

                if (variables.Count == 0)
                {
                    writer.WriteLine("Nu exista variabile globale declarate.");
                    return;
                }

                writer.WriteLine($"{"Nume",-20} {"Tip",-15} {"Constanta",-12} {"Valoare Initiala",-20} {"Linie",-10}");
                writer.WriteLine(new string('-', 80));

                foreach (var variable in variables)
                {
                    string constFlag = variable.IsConst ? "DA" : "NU";
                    string initValue = variable.InitValue ?? "N/A";

                    writer.WriteLine($"{variable.Name,-20} {variable.Type,-15} {constFlag,-12} {initValue,-20} {variable.Line,-10}");
                }
            }
        }

        static void SaveFunctions(List<FunctionInfo> functions, string filename)
        {
            using (var writer = new StreamWriter(filename))
            {
                writer.WriteLine("=== LISTA DE FUNCȚII ===\n");

                if (functions.Count == 0)
                {
                    writer.WriteLine("Nu exista functii declarate.");
                    return;
                }

                foreach (var func in functions)
                {
                    writer.WriteLine(new string('=', 80));
                    writer.WriteLine($"Funcție: {func.Name}");
                    writer.WriteLine(new string('=', 80));

                    writer.WriteLine($"Tip returnat:     {func.ReturnType}");
                    writer.WriteLine($"Tip functie:      {(func.IsMain ? "main" : "non-main")}, {(func.IsRecursive ? "recursiva" : "iterativa")}");
                    writer.WriteLine($"Linie declarare:  {func.Line}");

                    writer.WriteLine($"\nParametri: ({func.Parameters.Count})");
                    if (func.Parameters.Count > 0)
                    {
                        writer.WriteLine($"  {"Tip",-15} {"Nume",-20}");
                        writer.WriteLine($"  {new string('-', 35)}");
                        foreach (var param in func.Parameters)
                        {
                            writer.WriteLine($"  {param.Type,-15} {param.Name,-20}");
                        }
                    }
                    else
                    {
                        writer.WriteLine("  (fara parametri)");
                    }

                    writer.WriteLine($"\nVariabile locale: ({func.LocalVariables.Count})");
                    if (func.LocalVariables.Count > 0)
                    {
                        writer.WriteLine($"  {"Nume",-20} {"Tip",-15} {"Const",-8} {"Valoare Inițiala",-20}");
                        writer.WriteLine($"  {new string('-', 65)}");
                        foreach (var localVar in func.LocalVariables)
                        {
                            string constFlag = localVar.IsConst ? "DA" : "NU";
                            string initValue = localVar.InitValue ?? "N/A";
                            writer.WriteLine($"  {localVar.Name,-20} {localVar.Type,-15} {constFlag,-8} {initValue,-20}");
                        }
                    }
                    else
                    {
                        writer.WriteLine("  (fara variabile locale)");
                    }

                    writer.WriteLine($"\nStructuri de control: ({func.ControlStructures.Count})");
                    if (func.ControlStructures.Count > 0)
                    {
                        writer.WriteLine($"  {"Structura",-15} {"Linie",-10}");
                        writer.WriteLine($"  {new string('-', 25)}");
                        foreach (var ctrl in func.ControlStructures)
                        {
                            writer.WriteLine($"  {ctrl.Type,-15} {ctrl.Line,-10}");
                        }
                    }
                    else
                    {
                        writer.WriteLine("  (fara structuri de control)");
                    }

                    writer.WriteLine();
                }
            }
        }

        static void SaveErrors(List<string> errors, string filename)
        {
            using (var writer = new StreamWriter(filename))
            {
                writer.WriteLine("=== RAPORT DE ERORI ===\n");
                writer.WriteLine($"Total erori detectate: {errors.Count}\n");
                writer.WriteLine(new string('-', 80));

                int count = 1;
                foreach (var error in errors)
                {
                    writer.WriteLine($"{count}. {error}");
                    count++;
                }
            }
        }
    }
}