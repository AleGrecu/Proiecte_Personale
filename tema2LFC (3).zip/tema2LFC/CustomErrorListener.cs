﻿using Antlr4.Runtime;
using System;
using System.Collections.Generic;
using System.IO;

namespace MiniLangCompiler
{
    public class CustomErrorListener : BaseErrorListener, IAntlrErrorListener<IToken>
    {
        public List<string> Errors { get; } = new List<string>();

        public override void SyntaxError(TextWriter output, IRecognizer recognizer, IToken offendingSymbol,
            int line, int charPositionInLine, string msg, RecognitionException e)
        {
            if (offendingSymbol != null)
            {
                string tokenText = offendingSymbol.Text;

                if (tokenText.StartsWith("\"") && !tokenText.EndsWith("\""))
                {
                    Errors.Add("Eroare lexicala, linia {line}: String neinchis - '{tokenText}'");
                    return;
                }

                if (tokenText.StartsWith("/*") && !tokenText.EndsWith("*/"))
                {
                    Errors.Add("Eroare lexicala, linia {line}: Comentariu bloc neinchis - incepe cu '/*'");
                    return;
                }

                if (recognizer is MiniLangLexer lexer)
                {
                    if (offendingSymbol.Type == MiniLangLexer.INVALID_CHAR)
                    {
                        Errors.Add("Eroare lexicala, linia {line}: Caracter invalid - '{tokenText}'");
                        return;
                    }

                    if (offendingSymbol.Type == MiniLangLexer.UNCLOSED_STRING)
                    {
                        Errors.Add("Eroare lexicala, linia {line}: String care se intinde pe mai multe randuri");
                        return;
                    }

                    if (offendingSymbol.Type == MiniLangLexer.UNCLOSED_COMMENT)
                    {
                        Errors.Add("Eroare lexicala, linia {line}: Comentariu bloc neinchis pana la sfarsitul fisierului");
                        return;
                    }
                }
            }

            Errors.Add("Eroare sintactica, linia {line}:{charPositionInLine} - {msg}");
        }
    }

    public class LexerErrorListener : IAntlrErrorListener<int>
    {
        public List<string> Errors { get; } = new List<string>();

        public void SyntaxError(TextWriter output, IRecognizer recognizer, int offendingSymbol,
            int line, int charPositionInLine, string msg, RecognitionException e)
        {
            Errors.Add("Eroare lexicala, linia {line}:{charPositionInLine} - {msg}");
        }
    }
}