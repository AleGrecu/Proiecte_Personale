﻿import board;
import layout;
import <utility>;
import <stdexcept>;
import <string>;

void Board::setAge(Age a) {
	current = a;
}

std::vector<std::pair<const Card*, int>> Board::availableBoardCards() const
{
	std::vector<std::pair<const Card*, int>>result;
	auto indexes = layout.visibleIndexes();
	for (int idx : indexes) {
		if (idx >= 0 && static_cast<size_t>(idx) < layout.nodes.size()) {
			result.emplace_back(&layout.nodes[idx].card, idx);
		}
	}
	return result;

}

std::vector<Card> Board::visible() const {
	return layout.visibleCards();
}


bool Board::takeCard(int visibleIdx)
{
	const auto idxs = layout.visibleIndexes();
	const std::size_t size = idxs.size();

	if (visibleIdx < 0 || static_cast<std::size_t>(visibleIdx) >= size) {
		throw std::out_of_range("Visible card index " + std::to_string(visibleIdx) +
			" is out of range [0, " + std::to_string(size > 0 ? size - 1 : 0) + "]");
	}

	return layout.takeAtIndex(idxs[visibleIdx]);
}

bool Board::finishedAge() const {
	return layout.empty();
}

int Board::getCurrentAge() const {
	return static_cast<int>(current);
}