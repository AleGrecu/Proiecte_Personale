module card;

import <sstream>;
import <string>;
import <map>;
import <algorithm>;
import <vector>;

static std::string resourceToString(Resources r) {
	switch (r) {
	case Resources::Wood: return "Wood";
	case Resources::Stone: return "Stone";
	case Resources::Clay: return "Clay";
	case Resources::Glass: return "Glass";
	case Resources::Papyrus: return "Papyrus";
	default: return "Unknown";
	}
}

std::string Cost::toString() const {
	std::ostringstream ss;
	bool first = true;

	for (auto& [r, q] : resources) {
		if (!first) ss << ", ";
		ss << q << "x" << resourceToString(r) << " ";
		first = false;
	}

	if (coins > 0) {
		if (!first) ss << " + ";
		ss << coins << " coins ";
	}

	if (resources.empty() && coins == 0)
		ss << "Free";

	return ss.str();
}

static std::string effectToString(CardEffect e) {
	switch (e) {
	case CardEffect::ProduceResource: return "Produce Resource";
	case CardEffect::ProduceFlexible: return "Produce Multiple Resources";
	case CardEffect::Shields: return "Shields";
	case CardEffect::ScienceSymbol: return "Science Symbol";
	case CardEffect::Points: return "Points";
	case CardEffect::DiscountTrade: return "Discount Trade";

		//guild cards
	case CardEffect::GuildVPWonders: return "Guild VP: Max Wonders (2VP/W)";
	case CardEffect::GuildVPCoinSets: return "Guild VP: Max Coins (1VP/3C )";
	case CardEffect::GuildVPYellow: return "Guild VP: Max Yellow (+Coins/VP)";
	case CardEffect::GuildVPBrownGrey: return "Guild VP: Max Brown/Grey (+Coins/VP)";
	case CardEffect::GuildVPBlue: return "Guild VP: Max Blue (+Coins/VP)";
	case CardEffect::GuildVPGreen: return "Guild VP: Max Green (+Coins/VP)";
	case CardEffect::GuildVPRed: return "Guild VP: Max Red (+Coins/VP)";
	default: return "None";
	}
}

static std::string colorToString(CardColor c) {
	switch (c) {
	case CardColor::Brown: return "Brown";
	case CardColor::Grey: return "Grey";
	case CardColor::Blue: return "Blue";
	case CardColor::Yellow: return "Yellow";
	case CardColor::Red: return "Red";
	case CardColor::Green: return "Green";
	case CardColor::Purple: return "Purple";
	default: return "Unknown";
	}
}

std::string Card::info() const
{
	std::stringstream ss;

	ss << "[" << name << "] "
		<< "(" << colorToString(color) << ")\n"
		<< "Cost: " << cost.toString() << "\n"
		<< "Effect: " << effectToString(effect);

	if (shields > 0)
		ss << " Shields: " << shields;

	if (scienceSymbol != ScienceSymbol::None)
		ss << " Science: " << scienceSymbolToString(scienceSymbol);

	if (points > 0)
		ss << " Points: " << points;


	if (!producesResources.empty()) {
		ss << " | Produces: ";
		bool first = true;
		for (auto const& r : producesResources) {
			if (!first) ss << ", ";
			ss << resourceToString(r);
			first = false;
		}
	}

	if (!chainFrom.empty()) {
		ss << " | ChainFrom: " << chainFrom;
	}
	if (!chainTo.empty()) {
		ss << " | ChainTo: " << chainTo;
	}

	return ss.str();
}