﻿module rules;

import <algorithm>;
import <cmath>;
import <numeric>;
import <iostream>;
import <string>;
import <sstream>;
import <random>;

import card;
import player;
import wonder;
import progress;
import game_enums;
import board;

namespace Bank {
	bool payToBank(int amount, Player& player, bool allowPartial) {
		if (amount < 0) return false;

		int actualPayment = std::min(amount, player.getCoins());

		if (actualPayment > 0) {
			if (player.payCoins(actualPayment).has_value()) {
				std::cout << "[Bank]Payment: " << actualPayment << " coins paid by " << player.getName() << " to Bank";

				if (actualPayment < amount) {
					std::cout << " (required " << amount << ", but only had " << actualPayment << ")";

					if (!allowPartial) {
						std::cout << ".\n";
						return false;
					}
				}
				std::cout << ".\n";
				return true;
			}
		}
		else {
			std::cout << "[Bank] " << player.getName() << " has no coins to pay.\n";
		}
		return (amount == 0) || (allowPartial && actualPayment > 0);
	}

	bool payFromBank(int amount, Player& player) {
		if (amount < 0) return false;
		if (!player.earnCoins(amount)) return false;
		std::cout << "[Bank] Payment: " << amount << " coins received by "
			<< player.getName() << " from Bank.\n";
		return true;
	}
}

MilitaryTrack::MilitaryTrack() : position_(STARTING_POSITION) {
	std::cout << "[Military Track] Initialized at position " << position_ << "\n";
}

int MilitaryTrack::calculateZone(int pos) const noexcept {
	int absPos = std::abs(pos);

	if (absPos == 0) return 0;
	if (absPos >= 1 && absPos <= 2) return 1;
	if (absPos >= 3 && absPos <= 5) return 2;
	if (absPos >= 6 && absPos <= 8) return 3;
	if (absPos == 9) return 9;

	return 0;
}

int MilitaryTrack::getZoneVictoryPoints(int zone) const noexcept {
	switch (zone) {
	case 1: return 2;
	case 2: return 5;
	case 3: return 10;
	case 9: return 0;
	default: return 0;
	}
}

void MilitaryTrack::applyZoneBenefits(PlayerSide player, int newZone, Player& self, Player& opponent) {
	if (newZone == 0) return;

	int& lastZone = (player == PlayerSide::Player1) ? lastZoneP1_ : lastZoneP2_;

	if (newZone <= lastZone) return;

	if (newZone == 2) {
		Bank::payToBank(2, opponent, true);
	}
	else if (newZone == 3) {
		Bank::payToBank(5, opponent, true);
	}

	lastZone = newZone;
}

void MilitaryTrack::addShield(PlayerSide player, int amount, Player& p1, Player& p2) {
	if (amount <= 0) return;

	int oldPosition = position_;
	int oldZone = getZone();

	if (player == PlayerSide::Player1) {
		position_ -= amount;
		if (position_ > MAX_POSITION)
			position_ = MAX_POSITION;
	}
	else {
		position_ += amount;
		if (position_ < MIN_POSITION)
			position_ = MIN_POSITION;
	}
	int newZone = getZone();

	std::cout << "[Military Track] "
		<< (player == PlayerSide::Player1 ? "Player 1" : "Player 2")
		<< " gained " << amount << " shield(s).\n"
		<< "Position: " << oldPosition << " - > " << position_ << "\n";

	if (player == PlayerSide::Player1 && position_ < 0) {
		applyZoneBenefits(player, newZone, p1, p2);
	}
	else if (player == PlayerSide::Player2 && position_ > 0) {
		applyZoneBenefits(player, newZone, p2, p1);
	}

	if (auto winner = checkMilitaryVictory()) {
		std::cout << "[Military Track] !!! MILITARY VICTORY ACHIEVED !!!\n";
	}
}

int MilitaryTrack::getPosition() const noexcept { return position_; }

int MilitaryTrack::getZone() const noexcept { return calculateZone(position_); }

int MilitaryTrack::getFinalMilitaryPoints(PlayerSide player) const noexcept {
	if (position_ == 0) return 0;

	int zone = getZone();

	if (player == PlayerSide::Player1 && position_ > 0) {
		return getZoneVictoryPoints(zone);
	}
	else if (player == PlayerSide::Player2 && position_ < 0) {
		return getZoneVictoryPoints(zone);
	}

	return 0;
}

std::optional<PlayerSide> MilitaryTrack::checkMilitaryVictory() const {
	if (position_ >= MAX_POSITION)
		return PlayerSide::Player1;
	if (position_ <= MIN_POSITION)
		return PlayerSide::Player2;
	return std::nullopt;
}

int getTradeCost(const Player& opponent, Resources resource, const Player& self) {

	for (const auto& c : self.getBuiltCards())
		if (c.effect == CardEffect::DiscountTrade)
			for (auto r : c.producesResources)
				if (r == resource)
					return 1;

	int opponentProductionCount = 0;

	for (const auto& c : opponent.getBuiltCards())
		if (c.color == CardColor::Brown || c.color == CardColor::Grey)
			for (auto r : c.producesResources)
				if (r == resource)
					opponentProductionCount++;

	return 2 + opponentProductionCount;
}

CostResult calculateResourceCost(const Player& self, const Player& opponent,
	std::map<Resources, int> needed, int baseCoinCost, CardColor cardColour,
	bool isWonder) {
	CostResult r{};
	int totalCoins = baseCoinCost;
	int tradeCoinsToOpponent = 0;

	for (auto& [res, qty] : needed) {
		int have = self.countResource(res);
		qty -= std::min(have, qty);
	}

	for (const auto& wonder : self.getWonders()) {
		if (!wonder.built) continue;

		for (size_t i = 0; i < wonder.effects.size(); i++) {
			if (wonder.effects[i] == WonderEffect::ProduceFlexible) {
				int flexSlots = wonder.effectValues[i];

				for (int slot = 0; slot < flexSlots; slot++) {
					std::vector<Resources> applicableResources;
					for (const auto& flexRes : wonder.flexibleProduction) {
						auto it = needed.find(flexRes);
						if (it != needed.end() && it->second > 0)
							applicableResources.push_back(flexRes);
					}

					if (applicableResources.empty()) break;

					Resources chosen;
					if (applicableResources.size() - 1)
						chosen = applicableResources[0];
					else {
						std::cout << "\n[Flexible Production] Choose which resource to produce:\n";
						for (size_t j = 0; j < applicableResources.size(); ++j)
							std::cout << " [" << j << "]" << static_cast<int>(applicableResources[j]) << "\n";

						int choice;
						do {
							std::cout << "Enter choice (0-" << applicableResources.size() - 1 << "): ";
							std::cin >> choice;
						} while (choice < 0 || choice >= static_cast<int>(applicableResources.size()));

						chosen = applicableResources[choice];
					}
					needed[chosen]--;
					if (needed[chosen] == 0)
						needed.erase(chosen);
				}
			}
		}
	}

	int resourceDiscount = 0;

	if (isWonder) {
		for (auto const& t : self.getProgressTokens())
			if (t.name == "Architecture") {
				resourceDiscount = t.value;
				break;
			}
	}
	else {
		if (cardColour == CardColor::Blue) {
			for (auto const& t : self.getProgressTokens())
				if (t.name == "Masonry") {
					resourceDiscount = t.value;
					break;
				}
		}
		else if (cardColour == CardColor::Grey) {
			for (auto const& t : self.getProgressTokens())
				if (t.name == "Engineering") {
					resourceDiscount = t.value;
					break;
				}
		}
	}

	for (auto& [res, qty] : needed) {
		int used = std::min(qty, resourceDiscount);
		qty -= used;
		resourceDiscount -= used;
		if (resourceDiscount <= 0)
			break;
	}

	for (auto& [res, qty] : needed) {
		if (qty > 0) {
			int tradeCost = getTradeCost(opponent, res, self);
			int costForRes = qty * tradeCost;

			totalCoins += costForRes;
			tradeCoinsToOpponent += costForRes;
		}
	}

	r.coinsNeeded = totalCoins;
	r.coinsToOpponent = tradeCoinsToOpponent;
	r.possible = (self.getCoins() >= totalCoins);
	r.reason = r.possible ? "OK" : "Not enough coins. Needs " + std::to_string(totalCoins);
	return r;
}

CostResult computeBuildCardCost(const Player& self,
	const Player& opponent, const Card& card) {

	if (!card.chainFrom.empty())
		for (auto const& c : self.getBuiltCards())
			if (c.chainTo == card.chainFrom) {
				CostResult r{};
				r.possible = true;
				r.coinsNeeded = 0;
				r.coinsToOpponent = 0;
				r.reason = "Free by chain from: " + card.chainFrom;
				std::cout << "[Chain Building] " << card.name << " can be built for free! (Chain from " << card.chainFrom << ")\n";
				return r;
			}

	return calculateResourceCost(self, opponent, card.cost.resources,
		card.cost.coins, card.color, false);
}

CostResult computeBuildWonderCost(const Player& self, const Player& opponent, const Wonder& wonder) {
	return calculateResourceCost(self, opponent, wonder.cost.resources,
		wonder.cost.coins, CardColor::Purple, true);
}

ActionOutcome executeBuildCard(Player& self, Player& opponent, const Card& card) {

	ActionOutcome outcome{};
	auto cost = computeBuildCardCost(self, opponent, card);
	if (!cost.possible) {
		outcome.message = "Cannot afford this card. Needs " + std::to_string(cost.coinsNeeded) + " coins";
		return outcome;
	}

	bool isChainBuild = false;
	if (!card.chainFrom.empty()) {
		for (auto const& c : self.getBuiltCards()) {
			if (c.chainTo == card.chainFrom) {
				isChainBuild = true;
				break;
			}
		}
	}

	auto scienceResult = self.addCard(card);

	if (cost.coinsNeeded > 0) {
		if (!Bank::payToBank(cost.coinsNeeded, self, false)) {
			self.removeCard(self.getBuiltCards().size() - 1);
			outcome.message = "Failed to pay cost.";
			return outcome;
		}
	}

	if (opponent.getHasEconomyToken() && cost.coinsToOpponent > 0)
		Bank::payFromBank(cost.coinsToOpponent, opponent);

	if (isChainBuild && self.hasTokenByName("Urbanism")) {
		Bank::payFromBank(4, self);
		std::cout << "[Urbanism] +4 coins for chain building!\n";
	}

	outcome.success = true;
	outcome.message = card.name + " built successfully" + (isChainBuild ? " (via chain)" : "") + ".";

	if (auto winner = checkImmediateVictory(self, opponent)) {
		outcome.gameEnded = true;
		outcome.winner = winner;
		outcome.message = "Immediate Victory by Supremacy!";

		return outcome;
	}

	return outcome;
}

ActionOutcome executeDiscardCard(Player& self, Player& opponent, const Card& card) {
	ActionOutcome outcome{};

	int yellowCards = self.countCardsOfColor(CardColor::Yellow);
	int coinsGained = 2 + yellowCards;

	if (!Bank::payFromBank(coinsGained, self)) {
		outcome.message = "Failed to gain coins from bank";
		return outcome;
	}

	outcome.success = true;
	outcome.message = "Card discarded. Earned " + std::to_string(coinsGained) + " coins. ";

	return outcome;
}

static void applyBuildFromDiscardEffect(Player& self, Board& board) {
	if (board.discardPile.empty()) {
		std::cout << " -> Build from Discard: The discard pile is empty. No cards available to build.\n";
		std::cout << " -> This wonder effect cannot be used at this time.\n";
		return;
	}

	std::cout << " -> Build from Discard: Choose a card to build for free:\n";
	std::cout << "\n=== DISCARD PILE ===\n";

	for (size_t i = 0; i < board.discardPile.size(); ++i) {
		const Card& discardedCard = board.discardPile[i];
		std::cout << " [" << i << "] " << discardedCard.name
			<< " (" << static_cast<int>(discardedCard.color) << ") - "
			<< discardedCard.cost.toString() << "\n";
	}

	std::cout << " [" << board.discardPile.size() << "] Skip (don't build from discard)\n";

	int choice;
	do {
		std::cout << "Enter choice (0-" << board.discardPile.size() << "): ";
		std::cin >> choice;
		if (std::cin.fail()) {
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "Invalid input. Please enter a number.\n";
			choice = -1;
		}
	} while (choice < 0 || choice > static_cast<int>(board.discardPile.size()));

	if (choice < static_cast<int>(board.discardPile.size())) {
		Card chosenCard = board.discardPile[choice];
		self.addCard(chosenCard);
		board.discardPile.erase(board.discardPile.begin() + choice);

		std::cout << " -> Built " << chosenCard.name << " from discard pile for free!\n";

		if (chosenCard.scienceSymbol != ScienceSymbol::None &&
			self.countSymbol(chosenCard.scienceSymbol) == 2) {
			std::cout << " -> You collected two matching science symbols!\n";
			self.selectProgressToken(board.tokensPool);
		}
	}
	else {
		std::cout << " -> Skipped building from discard.\n";
	}
}

static void applyDestroyBrownEffect(Player& opponent) {
	std::cout << "-> Destroy one of opponent's Brown cards.\n";
	std::vector<size_t> brownCardIndices;
	const auto& oppCards = opponent.getBuiltCards();

	for (size_t i = 0; i < oppCards.size(); ++i) {
		if (oppCards[i].color == CardColor::Brown) {
			brownCardIndices.push_back(i);
		}
	}

	if (!brownCardIndices.empty()) {
		std::cout << "Opponent's Brown cards:\n";
		for (size_t i = 0; i < brownCardIndices.size(); ++i) {
			std::cout << " [" << i << "] " << oppCards[brownCardIndices[i]].name << "\n";
		}
		std::cout << "Choose a card to destroy (0-" << brownCardIndices.size() - 1 << "): ";
		int choice;
		std::cin >> choice;

		if (choice >= 0 && choice < static_cast<int>(brownCardIndices.size())) {
			size_t cardToDestroy = brownCardIndices[choice];
			std::cout << " -> Destroyed " << oppCards[cardToDestroy].name << "\n";
			opponent.removeCard(cardToDestroy);
		}
	}
	else {
		std::cout << "-> Opponent has no Brown cards to destroy\n";
	}
}

static void applyDestroyGreyEffect(Player& opponent) {
	std::cout << "-> Destroy one of opponent's Grey cards\n";
	std::vector<size_t> greyCardIndices;
	const auto& oppCards = opponent.getBuiltCards();

	for (size_t i = 0; i < oppCards.size(); ++i) {
		if (oppCards[i].color == CardColor::Grey) {
			greyCardIndices.push_back(i);
		}
	}

	if (!greyCardIndices.empty()) {
		std::cout << "Opponent's Grey cards:\n";
		for (size_t i = 0; i < greyCardIndices.size(); ++i) {
			std::cout << " [" << i << "] " << oppCards[greyCardIndices[i]].name << "\n";
		}
		std::cout << "Choose a card to destroy (0-" << greyCardIndices.size() - 1 << "): ";
		int choice;
		std::cin >> choice;

		if (choice >= 0 && choice < static_cast<int>(greyCardIndices.size())) {
			size_t cardToDestroy = greyCardIndices[choice];
			std::cout << " -> Destroyed " << oppCards[cardToDestroy].name << "\n";
			opponent.removeCard(cardToDestroy);
		}
	}
	else {
		std::cout << "-> Opponent has no Grey cards to destroy\n";
	}
}

static void applyDrawProgressTokenEffect(Player& self, Player& opponent, Board& board) {
	std::cout << " -> Draw Progress Token: Drawing 3 random tokens...\n";
	std::vector<ProgressToken> allTokens = getAllProgressTokens();
	std::vector<ProgressToken> unusedTokens;

	for (const auto& token : allTokens) {
		bool isUsed = false;

		for (const auto& poolToken : board.tokensPool) {
			if (token.name == poolToken.name) {
				isUsed = true;
				break;
			}
		}

		if (!isUsed) {
			for (const auto& ownedToken : self.getProgressTokens()) {
				if (token.name == ownedToken.name) {
					isUsed = true;
					break;
				}
			}
		}

		if (!isUsed) {
			for (const auto& ownedToken : opponent.getProgressTokens()) {
				if (token.name == ownedToken.name) {
					isUsed = true;
					break;
				}
			}
		}

		if (!isUsed) {
			unusedTokens.push_back(token);
		}
	}

	if (unusedTokens.empty()) {
		std::cout << " -> No unused progress tokens available.\n";
		return;
	}

	std::random_device rd;
	std::mt19937 rng(rd());
	std::shuffle(unusedTokens.begin(), unusedTokens.end(), rng);

	int tokensToOffer = std::min(3, static_cast<int>(unusedTokens.size()));
	std::vector<ProgressToken> tempPool(unusedTokens.begin(), unusedTokens.begin() + tokensToOffer);

	self.selectProgressToken(tempPool, tokensToOffer);

	std::cout << " -> The other drawn tokens were returned to the unused pile.\n";
}

static void applyWonderEffect(WonderEffect effect, int value, const Wonder& wonder,
	Player& self, Player& opponent, Board& board, ActionOutcome& outcome) {

	switch (effect) {
	case WonderEffect::GainCoins:
		Bank::payFromBank(value, self);
		std::cout << " -> Gained " << value << " coins.\n";
		break;

	case WonderEffect::GainPoints:
		std::cout << " -> Grants " << value << " victory points.\n";
		break;

	case WonderEffect::ExtraTurn:
		outcome.extraTurn = true;
		std::cout << " -> Grants an extra turn.\n";
		break;

	case WonderEffect::GainShields:
		outcome.shieldsGained = value;
		std::cout << " -> Grants " << value << " military shield(s).\n";
		break;

	case WonderEffect::ProduceFlexible:
		std::cout << " -> Grants flexible resource production: ";
		for (size_t j = 0; j < wonder.flexibleProduction.size(); j++) {
			std::cout << static_cast<int>(wonder.flexibleProduction[j]);
			if (j < wonder.flexibleProduction.size() - 1)
				std::cout << "/";
		}
		std::cout << "\n";
		break;

	case WonderEffect::BuildFromDiscard:
		applyBuildFromDiscardEffect(self, board);
		break;

	case WonderEffect::DestroyBrown:
		applyDestroyBrownEffect(opponent);
		break;

	case WonderEffect::DestroyGrey:
		applyDestroyGreyEffect(opponent);
		break;

	case WonderEffect::OpponentLosesCoins:
		Bank::payToBank(value, opponent, true);
		std::cout << " -> Opponent loses " << value << " coins.\n";
		break;

	case WonderEffect::DrawProgressToken:
		applyDrawProgressTokenEffect(self, opponent, board);
		break;

	default:
		break;
	}
}

static bool checkForTheologyTokenExtraTurn(const Player& self) {
	for (auto const& t : self.getProgressTokens()) {
		if (t.effect == TokenEffect::ExtraTurnWonder) {
			std::cout << " -> Theology token grants an extra turn.\n";
			return true;
		}
	}
	return false;
}

ActionOutcome executeBuildWonder(Player& self, Player& opponent,
	Wonder& wonderToBuild, const Card& cardToUse, Board& board) {

	ActionOutcome outcome{};

	if (wonderToBuild.built) {
		outcome.message = "Wonder already built.";
		return outcome;
	}

	auto cost = computeBuildWonderCost(self, opponent, wonderToBuild);
	if (!cost.possible) {
		outcome.message = "Cannot afford to build this wonder. Needs "
			+ std::to_string(cost.coinsNeeded) + " coins.";
		return outcome;
	}

	if (cost.coinsNeeded > 0) {
		if (!Bank::payToBank(cost.coinsNeeded, self, false)) {
			outcome.message = "Failed to pay cost.";
			return outcome;
		}
	}

	if (opponent.getHasEconomyToken() && cost.coinsToOpponent > 0)
		Bank::payFromBank(cost.coinsToOpponent, opponent);

	wonderToBuild.built = true;

	std::cout << "[Wonder] Applying effects of " << wonderToBuild.name << ":\n";

	bool hasNaturalExtraTurn = false;

	for (size_t i = 0; i < wonderToBuild.effects.size(); i++) {
		WonderEffect effect = wonderToBuild.effects[i];
		int value = wonderToBuild.effectValues[i];

		if (effect == WonderEffect::ExtraTurn)
			hasNaturalExtraTurn = true;

		applyWonderEffect(effect, value, wonderToBuild, self, opponent, board, outcome);
	}

	if (!hasNaturalExtraTurn) {
		if (checkForTheologyTokenExtraTurn(self))
			outcome.extraTurn = true;
	}

	outcome.success = true;
	outcome.message = wonderToBuild.name + " built successfully.\n";

	if (auto winner = checkImmediateVictory(self, opponent)) {
		outcome.gameEnded = true;
		outcome.winner = winner;
		outcome.message += "Immediate Victory by Supremacy!\n";
	}

	return outcome;
}

ActionOutcome executeDiscardCard(Player& self, Player& opponent, const Card& card, Board& board) {
	ActionOutcome outcome{};

	int yellowCards = self.countCardsOfColor(CardColor::Yellow);
	int coinsGained = 2 + yellowCards;

	if (!Bank::payFromBank(coinsGained, self)) {
		outcome.message = "Failed to gain coins from bank";
		return outcome;
	}

	board.discardPile.push_back(card);

	outcome.success = true;
	outcome.message = "Card discarded. Earned " + std::to_string(coinsGained) + " coins. ";

	return outcome;
}

std::optional<PlayerSide> checkImmediateVictory(const Player& p1, const Player& p2) {
	if (p1.hasScienceVictory())
		return PlayerSide::Player1;
	if (p2.hasScienceVictory())
		return PlayerSide::Player2;

	if (p1.hasMilitaryAdvantageOver(p2))
		return PlayerSide::Player1;
	if (p2.hasMilitaryAdvantageOver(p1))
		return PlayerSide::Player2;

	return std::nullopt;
}