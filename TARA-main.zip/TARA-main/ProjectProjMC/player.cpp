﻿module player;

import <algorithm>;
import <numeric>;
import <string>;
import <optional>;
import <cmath>;
import <limits>;
import<iostream>;
import <regex>;

import card;
import wonder;
import progress;

Player::Player(const std::string& name) : name_(name) {}

Player::Player(std::string&& name) : name_(std::move(name)) {}

const std::string& Player::getName() const noexcept { return name_; }

int Player::getCoins() const noexcept { return coins_; }

int Player::getShields() const noexcept { return shields_; }

const std::map<Resources, int>& Player::getProduction() const noexcept { return resourcesProduced_; }

const std::map<ScienceSymbol, int>& Player::getScience() const noexcept { return scienceSymbols_; }

const std::vector<Card>& Player::getBuiltCards() const noexcept { return builtCards_; }

std::vector<Wonder>& Player::getWonders() noexcept { return builtWonders_; }

const std::vector<Wonder>& Player::getWonders() const noexcept { return builtWonders_; }

const std::vector<ProgressToken>& Player::getProgressTokens() const noexcept { return progressTokens_; }

bool Player::earnCoins(int amount) noexcept {
	if (amount < 0)
		return false;
	coins_ += amount;
	return true;
}

std::optional<int> Player::payCoins(int amount) noexcept {
	if (coins_ < amount || amount < 0)
		return std::nullopt;
	coins_ -= amount;
	return coins_;
}

std::optional<ScienceSymbol>Player::addCard(const Card& c) {
	builtCards_.push_back(c);

	for (auto r : c.producesResources) {
		resourcesProduced_[r]++;
	}

	if (c.shields > 0) {
		int bonus = 0;

		if (c.color == CardColor::Red && this->hasStrategyToken_)
			bonus = 1;

		shields_ += (c.shields + bonus);
	}

	if (c.scienceSymbol != ScienceSymbol::None) {
		scienceSymbols_[c.scienceSymbol]++;
		if (scienceSymbols_[c.scienceSymbol] == 2) {
			return c.scienceSymbol;
		}
	}

	return std::nullopt;
}

void Player::addWonder(const Wonder& w) {
	builtWonders_.push_back(w);
}

void Player::removeCard(size_t index) {
	if (index >= builtCards_.size()) return;

	const Card& card = builtCards_[index];

	for (auto r : card.producesResources) {
		resourcesProduced_[r]--;
		if (resourcesProduced_[r] <= 0) {
			resourcesProduced_.erase(r);
		}
	}

	if (card.shields > 0) {
		shields_ -= card.shields;
		if (shields_ < 0) shields_ = 0;
	}

	if (card.scienceSymbol != ScienceSymbol::None) {
		scienceSymbols_[card.scienceSymbol]--;
		if (scienceSymbols_[card.scienceSymbol] <= 0) {
			scienceSymbols_.erase(card.scienceSymbol);
		}
	}

	builtCards_.erase(builtCards_.begin() + index);

}

void Player::addProgressToken(ProgressToken token) {
	progressTokens_.push_back(token);

	if (token.effect == TokenEffect::ScienceSymbol) this->hasLawToken_ = true;

	if (token.effect == TokenEffect::ExtraShieldPerRed) this->hasStrategyToken_ = true;

	if (token.effect == TokenEffect::MirrorCoinsSpent) this->hasEconomyToken_ = true;
}

bool Player::hasToken(TokenEffect effect) const noexcept {
	for (const auto& t : progressTokens_)
		if (t.effect == effect) return true;

	return false;
}

bool Player::hasTokenByName(const std::string& name) const noexcept {
	for (const auto& t : progressTokens_)
		if (t.name == name) return true;
	return false;
}

int Player::countProgressTokens() const noexcept {
	return static_cast<int>(progressTokens_.size());
}

int Player::countResource(Resources r) const noexcept {
	auto it = resourcesProduced_.find(r);
	if (it == resourcesProduced_.end()) return 0;
	return it->second;
}

int Player::countSymbol(ScienceSymbol s) const noexcept {
	auto it = scienceSymbols_.find(s);
	if (it == scienceSymbols_.end()) return 0;
	return it->second;
}

int Player::countDistinctScienceSymbols() const noexcept {
	int distinct = 0;
	for (auto& [sym, qty] : scienceSymbols_) {
		if (sym != ScienceSymbol::None && qty > 0)
			++distinct;
	}
	//aplicare bonus simbol stiintific(law)
	//daca tokenul law e detinut adauga un simbol distinct suplimentar
	if (this->hasLawToken_) {
		distinct += 1;
	}
	return distinct;
}

void Player::selectProgressToken(std::vector<ProgressToken>& tokenPool, int numTokensToOffer) {
	if (tokenPool.empty()) {
		std::cout << "[Progress Token] No tokens available in the pool.\n";
		return;
	}


	int tokensToShow = std::min(numTokensToOffer, static_cast<int>(tokenPool.size()));

	std::cout << "\n=== SELECT PROGRESS TOKEN ===\n";
	std::cout << "Available Progress Tokens:\n\n";

	for (int i = 0; i < tokensToShow; ++i) {
		const auto& token = tokenPool[i];
		std::cout << " [" << i << "] " << token.name << "\n";
		std::cout << "     " << token.description << "\n";


		switch (token.effect) {
		case TokenEffect::GainCoins:
			std::cout << "     Effect: Gain " << token.value << " coins\n";
			break;
		case TokenEffect::GainPoints:
			std::cout << "     Effect: Gain " << token.value << " victory points\n";
			break;
		case TokenEffect::ReduceWonderCost:
			std::cout << "     Effect: Reduce wonder resource cost by " << token.value << "\n";
			break;
		case TokenEffect::ReduceBlueCost:
			std::cout << "     Effect: Reduce blue card resource cost by " << token.value << "\n";
			break;
		case TokenEffect::ReduceGreyCost:
			std::cout << "     Effect: Reduce grey card resource cost by " << token.value << "\n";
			break;
		case TokenEffect::MirrorCoinsSpent:
			std::cout << "     Effect: Receive coins opponent spends on trade\n";
			break;
		case TokenEffect::ScienceSymbol:
			std::cout << "     Effect: Counts as an extra science symbol\n";
			break;
		case TokenEffect::ExtraShieldPerRed:
			std::cout << "     Effect: +1 shield per red (military) card\n";
			break;
		case TokenEffect::ExtraTurnWonder:
			std::cout << "     Effect: Gain extra turn when building wonders\n";
			break;
		case TokenEffect::ChainBonus:
			std::cout << "     Effect: Chain building bonus\n";
			break;
		default:
			std::cout << "     Effect: Special effect\n";
			break;
		}
		std::cout << "\n";
	}

	int choice;
	do {
		std::cout << "Choose a progress token (0-" << tokensToShow - 1 << "): ";
		std::cin >> choice;
		if (std::cin.fail() || choice < 0 || choice >= tokensToShow) {
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "Invalid choice. Try again.\n";
		}
		else {
			break;
		}
	} while (true);


	ProgressToken selectedToken = tokenPool[choice];


	addProgressToken(selectedToken);


	tokenPool.erase(tokenPool.begin() + choice);

	std::cout << "\n[Progress Token] You acquired: " << selectedToken.name << "\n";

	if (selectedToken.effect == TokenEffect::GainCoins) {
		earnCoins(selectedToken.value);
		std::cout << "[Progress Token] Gained " << selectedToken.value << " coins immediately!\n";
	}

	std::cout << "\n";
}




bool Player::getHasEconomyToken() const noexcept { return hasEconomyToken_; }

bool Player::getHasLawToken() const noexcept { return hasLawToken_; }

bool Player::getHasStrategyToken() const noexcept { return hasStrategyToken_; }


bool Player::hasScienceVictory() const noexcept { return countDistinctScienceSymbols() >= 6; }

bool Player::hasMilitaryAdvantageOver(const Player& opponent) const noexcept { return (shields_ - opponent.shields_) >= 9; }

int Player::countCardsOfColor(CardColor col) const noexcept {
	int cnt = 0;
	for (const auto& c : builtCards_) {
		if (c.color == col) ++cnt;
	}
	return cnt;
}

int Player::calculateGuildPoints(const Player& opponent) const noexcept
{
	int vp = 0;
	for (const auto& c : builtCards_) {
		if (c.color != CardColor::Purple) continue;

		auto self_card_count = [&](CardColor col) { return countCardsOfColor(col); };

		auto opp_card_count = [&](CardColor col) { return opponent.countCardsOfColor(col); };

		switch (c.effect) {
		case CardEffect::GuildVPWonders: {
			std::size_t max_wonders = std::max(builtWonders_.size(), opponent.getWonders().size());
			vp += 2 * static_cast<int>(max_wonders);
			break;
		}
		case CardEffect::GuildVPCoinSets: {
			int max_coins = std::max(getCoins(), opponent.getCoins());
			vp += max_coins / 3;
			break;
		}
		case CardEffect::GuildVPYellow:
		case CardEffect::GuildVPBlue:
		case CardEffect::GuildVPGreen:
		case CardEffect::GuildVPRed: {
			CardColor target_col = CardColor::None;
			if (c.effect == CardEffect::GuildVPYellow) target_col = CardColor::Yellow;
			else if (c.effect == CardEffect::GuildVPBlue) target_col = CardColor::Blue;
			else if (c.effect == CardEffect::GuildVPGreen) target_col = CardColor::Green;
			else target_col = CardColor::Red;

			int max_count = std::max(self_card_count(target_col), opp_card_count(target_col));
			vp += max_count;
			break;
		}
		case CardEffect::GuildVPBrownGrey: {
			int self_res = self_card_count(CardColor::Brown) + self_card_count(CardColor::Grey);
			int opp_res = opp_card_count(CardColor::Brown) + opp_card_count(CardColor::Grey);

			vp += std::max(self_res, opp_res);
			break;
		}
		default: break;
		}
	}

	return vp;
}

int Player::totalVictoryPoints(const Player& opponent, bool isFinalScoring) const noexcept {
	int vp = 0;


	for (const auto& c : builtCards_) {
		if (isFinalScoring || c.color != CardColor::Purple) {
			vp += c.points;
		}
	}


	for (const auto& w : builtWonders_)
		if (w.built)
			for (size_t i = 0; i < w.effects.size(); i++)
				if (w.effects[i] == WonderEffect::GainPoints)
					vp += w.effectValues[i];

	if (isFinalScoring) {
		vp += coins_ / 3;
	}

	if (isFinalScoring) {
		vp += calculateGuildPoints(opponent);
	}

	for (const auto& t : progressTokens_) {

		if (t.effect == TokenEffect::GainPoints && t.name == "Mathematics") {
			if (isFinalScoring) {
				vp += 3 * countProgressTokens();
			}
		}

		else if (t.effect == TokenEffect::GainPoints && t.value > 0) {
			vp += t.value;
		}
		if (t.name == "Agriculture") {
			vp += 4;
		}
	}

	return vp;

}

bool Player::isValidName(const std::string& name) {
	if (name.empty() || name.length() < 2 || name.length() > 20) {
		return false;
	}
	std::regex namePattern("^[A-Za-z][A-Za-z' -]{1,19}$");

	std::regex noConsecutiveSpaces("^(?!.* {2}).*$");

	if (name.front() == ' ' || name.back() == ' ')
		return false;
	return std::regex_match(name, namePattern) && std::regex_match(name, noConsecutiveSpaces);

}