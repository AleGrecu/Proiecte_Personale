﻿module game;

import <algorithm>;
import <random>;
import <chrono>;
import <ranges>;
import <vector>;
import <optional>;
import <string>;
import <map>;
import <iostream>;
import <limits>;

import display;
import age1_cards;
import age2_cards;
import age3_cards;
import guild_cards;
import wonder;
import player;
import game_enums;
import card;
import ai;
import board;
import rules;

Game::Game(std::string player1Name, std::string player2Name)
	: p1_(player1Name)
	, p2_(player2Name) {
}

const Player& Game::getPlayer(PlayerSide side) const noexcept {
	return (side == PlayerSide::Player1) ? p1_ : p2_;
}

Player& Game::getPlayer(PlayerSide side) noexcept {
	return (side == PlayerSide::Player1) ? p1_ : p2_;
}

GameState Game::state() const noexcept {
	return state_;
}

int Game::currentAge() const noexcept {
	return currentAge_;
}

PlayerSide Game::currentPlayer() const noexcept {
	return current_;
}

PlayerSide Game::otherPlayer() const noexcept {
	return (current_ == PlayerSide::Player1) ? PlayerSide::Player2 : PlayerSide::Player1;
}

Player& Game::currentPlayerRef() noexcept {
	return (current_ == PlayerSide::Player1) ? p1_ : p2_;
}

const Player& Game::currentPlayerRef() const noexcept {
	return (current_ == PlayerSide::Player1) ? p1_ : p2_;
}

Player& Game::otherPlayerRef() noexcept {
	return (current_ == PlayerSide::Player1) ? p2_ : p1_;
}

const Player& Game::otherPlayerRef() const noexcept {
	return (current_ == PlayerSide::Player1) ? p2_ : p1_;
}

void Game::startNewGame() {
	state_ = GameState::Age1;
	currentAge_ = 1;
}

void Game::advanceAge() {
	if (currentAge_ < 3) {
		++currentAge_;
		state_ = static_cast<GameState>(static_cast<int>(state_) + 1);
	}
	else {
		state_ = GameState::Finished;
	}
}

GameMode selectGameMode() {
	printSeparator('=', 50);
	std::cout << "7 WONDERS DUEL - GAME SETUP\n";
	printSeparator('=', 50);
	std::cout << "Select Game Mode:\n";
	std::cout << " [0] Player vs Player\n";
	std::cout << " [1] Player vs AI\n";

	int choice = getPlayerChoice(2);
	return (choice == 0) ? GameMode::PlayerVsPlayer : GameMode::PlayerVsAI;
}

void getPlayerNames(GameMode mode, std::string& player1Name, std::string& player2Name) {
	std::cout << "\n";
	printSeparator('-', 50);
	if (mode == GameMode::PlayerVsPlayer) {
		do {
			std::cout << "Enter Player 1 name: ";
			std::getline(std::cin >> std::ws, player1Name);
			if (!Player::isValidName(player1Name)) {
				std::cout << "Invalid name. Please try again. (msut be 2-20 characters, no consecutive)\n";

			}

		} while (!Player::isValidName(player1Name));

		do {
			std::cout << "Enter Player 2 name: ";
			std::getline(std::cin >> std::ws, player2Name);
			if (!Player::isValidName(player2Name)) {
				std::cout << "Invalid name. Please try again. (must be 2-20 characters, no consecutive)\n";
			}
			else if (player2Name == player1Name) {
				std::cout << "Name already taken. Choose a different name.\n";
			}
		} while (!Player::isValidName(player2Name) || player2Name == player1Name);
	}
	else {
		do {
			std::cout << "Enter your name: ";
			std::getline(std::cin >> std::ws, player1Name);
			if (!Player::isValidName(player1Name)) {
				std::cout << "Invalid name. Please try again. (must be 2-20 characters, no consecutive)\n";
			}
		} while (!Player::isValidName(player1Name));

		player2Name = "AI";
		std::cout << "You will play against: " << player2Name << "\n";

		printSeparator('-', 50);
		std::cout << "\n";
	}
}

PlayerSide selectFirstPlayer(GameMode mode, const std::string& player1Name, const std::string& player2Name) {
	printSeparator('-', 50);
	std::cout << "Dice Toss - Who goes first?\n";
	printSeparator('-', 50);

	if (mode == GameMode::PlayerVsPlayer) {
		std::cout << "\n Both players will roll the dice!\n";
		std::cout << " The player with the higher roll starts first.\n\n";

		std::cout << "Press Enter for " << player1Name << " to roll the dice...";
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		std::cin.get();

		int roll1 = simulateDiceToss(player1Name);

		std::cout << "Press Enter for " << player2Name << " to roll the dice...";
		std::cin.get();

		int roll2 = simulateDiceToss(player2Name);

		printSeparator('-', 50);
		std::cout << "    RESULTS\n";
		printSeparator('-', 50);
		std::cout << " " << player1Name << ": " << roll1 << "\n";
		std::cout << " " << player2Name << ": " << roll2 << "\n";
		printSeparator('-', 50);

		if (roll1 > roll2) {
			std::cout << "\n " << player1Name << " rolled higher and goes first!\n\n";
			return PlayerSide::Player1;
		}
		else if (roll2 > roll1) {
			std::cout << "\n " << player2Name << " rolled higher and goes first!\n\n";
			return PlayerSide::Player2;
		}
		else {
			std::cout << "\n It's a TIE! Rolling again...\n\n";
			std::cout << "Press Enter to re-roll...";
			std::cin.get();
			return selectFirstPlayer(mode, player1Name, player2Name);
		}
	}
	else {
		std::cout << "\n>>> Rolling dice to determine who starts...\n\n";

		std::cout << "Press Enter to roll the dice...";
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		std::cin.get();

		int playerRoll = simulateDiceToss(player1Name);
		int aiRoll = simulateDiceToss(player2Name);

		printSeparator('-', 50);
		std::cout << "    RESULTS\n";
		printSeparator('-', 50);
		std::cout << " " << player1Name << ": " << playerRoll << "\n";
		std::cout << " " << player2Name << ": " << aiRoll << "\n";
		printSeparator('-', 50);

		if (playerRoll > aiRoll) {
			std::cout << "\n You rolled higher and go first!\n\n";
			return PlayerSide::Player1;
		}
		else if (aiRoll > playerRoll) {
			std::cout << "\n AI rolled higher and goes first!\n\n";
			return PlayerSide::Player2;
		}
		else {
			std::cout << "\n  It's a TIE! Rolling again...\n\n";
			std::cout << "Press Enter to re-roll...";
			std::cin.get();
			return selectFirstPlayer(mode, player1Name, player2Name);
		}
	}
}

static double calculateWonderScore(const Wonder& wonder) {
	double score = 0.0;

	for (size_t i = 0; i < wonder.effects.size(); ++i) {
		switch (wonder.effects[i]) {
		case WonderEffect::GainPoints:
			score += wonder.effectValues[i] * 10.0;
			break;
		case WonderEffect::ExtraTurn:
			score += 50.0;
			break;
		case WonderEffect::DrawProgressToken:
			score += 45.0;
			break;
		case WonderEffect::GainShields:
			score += wonder.effectValues[i] * 12.0;
			break;
		case WonderEffect::ProduceFlexible:
			score += 35.0;
			break;
		case WonderEffect::BuildFromDiscard:
			score += 30.0;
			break;
		case WonderEffect::DestroyBrown:
			score += 25.0;
			break;
		case WonderEffect::DestroyGrey:
			score += 28.0;
			break;
		case WonderEffect::GainCoins:
			score += wonder.effectValues[i] * 2.0;
			break;
		case WonderEffect::OpponentLosesCoins:
			score += wonder.effectValues[i] * 3.0;
			break;
		default:
			break;
		}
	}

	int totalResourceCost = 0;
	for (const auto& [res, qty] : wonder.cost.resources) {
		totalResourceCost += qty;
	}

	if (totalResourceCost > 0) {
		score -= totalResourceCost * 2.0;
	}

	score -= wonder.cost.coins * 0.5;

	return score;
}

static int selectBestWonderAI(const std::vector<Wonder>& wonders) {
	int bestIndex = 0;
	double bestScore = -std::numeric_limits<double>::infinity();

	for (size_t i = 0; i < wonders.size(); ++i) {
		double score = calculateWonderScore(wonders[i]);

		if (score > bestScore) {
			bestScore = score;
			bestIndex = static_cast<int>(i);
		}
	}

	return bestIndex;
}

static void displayWonderOptions(const std::vector<Wonder>& wonders) {
	std::cout << "\nAvailable Wonders:\n";
	printSeparator('-', 50);
	for (size_t i = 0; i < wonders.size(); ++i) {
		std::cout << " [" << i << "] " << wonders[i].name << "\n";
		std::cout << " Cost: " << wonders[i].cost.toString() << "\n";
		std::cout << " Effects: ";

		for (size_t j = 0; j < wonders[i].effects.size(); ++j) {
			switch (wonders[i].effects[j]) {
			case WonderEffect::GainCoins: std::cout << "+" << wonders[i].effectValues[j] << " coins "; break;
			case WonderEffect::GainPoints: std::cout << "+" << wonders[i].effectValues[j] << " VP "; break;
			case WonderEffect::ExtraTurn: std::cout << "Extra turn "; break;
			case WonderEffect::GainShields: std::cout << "+" << wonders[i].effectValues[j] << " shields "; break;
			case WonderEffect::ProduceFlexible: std::cout << "Flexible production "; break;
			case WonderEffect::BuildFromDiscard: std::cout << "Build from discard "; break;
			case WonderEffect::DestroyBrown: std::cout << "Destroy brown card "; break;
			case WonderEffect::DestroyGrey: std::cout << "Destroy grey card "; break;
			case WonderEffect::OpponentLosesCoins: std::cout << "Opponent loses coins "; break;
			case WonderEffect::DrawProgressToken: std::cout << "Draw progress token "; break;
			default: break;
			}
		}
		std::cout << "\n\n";
	}
	printSeparator('-', 50);

}

static void wonderSelectionRound(std::vector<Wonder>& wonderPool, Player& firstPlayer, Player& secondPlayer,
	const std::string& firstPlayerName, const std::string& secondPlayerName,
	bool firstPlayerStarts, std::mt19937& rng, GameMode mode) {

	std::shuffle(wonderPool.begin(), wonderPool.end(), rng);
	std::vector<Wonder> roundWonders;

	for (int i = 0; i < 4 && !wonderPool.empty(); ++i) {
		roundWonders.push_back(wonderPool.back());
		wonderPool.pop_back();
	}

	std::cout << "\n";
	printSeparator('*', 50);
	std::cout << "    WONDER SELECTION ROUND\n";
	printSeparator('*', 50);

	displayWonderOptions(roundWonders);

	Player* picker1 = firstPlayerStarts ? &firstPlayer : &secondPlayer;
	Player* picker2 = firstPlayerStarts ? &secondPlayer : &firstPlayer;
	std::string picker1Name = firstPlayerStarts ? firstPlayerName : secondPlayerName;
	std::string picker2Name = firstPlayerStarts ? secondPlayerName : firstPlayerName;
	bool picker1IsAI = (mode == GameMode::PlayerVsAI && picker1Name == "AI");
	bool picker2IsAI = (mode == GameMode::PlayerVsAI && picker2Name == "AI");

	int choice1;
	if (picker1IsAI) {
		choice1 = selectBestWonderAI(roundWonders);
		std::cout << "\n[AI] Selected wonder at index: " << choice1 << "\n";
	}
	else {
		std::cout << "\n" << picker1Name << ", choose your first wonder (0-" << static_cast<int>(roundWonders.size()) - 1 << "): ";
		choice1 = getPlayerChoice(static_cast<int>(roundWonders.size()));
	}
	picker1->addWonder(roundWonders[choice1]);
	std::cout << picker1Name << " selected: " << roundWonders[choice1].name << "\n";
	roundWonders.erase(roundWonders.begin() + choice1);

	displayWonderOptions(roundWonders);

	int choice2;
	if (picker2IsAI) {
		choice2 = selectBestWonderAI(roundWonders);
		std::cout << "\n[AI] Selected wonder at index: " << choice2 << "\n";
	}
	else {
		std::cout << "\n" << picker2Name << ", choose your first wonder (0-" << static_cast<int>(roundWonders.size()) - 1 << "): ";
		choice2 = getPlayerChoice(static_cast<int>(roundWonders.size()));
	}
	picker2->addWonder(roundWonders[choice2]);
	std::cout << picker2Name << " selected: " << roundWonders[choice2].name << "\n";
	roundWonders.erase(roundWonders.begin() + choice2);

	displayWonderOptions(roundWonders);

	int choice3;
	if (picker2IsAI) {
		choice3 = selectBestWonderAI(roundWonders);
		std::cout << "\n[AI] Selected wonder at index: " << choice3 << "\n";
	}
	else {
		std::cout << "\n" << picker2Name << ", choose your second wonder (0-" << static_cast<int>(roundWonders.size()) - 1 << "): ";
		choice3 = getPlayerChoice(static_cast<int>(roundWonders.size()));
	}
	picker2->addWonder(roundWonders[choice3]);
	std::cout << picker2Name << " selected: " << roundWonders[choice3].name << "\n";
	roundWonders.erase(roundWonders.begin() + choice3);


	picker1->addWonder(roundWonders[0]);
	std::cout << picker1Name << " receives the remaining wonder: " << roundWonders[0].name << "\n";
}

void wonderSelectionPhase(Player& p1, Player& p2, const std::string& player1Name,
	const std::string& player2Name, PlayerSide firstPlayer) {

	printSeparator('=', 50);
	std::cout << "    WONDERS SELECTION PHASE\n";
	printSeparator('=', 50);

	std::vector<Wonder> allWonders = getAllWonders();

	std::random_device rd;
	std::mt19937 rng(rd());

	GameMode mode = (player2Name == "AI") ? GameMode::PlayerVsAI : GameMode::PlayerVsPlayer;

	wonderSelectionRound(allWonders, p1, p2, player1Name, player2Name,
		(firstPlayer == PlayerSide::Player1), rng, mode);

	std::cout << "\n";
	printSeparator('-', 50);
	std::cout << "Press Enter to continue to second selection round...";
	std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	std::cin.get();

	wonderSelectionRound(allWonders, p1, p2, player1Name, player2Name,
		(firstPlayer == PlayerSide::Player2), rng, mode);

	std::cout << "\n";
	printSeparator('=', 50);
	std::cout << "    FINAL WONDER SELECTIONS\n";
	printSeparator('=', 50);

	std::cout << "\n" << player1Name << "'s Wonders:\n";
	for (const auto& w : p1.getWonders()) {
		std::cout << "  - " << w.name << "\n";
	}

	std::cout << "\n" << player2Name << "'s Wonders:\n";
	for (const auto& w : p2.getWonders()) {
		std::cout << "  - " << w.name << "\n";
	}

	printSeparator('=', 50);
	std::cout << "\n";
}

std::vector<Card> prepareAgeDeck(int age) {
	std::vector<Card> deck;

	if (age == 1) {
		deck = getCardsAge1();
	}
	else if (age == 2) {
		deck = getCardsAge2();
	}
	else if (age == 3) {
		deck = getCardsAge3();

		std::vector<Card> allGuilds = getAllGuildCards();

		std::random_device rd;
		std::mt19937 rng(rd());
		std::shuffle(allGuilds.begin(), allGuilds.end(), rng);

		for (int i = 0; i < 3 && i < static_cast<int>(allGuilds.size()); ++i) {
			deck.push_back(allGuilds[i]);
		}
	}

	std::random_device rd;
	std::mt19937 rng(rd());
	std::shuffle(deck.begin(), deck.end(), rng);

	if (deck.size() > 3) {
		deck.erase(deck.end() - 3, deck.end());
	}

	return deck;
}

void handleAITurn(
	Player& aiPlayer,
	Player& humanPlayer,
	const std::vector<std::pair<const Card*, int>>& availableCards,
	Board& board,
	AIDifficulty difficulty) {

	AIPlayer ai(difficulty);

	AIDecision decision = ai.makeDecision(aiPlayer, humanPlayer, availableCards, board);

	std::cout << "[AI] Decision: " << decision.reason << "\n";

	switch (decision.action) {
	case AIDecision::ActionType::BuildCard: {
		if (decision.cardIndex >= 0 &&
			decision.cardIndex < static_cast<int>(availableCards.size())) {

			const Card* card = availableCards[decision.cardIndex].first;
			auto outcome = executeBuildCard(aiPlayer, humanPlayer, *card);

			std::cout << "[AI] " << outcome.message << "\n";
		}
		break;
	}

	case AIDecision::ActionType::BuildWonder: {

		const auto& wonders = aiPlayer.getWonders();

		if (decision.wonderIndex >= 0 && decision.wonderIndex < static_cast<int>(wonders.size()) &&
			decision.cardIndex >= 0 && decision.cardIndex < static_cast<int>(availableCards.size())) {

			Wonder& wonder = const_cast<Wonder&>(aiPlayer.getWonders()[decision.wonderIndex]);
			const Card* cardUsedAsPayment = availableCards[decision.cardIndex].first;

			auto outcome = executeBuildWonder(aiPlayer, humanPlayer, wonder, *cardUsedAsPayment, board);

			std::cout << "[AI] Wonder Build: " << outcome.message << "\n";
		}
		else {
			std::cout << "[AI] Failed to build wonder: Invalid indices.\n";
		}
		break;
	}


	case AIDecision::ActionType::DiscardCard: {
		if (decision.cardIndex >= 0 &&
			decision.cardIndex < static_cast<int>(availableCards.size())) {

			const Card* card = availableCards[decision.cardIndex].first;
			auto outcome = executeDiscardCard(aiPlayer, humanPlayer, *card, board);

			std::cout << "[AI] " << outcome.message << "\n";
		}
		break;
	}
	}
}