﻿module progress;
import <sstream>;

std::string ProgressToken::info() const {
	std::ostringstream ss;
	ss << name << " _ " << description;
	return ss.str();
}

std::vector<ProgressToken>getAllProgressTokens()
{
	return{

		{"Agriculture","+6 Coins or +4 Victory Points",
		TokenEffect::GainCoins,6},

		{"Agriculture Points", "Part of Agriculture effects (+4 VP)",
		 TokenEffect::GainPoints,4},

		 //Architecture
		{"Architecture","Reduce cost of Wonders by 2 resources",
		TokenEffect::ReduceWonderCost,2},

		//Economy
		{"Economy","Gain coins equal to what opponent spends buying resources"
		,TokenEffect::MirrorCoinsSpent, 0 },

		//Law
		{"Law", "Grants an extra science symbol",
		TokenEffect::ScienceSymbol,1},

		//Mansory
		{"Mansory","Reduce cost of Blue cards by 2 resources",
		TokenEffect::ReduceBlueCost,2},

		//Philosophy
		{"Philosophy", "+7 victory points",
		TokenEffect::GainPoints,7},

		//Strategy
		{"Strategy", "+1 shield for each Red card you build",
		 TokenEffect::ExtraShieldPerRed,1},

		//Theology
		{"Theology","Your Wonder with extra turn ability properly",
		 TokenEffect::ExtraTurnWonder,1},

		//Urbanism
		{"Urbanism","+6 coins when you build yellow cards",
		TokenEffect::GainCoins,6},

		//Engineering
		{"Engineering","Reduce cost of Grey cards by 2 resources",
		TokenEffect::ReduceGreyCost,2}
	};
}

void applyImmediateEffect(ProgressToken const& t, int& coins, int& points, bool& scienceLawFlag)
{
	using enum TokenEffect;

	switch (t.effect)
	{
	case GainCoins:
		coins += t.value;
		break;
	case GainPoints:
		points += t.value;
		break;
	case ScienceSymbol:
		scienceLawFlag = true;
		break;
	default:
		break;
	}
}