﻿module ai;

import <algorithm>;
import <random>;
import <iostream>;
import <cmath>;

import card;
import player;
import board;
import rules;
import wonder;

AIPlayer::AIPlayer(AIDifficulty difficulty)
	: difficulty_(difficulty) {
}

AIDecision AIPlayer::makeDecision(
	const Player& self,
	const Player& opponent,
	const std::vector<std::pair<const Card*, int>>& availableCards,
	const Board& board) {

	std::cout << "[AI] Thinking...\n";

	if (availableCards.empty()) {
		std::cout << "[AI] No cards available, must pass.\n";
		return { AIDecision::ActionType::DiscardCard, 0, -1, 0.0, "No cards" };
	}

	AIDecision bestDecision;
	double bestScore = -std::numeric_limits<double>::infinity();

	int maxDepth = (difficulty_ == AIDifficulty::Hard) ? 3 :
		(difficulty_ == AIDifficulty::Medium) ? 2 : 1;

	auto possibleActions = generatePossibleActions(self, availableCards);

	std::cout << "[AI] Evaluating " << possibleActions.size() << " possible actions...\n";

	for (const auto& action : possibleActions) {

		GameState currentState{
			.aiPlayer = self,
			.humanPlayer = opponent,
			.board = board,
			.isAITurn = true
		};

		GameState newState = simulateAction(currentState, action, availableCards);


		double score = minimax(newState, maxDepth - 1,
			-std::numeric_limits<double>::infinity(),
			std::numeric_limits<double>::infinity(),
			false);

		if (score > bestScore) {
			bestScore = score;
			bestDecision = action;
			bestDecision.evaluationScore = score;
		}
	}

	std::cout << "[AI] Best action score: " << bestScore << " - " << bestDecision.reason << "\n";

	return bestDecision;
}

double AIPlayer::minimax(
	const GameState& state,
	int depth,
	double alpha,
	double beta,
	bool maximizingPlayer) {

	if (depth == 0) {
		return evaluateState(state.aiPlayer, state.humanPlayer);
	}

	if (state.aiPlayer.hasScienceVictory() || state.aiPlayer.hasMilitaryAdvantageOver(state.humanPlayer)) {
		return 10000.0;
	}
	if (state.humanPlayer.hasScienceVictory() || state.humanPlayer.hasMilitaryAdvantageOver(state.aiPlayer)) {
		return -10000.0;
	}

	if (maximizingPlayer) {
		double maxEval = -std::numeric_limits<double>::infinity();


		maxEval = evaluateState(state.aiPlayer, state.humanPlayer);

		return maxEval;
	}
	else {
		double minEval = std::numeric_limits<double>::infinity();
		minEval = evaluateState(state.aiPlayer, state.humanPlayer);

		return minEval;
	}
}

double AIPlayer::evaluateState(
	const Player& aiPlayer,
	const Player& humanPlayer) const {

	double score = 0.0;

	int aiVP = aiPlayer.totalVictoryPoints(humanPlayer, false);
	int humanVP = humanPlayer.totalVictoryPoints(aiPlayer, false);
	score += (aiVP - humanVP) * 5.0;

	int shieldDiff = aiPlayer.getShields() - humanPlayer.getShields();
	score += shieldDiff * 3.0;

	int aiScience = aiPlayer.countDistinctScienceSymbols();
	int humanScience = humanPlayer.countDistinctScienceSymbols();

	if (aiScience >= 5) score += 1000.0;
	if (humanScience >= 5) score -= 1000.0;

	score += (aiScience - humanScience) * 20.0;

	score += (aiPlayer.getCoins() - humanPlayer.getCoins()) * 0.5;

	int aiWonders = 0;
	for (const auto& w : aiPlayer.getWonders()) {
		if (w.built) aiWonders++;
	}

	int humanWonders = 0;
	for (const auto& w : humanPlayer.getWonders()) {
		if (w.built) humanWonders++;
	}

	score += (aiWonders - humanWonders) * 15.0;

	int aiResources = 0;
	for (const auto& [res, qty] : aiPlayer.getProduction()) {
		aiResources += qty;
	}

	int humanResources = 0;
	for (const auto& [res, qty] : humanPlayer.getProduction()) {
		humanResources += qty;
	}

	score += (aiResources - humanResources) * 2.0;

	score += (aiPlayer.countProgressTokens() - humanPlayer.countProgressTokens()) * 10.0;

	return score;
}

std::vector<AIDecision> AIPlayer::generatePossibleActions(
	const Player& player,
	const std::vector<std::pair<const Card*, int>>& availableCards) const {

	std::vector<AIDecision> actions;

	for (size_t i = 0; i < availableCards.size(); ++i) {
		const Card* card = availableCards[i].first;

		AIDecision decision;
		decision.action = AIDecision::ActionType::BuildCard;
		decision.cardIndex = static_cast<int>(i);

		double cardScore = 0.0;
		cardScore += card->points * 10.0;
		cardScore += card->shields * 8.0;

		if (card->scienceSymbol != ScienceSymbol::None) {
			cardScore += 15.0;
			if (player.countSymbol(card->scienceSymbol) > 0) {
				cardScore += 25.0;
			}
		}

		cardScore += card->producesResources.size() * 5.0;

		if (!card->chainTo.empty()) {
			cardScore += 12.0;
		}

		if (card->color == CardColor::Purple) {
			cardScore += 20.0;
		}

		decision.evaluationScore = cardScore;
		decision.reason = "Build " + card->name;

		actions.push_back(decision);
	}

	const auto& wonders = player.getWonders();
	for (size_t i = 0; i < wonders.size(); ++i) {
		if (!wonders[i].built && !availableCards.empty()) {
			AIDecision decision;
			decision.action = AIDecision::ActionType::BuildWonder;
			decision.wonderIndex = static_cast<int>(i);
			decision.cardIndex = 0;
			decision.evaluationScore = 30.0;
			decision.reason = "Build Wonder: " + wonders[i].name;

			actions.push_back(decision);
		}
	}


	if (!availableCards.empty()) {
		AIDecision decision;
		decision.action = AIDecision::ActionType::DiscardCard;
		decision.cardIndex = 0;
		decision.evaluationScore = 5.0;
		decision.reason = "Discard for coins";

		actions.push_back(decision);
	}

	return actions;
}

AIPlayer::GameState AIPlayer::simulateAction(
	const GameState& state,
	const AIDecision& decision,
	const std::vector<std::pair<const Card*, int>>& availableCards) const {

	GameState newState = state;

	if (decision.action == AIDecision::ActionType::BuildCard &&
		decision.cardIndex >= 0 &&
		decision.cardIndex < static_cast<int>(availableCards.size())) {

		const Card* card = availableCards[decision.cardIndex].first;

		newState.aiPlayer.addCard(*card);
	}

	return newState;
}