﻿module layout;
import <ranges>;
import <utility>;
import <algorithm>;
import <string>;
import <vector>;

void Layout::buildFrom(const std::vector<Card>& cards, const std::vector<Edge>& es)
{
	nodes.clear();
	nodes.reserve(cards.size());


	for (auto& c : cards) {
		nodes.push_back(LayoutNode{ std::move(c), 0, false, false });
	}

	edges = std::move(es);

	for (const auto& e : edges) {
		if (e.child >= 0 && e.child < (int)nodes.size())
			nodes[e.child].coveredBy++;
	}

	for (auto& node : nodes)
		if (node.coveredBy == 0)
			node.faceUp = true;
}

std::vector<int> Layout::visibleIndexes() const {
	std::vector<int> out;
	for (int i = 0; i < (int)nodes.size(); i++)
		if (!nodes[i].taken && nodes[i].coveredBy == 0)
			out.push_back(i);
	return out;
}

std::vector<Card> Layout::visibleCards() const {
	std::vector<Card> v;
	for (auto i : visibleIndexes())
		v.push_back(nodes[i].card);
	return v;
}

bool Layout::takeAtIndex(int idx) {

	if (idx < 0 || idx >= (int)nodes.size())
		return false;

	auto& n = nodes[idx];
	if (n.taken || n.coveredBy != 0)
		return false;

	n.taken = true;

	for (auto& e : edges)
		if (e.parent == idx) {
			auto& child = nodes[e.child];
			if (child.coveredBy > 0) {
				child.coveredBy--;
				if (child.coveredBy == 0)
					child.faceUp = true;
			}
		}
	return true;
}

bool Layout::empty() const {
	for (auto& n : nodes)
		if (!n.taken)
			return false;
	return true;
}