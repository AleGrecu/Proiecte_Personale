﻿module display;

import <iostream>;
import <vector>;
import <iomanip>;
import <string>;
import <random>;
import <chrono>;
import <thread>;



import player;
import layout;
import board;
import card;
import rules;

void printSeparator(char c, int count) {
	std::cout << std::string(count, c) << "\n";
}

// Helper function to get color code
static std::string getColorCode(CardColor color) {
	const std::string BROWN = "\033[38;5;94m";
	const std::string GREY = "\033[90m";
	const std::string BLUE = "\033[94m";
	const std::string YELLOW = "\033[93m";
	const std::string RED = "\033[91m";
	const std::string GREEN = "\033[92m";
	const std::string PURPLE = "\033[95m";
	const std::string RESET = "\033[0m";

	switch (color) {
	case CardColor::Brown:  return BROWN;
	case CardColor::Grey:   return GREY;
	case CardColor::Blue:   return BLUE;
	case CardColor::Yellow: return YELLOW;
	case CardColor::Red:    return RED;
	case CardColor::Green:  return GREEN;
	case CardColor::Purple: return PURPLE;
	default:                return RESET;
	}
}

// Helper function to shorten card names to exactly 6 characters
static std::string shortenCardName(const std::string& name) {
	// Special cases for better readability (all 6 characters)
	if (name == "Lumber Yard") return "LumbYd";
	if (name == "Logging Camp") return "LogCmp";
	if (name == "Clay Pool") return "ClayPl";
	if (name == "Clay Pit") return "ClayPt";
	if (name == "Quarry") return "Quarry";
	if (name == "Stone Pit") return "StonPt";
	if (name == "Glassworks") return "GlassW";
	if (name == "Press") return "Press ";
	if (name == "Guard Tower") return "GuardT";
	if (name == "Stable") return "Stable";
	if (name == "Garrison") return "Garrsn";
	if (name == "Palisade") return "Palisa";
	if (name == "Workshop") return "WorkSh";
	if (name == "Apothecary") return "Apothe";
	if (name == "Scriptorium") return "Script";
	if (name == "Pharmacist") return "Pharma";
	if (name == "Theater") return "Theatr";
	if (name == "Altar") return "Altar ";
	if (name == "Baths") return "Baths ";
	if (name == "Stone Reserve") return "StonRe";
	if (name == "Clay Reserve") return "ClayRe";
	if (name == "Wood Reserve") return "WoodRe";
	if (name == "Tavern") return "Tavern";

	// Age 2
	if (name == "Sawmill") return "SawMil";
	if (name == "Brickyard") return "BrickY";
	if (name == "Shelf Quarry") return "ShelfQ";
	if (name == "Glassblower") return "GlasBw";
	if (name == "Drying Room") return "DryRom";
	if (name == "Walls") return "Walls ";
	if (name == "Horse Breeders") return "HorsBr";
	if (name == "Barracks") return "Barrak";
	if (name == "Archery Range") return "ArchRg";
	if (name == "Parade Ground") return "Parade";
	if (name == "Courthouse") return "CourtH";
	if (name == "Statue") return "Statue";
	if (name == "Temple") return "Temple";
	if (name == "Aqueduct") return "Aquedc";
	if (name == "Rostrum") return "Rostrm";
	if (name == "Library") return "Librar";
	if (name == "Dispensary") return "Dispen";
	if (name == "School") return "School";
	if (name == "Laboratory") return "Labort";
	if (name == "Forum") return "Forum ";
	if (name == "Caravansery") return "Caravn";
	if (name == "Customs House") return "CustmH";
	if (name == "Brewery") return "Brewy ";

	// Age 3
	if (name == "Pantheon") return "Panthe";
	if (name == "Gardens") return "Garden";
	if (name == "Town Hall") return "TownHl";
	if (name == "Palace") return "Palace";
	if (name == "Senate") return "Senate";
	if (name == "Haven") return "Haven ";
	if (name == "Lighthouse") return "LightH";
	if (name == "Chamber of Commerce") return "ChamCo";
	if (name == "Arena") return "Arena ";
	if (name == "Port") return "Port  ";
	if (name == "Armory") return "Armory";
	if (name == "Pretorium") return "Pretur";
	if (name == "Fortifications") return "Fortif";
	if (name == "Siege Workshop") return "SiegeW";
	if (name == "Circus") return "Circus";
	if (name == "University") return "Univer";
	if (name == "Observatory") return "Observ";
	if (name == "Study") return "Study ";
	if (name == "Academy") return "Academ";
	if (name == "Lodge") return "Lodge ";

	// Guilds
	if (name == "Builders Guild") return "BuildG";
	if (name == "Moneylenders Guild") return "MoneyG";
	if (name == "Scientists Guild") return "ScienG";
	if (name == "Shipowners Guild") return "ShipwG";
	if (name == "Traders Guild") return "TradeG";
	if (name == "Magistrates Guild") return "MagisG";
	if (name == "Tacticians Guild") return "TactiG";

	// Default: take first 6 characters or pad with spaces
	if (name.length() >= 6) return name.substr(0, 6);
	return name + std::string(6 - name.length(), ' ');
}

void printGameState(const Player& p1, const Player& p2, int age) {
	const int WIDTH = 80;

	printSeparator('=', WIDTH);
	std::cout << "           GAME STATE - AGE " << age << "\n";
	printSeparator('=', WIDTH);

	auto printPlayerState = [&](const Player& player, const Player& opponent) {
		std::cout << "\n[" << player.getName() << "]\n";
		printSeparator('-', 70);

		std::cout << " Coins: " << player.getCoins()
			<< " | Shields: " << player.getShields()
			<< " | Victory Points: " << player.totalVictoryPoints(opponent, false) << "\n";

		const auto& production = player.getProduction();
		if (!production.empty()) {
			std::cout << " Resources: ";
			bool first = true;
			for (const auto& [resource, quantity] : production) {
				if (!first) std::cout << ", ";
				std::cout << quantity << " x ";

				switch (resource) {
				case Resources::Wood: std::cout << "Wood"; break;
				case Resources::Stone: std::cout << "Stone"; break;
				case Resources::Clay: std::cout << "Clay"; break;
				case Resources::Glass: std::cout << "Glass"; break;
				case Resources::Papyrus: std::cout << "Papyrus"; break;
				default: break;
				}
				first = false;
			}
			std::cout << "\n";
		}
		else
			std::cout << " Resources: None\n";
		const auto& science = player.getScience();
		if (!science.empty()) {
			std::cout << " Science symbols: ";
			bool first = true;
			for (const auto& [symbol, count] : science) {
				if (symbol != ScienceSymbol::None && count > 0) {
					if (!first) std::cout << ", ";
					std::cout << count << "x" << scienceSymbolToString(symbol);
					first = false;
				}
			}
			std::cout << "\n";
		}

		const auto& wonders = player.getWonders();
		if (!wonders.empty()) {
			std::cout << " Wonders (" << wonders.size() << "):\n";
			for (const auto& wonder : wonders) {
				std::cout << "    - " << wonder.name;
				if (wonder.built)
					std::cout << " [BUILT]";
				else std::cout << " [Available]";
				std::cout << "\n";
			}
		}
		else std::cout << "  Wonders: None\n";

		const auto& tokens = player.getProgressTokens();
		if (!tokens.empty()) {
			std::cout << " Progress Tokens: ";
			bool first = true;
			for (const auto& token : tokens) {
				if (!first) std::cout << ", ";
				std::cout << token.name;
				first = false;
			}
			std::cout << "\n";
		}
		std::cout << " Cards built: " << player.getBuiltCards().size() << "\n";
		printSeparator('-', 70);
		};

	printPlayerState(p1, p2);
	printPlayerState(p2, p1);
	printSeparator('=', WIDTH);
}

void printCardPyramid(const Layout& layout, Age age) {
	const int SCREEN_WIDTH = 80;
	const std::string RESET = "\033[0m";
	const std::string FACEDOWN_COLOR = "\033[38;5;240m";

	printSeparator('=', SCREEN_WIDTH);
	std::string title = "CARD LAYOUT - AGE " + std::to_string(static_cast<int>(age));
	int titlePadding = (SCREEN_WIDTH - title.length()) / 2;
	std::cout << std::string(titlePadding, ' ') << title << "\n";
	printSeparator('=', SCREEN_WIDTH);
	std::cout << "\n";

	std::vector<std::vector<int>> rows;
	if (age == Age::I) {
		rows = { {0, 1}, {2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12, 13}, {14, 15, 16, 17, 18, 19} };
	}
	else if (age == Age::II) {
		rows = { {0, 1, 2, 3, 4, 5}, {6, 7, 8, 9, 10}, {11, 12, 13, 14}, {15, 16, 17}, {18, 19} };
	}
	else {
		rows = { {0, 1}, {2, 3, 4}, {5, 6, 7, 8}, {9, 10}, {11, 12, 13, 14}, {15, 16, 17}, {18, 19} };
	}

	for (const auto& row : rows) {
		std::string line;
		int visualWidth = 0;

		for (int index : row) {
			if (static_cast<size_t>(index) < layout.nodes.size()) {
				const auto& node = layout.nodes[index];

				if (node.taken) {
					line += "[      ] ";
					visualWidth += 9;
				}
				else {
					std::string cardName = shortenCardName(node.card.name);
					std::string colorCode = getColorCode(node.card.color);

					if (node.faceUp) {
						line += "[" + colorCode + cardName + RESET + "] ";
						visualWidth += 9;
					}
					else {
						// Face-down card: show as hidden
						line += "[" + FACEDOWN_COLOR + "======" + RESET + "] ";
						visualWidth += 9;
					}
				}
			}
		}
		int padding = (SCREEN_WIDTH - visualWidth) / 2;
		if (padding > 0) {
			std::cout << std::string(padding, ' ');
		}
		std::cout << line << "\n";
	}
	std::cout << "\n";
	printSeparator('=', SCREEN_WIDTH);
	std::cout << "\n";
}

void printAvailableCards(const std::vector<std::pair<const Card*, int>>& available, const Player& currentPlayer, const Player& opponent) {
	std::cout << " >>> Available cards (" << available.size() << ")\n\n";

	if (available.empty()) {
		std::cout << " No available cards\n\n";
		return;
	}

	const std::string RESET = "\033[0m";
	const std::string BROWN = "\033[38;5;94m";
	const std::string GREY = "\033[90m";
	const std::string BLUE = "\033[94m";
	const std::string YELLOW = "\033[93m";
	const std::string RED = "\033[91m";
	const std::string GREEN = "\033[92m";
	const std::string PURPLE = "\033[95m";

	const int COL_INDEX = 4;
	const int COL_NAME = 30;
	const int COL_COST = 40;

	for (size_t i = 0; i < available.size(); ++i) {
		const Card* card = available[i].first;
		int cardIdx = available[i].second;

		std::string colorCode;
		switch (card->color) {
		case CardColor::Brown:  colorCode = BROWN; break;
		case CardColor::Grey:   colorCode = GREY; break;
		case CardColor::Blue:   colorCode = BLUE; break;
		case CardColor::Yellow: colorCode = YELLOW; break;
		case CardColor::Red:    colorCode = RED; break;
		case CardColor::Green:  colorCode = GREEN; break;
		case CardColor::Purple: colorCode = PURPLE; break;
		default:                colorCode = RESET; break;
		}

		std::cout << std::setw(COL_INDEX) << std::left << "[" + std::to_string(i) + "]";
		std::cout << colorCode << std::setw(COL_NAME) << std::left << card->name << RESET;

		auto costResult = computeBuildCardCost(currentPlayer, opponent, *card);
		std::string costDisplay;

		if (!card->chainFrom.empty()) {
			bool hasChain = false;
			for (const auto& c : currentPlayer.getBuiltCards()) {
				if (c.chainTo == card->chainFrom) {
					hasChain = true;
					break;
				}
			}

			if (hasChain) {
				costDisplay = "Free (Chain)";
			}
			else {
				if (card->cost.resources.empty() && card->cost.coins == 0) {
					costDisplay = "Free";
				}
				else if (card->cost.resources.empty()) {
					costDisplay = std::to_string(card->cost.coins) + " coins";
				}
				else {
					costDisplay = card->cost.toString();
					if (costResult.coinsNeeded > card->cost.coins) {
						int tradingCost = costResult.coinsNeeded - card->cost.coins;
						costDisplay += " (" + std::to_string(tradingCost) + " coins)";
					}
					else if (costResult.coinsNeeded == 0 && card->cost.coins == 0) {
						costDisplay += " (Free)";
					}
				}
			}
		}
		else {
			if (card->cost.resources.empty() && card->cost.coins == 0) {
				costDisplay = "Free";
			}
			else if (card->cost.resources.empty()) {
				costDisplay = std::to_string(card->cost.coins) + " coins";
			}
			else {
				costDisplay = card->cost.toString();
				if (costResult.coinsNeeded > card->cost.coins) {
					int tradingCost = costResult.coinsNeeded - card->cost.coins;
					costDisplay += " (" + std::to_string(tradingCost) + " coins)";
				}
				else if (costResult.coinsNeeded == 0 && card->cost.coins == 0) {
					costDisplay += " (Free)";
				}
			}
		}

		std::cout << std::setw(COL_COST) << std::left << "Cost: " + costDisplay;

		std::vector<std::string> effects;

		if (!card->producesResources.empty()) {
			std::string production = "Produces: ";
			bool first = true;
			for (const auto& resource : card->producesResources) {
				if (!first) production += "/";
				switch (resource) {
				case Resources::Wood: production += "Wood"; break;
				case Resources::Stone: production += "Stone"; break;
				case Resources::Clay: production += "Clay"; break;
				case Resources::Glass: production += "Glass"; break;
				case Resources::Papyrus: production += "Papyrus"; break;
				default: break;
				}
				first = false;
			}
			effects.push_back(production);
		}

		if (card->points > 0) {
			effects.push_back("VP: " + std::to_string(card->points));
		}

		if (card->shields > 0) {
			effects.push_back("Shields: " + std::to_string(card->shields));
		}

		if (card->scienceSymbol != ScienceSymbol::None) {
			effects.push_back("Science: " + scienceSymbolToString(card->scienceSymbol));
		}

		switch (card->effect) {
		case CardEffect::ProduceFlexible:
			effects.push_back("Flexible Production");
			break;

		case CardEffect::DiscountTrade: {
			std::string discount = "Trade Discount (";
			bool first = true;
			for (const auto& res : card->producesResources) {
				if (!first) discount += "/";
				switch (res) {
				case Resources::Wood: discount += "Wood"; break;
				case Resources::Stone: discount += "Stone"; break;
				case Resources::Clay: discount += "Clay"; break;
				case Resources::Glass: discount += "Glass"; break;
				case Resources::Papyrus: discount += "Papyrus"; break;
				default: break;
				}
				first = false;
			}
			discount += ")";
			effects.push_back(discount);
			break;
		}
		case CardEffect::GainCoins:
			effects.push_back("Gain Coins");
			break;
		case CardEffect::GuildVPWonders:
			effects.push_back("Guild: 2VP/Wonder");
			break;
		case CardEffect::GuildVPCoinSets:
			effects.push_back("Guild: 1VP/3Coins");
			break;
		case CardEffect::GuildVPYellow:
			effects.push_back("Guild: VP/Yellow");
			break;
		case CardEffect::GuildVPBrownGrey:
			effects.push_back("Guild: VP/Brown+Grey");
			break;
		case CardEffect::GuildVPBlue:
			effects.push_back("Guild: VP/Blue");
			break;
		case CardEffect::GuildVPGreen:
			effects.push_back("Guild: VP/Green");
			break;
		case CardEffect::GuildVPRed:
			effects.push_back("Guild: VP/Red");
			break;
		case CardEffect::None:
		case CardEffect::ProduceResource:
		case CardEffect::ScienceSymbol:
		case CardEffect::Shields:
		case CardEffect::Points:
			break;
		default:
			break;
		}

		if (!effects.empty()) {
			std::cout << "| ";
			for (size_t j = 0; j < effects.size(); ++j) {
				if (j > 0) std::cout << " | ";
				std::cout << effects[j];
			}
		}

		std::cout << "\n";
	}
	std::cout << "\n";
}

void printFinalScore(const Player& p1, const Player& p2, int totalTurns, const MilitaryTrack& track) {
	printSeparator('-', 20);
	std::cout << "     GAME FINISHED - FINAL SCORING\n";
	printSeparator('-', 20);

	int p1_score = p1.totalVictoryPoints(p2);
	int p2_score = p2.totalVictoryPoints(p1);

	int p1_milP = track.getFinalMilitaryPoints(PlayerSide::Player1);
	int p2_milP = track.getFinalMilitaryPoints(PlayerSide::Player2);

	p1_score += p1_milP;
	p2_score += p2_milP;

	std::cout << "\n" << p1.getName() << " Final Stats:\n";
	std::cout << " Victory Points: " << p1_score << "\n";
	std::cout << " Coins: " << p1.getCoins() << "\n";
	std::cout << " Shields: " << p1.getShields() << "\n";
	std::cout << " Card Built: " << p1.getBuiltCards().size() << "\n";
	std::cout << " Wonders Built: " << p1.getWonders().size() << "\n";

	std::cout << "\n" << p2.getName() << " Final Stats:\n";
	std::cout << " Victory Points: " << p2_score << "\n";
	std::cout << " Coins: " << p2.getCoins() << "\n";
	std::cout << " Shields: " << p2.getShields() << "\n";
	std::cout << "Cards Built: " << p2.getBuiltCards().size() << "\n";
	std::cout << "Wonders Built: " << p2.getWonders().size() << "\n";

	printSeparator('-', 20);
	if (p1_score > p2_score)
		std::cout << "Winner: " << p1.getName() << " with " << p1_score << " points!\n";
	else if (p2_score > p1_score)
		std::cout << "Winner: " << p2.getName() << " with " << p2_score << " points!\n";
	else
		std::cout << "Tied Game! Both players have " << p1_score << " points!\n";

	printSeparator('-', 20);
	std::cout << "\nGame Statistics\n";
	std::cout << "Total Turns: " << totalTurns << "\n\n";
}

void printMilitaryTrack(const MilitaryTrack& track, const Player& p1, const Player& p2) {
	const int WIDTH = 75;
	std::cout << "\n";
	printSeparator('=', WIDTH);

	std::string title = "MILITARY TRACK";
	int titlePadding = (WIDTH - title.length()) / 2;
	std::cout << std::string(titlePadding, ' ') << title << "\n";
	printSeparator('=', WIDTH);

	std::cout << " " << std::setw(8) << std::left << p2.getName() << " ";
	int position = track.getPosition();

	for (int i = -9; i <= 9; i++) {
		if (i == position)
			std::cout << "[*]";
		else if (i == 0)
			std::cout << " | ";
		else if (i == -9 || i == 9)
			std::cout << "[X]";
		else if (i % 3 == 0)
			std::cout << " - ";
		else
			std::cout << " . ";
	}

	std::cout << " " << std::setw(8) << std::right << p1.getName() << "\n";
	std::cout << "           ";
	for (int i = -9; i <= 9; i++) {
		if (i == -9 || i == 9 || i == 0 || i % 3 == 0) {
			std::string numStr = std::to_string(i);
			if (numStr.length() == 1)
				std::cout << " " << numStr << " ";
			else if (numStr.length() == 2)
				std::cout << numStr << " ";
			else
				std::cout << numStr;
		}
		else std::cout << "   ";
	}
	std::cout << "\n";

	std::cout << " Position: " << std::setw(3) << std::right << position << " ";
	if (position < 0)
		std::cout << "(" << p1.getName() << " advantage + " << (-position) << ")";
	else if (position > 0)
		std::cout << "(" << p2.getName() << " advantage + " << position << ")";
	std::cout << "\n";

	int p1Shields = p1.getShields();
	int p2Shields = p2.getShields();

	std::cout << " Shields: " << std::setw(8)
		<< std::left << p2.getName() << ": " << std::setw(2) << p2Shields << " "
		<< " | "
		<< std::setw(8) << std::left << p1.getName() << ": " << std::setw(2) << p1Shields << "\n";

	printSeparator('=', WIDTH);
}

void printProgressTokens(const std::vector<ProgressToken>& tokens) {
	if (tokens.empty()) return;

	const int WIDTH = 75;
	std::cout << "\n";

	std::string tokensRow = "";
	for (const auto& token : tokens) {
		tokensRow += "[" + token.name + "]  ";
	}

	int padding = (WIDTH - (int)tokensRow.length()) / 2;
	if (padding > 0) std::cout << std::string(padding, ' ');

	std::cout << tokensRow << "\n";

	if (padding > 0) std::cout << std::string(padding, ' ');
	std::cout << std::string(tokensRow.length() - 2, '-') << "\n";
}

void printPlayerWonders(const Player& player, const Player& opponent) {
	const int WIDTH = 60;

	printSeparator('=', WIDTH);
	std::cout << player.getName() << "'s Wonders\n";
	printSeparator('=', WIDTH);

	const auto& wonders = player.getWonders();
	if (wonders.empty()) {
		std::cout << " No wonders available.\n";
		printSeparator('=', WIDTH);
		return;
	}

	for (size_t i = 0; i < wonders.size(); ++i) {
		const auto& wonder = wonders[i];

		std::cout << " [" << i << "] " << wonder.name;
		if (wonder.built) {
			std::cout << " [BUILT]\n";
			printSeparator('-', WIDTH);
			continue;
		}
		std::cout << " [Available]\n";

		int totalCoinCost = wonder.cost.coins;
		std::map<Resources, int> needed = wonder.cost.resources;

		for (auto& [res, qty] : needed) {
			int have = player.countResource(res);
			qty -= std::min(have, qty);
		}

		for (auto it = needed.begin(); it != needed.end(); ) {
			if (it->second <= 0)
				it = needed.erase(it);
			else
				++it;
		}

		for (const auto& [res, qty] : needed) {
			int baseCost = 2;
			int opponentProduction = 0;

			for (const auto& c : opponent.getBuiltCards())
				if (c.color == CardColor::Brown || c.color == CardColor::Grey)
					for (auto r : c.producesResources)
						if (r == res)
							opponentProduction++;

			bool hasDiscount = false;
			for (const auto& c : player.getBuiltCards()) {
				if (c.effect == CardEffect::DiscountTrade) {
					for (auto r : c.producesResources) {
						if (r == res) {
							hasDiscount = true;
							break;
						}
					}
				}
				if (hasDiscount) break;
			}

			int pricePerUnit = hasDiscount ? 1 : (baseCost + opponentProduction);
			totalCoinCost += qty * pricePerUnit;
		}

		std::cout << "     Total Cost: " << totalCoinCost << " coins\n";

		std::cout << "     Resources: ";
		if (!wonder.cost.resources.empty()) {
			bool first = true;
			for (const auto& [res, qty] : wonder.cost.resources) {
				if (!first) std::cout << ", ";
				std::cout << qty << "x";
				switch (res) {
				case Resources::Wood: std::cout << "Wood"; break;
				case Resources::Stone: std::cout << "Stone"; break;
				case Resources::Clay: std::cout << "Clay"; break;
				case Resources::Glass: std::cout << "Glass"; break;
				case Resources::Papyrus: std::cout << "Papyrus"; break;
				default: break;
				}
				first = false;
			}
			std::cout << "\n";
		}
		else {
			std::cout << "None\n";
		}
	}

	printSeparator('=', WIDTH);
}

int getPlayerChoice(int maxValidChoice) {
	int choice = -1;
	std::cout << "Enter your choice (0 to " << maxValidChoice - 1 << "): ";
	while (true) {
		std::cin >> choice;
		if (std::cin.good() && choice >= 0 && choice < maxValidChoice) {
			break;
		}
		std::cin.clear();
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		std::cout << "Invalid choice. Please enter a number between 0 and " << maxValidChoice - 1 << ": ";
	}
	return choice;
}

int simulateDiceToss(const std::string& playerName) {
	std::random_device rd;
	std::mt19937 gen(rd());
	std::uniform_int_distribution<> dist(1, 6);

	std::cout << "\n";
	printSeparator('*', 50);
	std::cout << "    " << playerName << " is rolling the dice...\n";
	printSeparator('*', 50);

	std::cout << "\nRolling";
	for (int i = 0; i < 3; ++i) {
		std::cout << ".";
		std::cout.flush();
		std::this_thread::sleep_for(std::chrono::milliseconds(400));
	}
	std::cout << "\n\n";

	int result = dist(gen);

	printSeparator('=', 40);
	std::cout << "        " << playerName << " rolled a " << result << "!\n";
	printSeparator('=', 40);
	std::cout << "\n";

	return result;
}