﻿#include <iostream>
#include <vector>
#include <string>
#include <random>
#include <chrono>
#include <algorithm>
#include <utility> 
#include <limits>

import board;
import player;
import rules;
import display;
import card;
import age1_cards;
import age2_cards;
import age3_cards;
import guild_cards;
import layouts_data; 
import layout; 
import progress; 
import game;
import wonder;
import game_enums;

void markFaceUpCards(Layout& layout, Age age) {
	if (age == Age::I) {
		std::vector<int> faceUpIndices = { 0, 1, 5, 6, 7, 8, 14, 15, 16, 17, 18, 19 };
		for (int idx : faceUpIndices) {
			if (idx < static_cast<int>(layout.nodes.size())) {
				layout.nodes[idx].faceUp = true;
			}
		}
	}
	else if (age == Age::II) {
		std::vector<int> faceUpIndices = { 0, 1, 2, 3, 4, 5, 11, 12, 13, 14, 18, 19 };
		for (int idx : faceUpIndices) {
			if (idx < static_cast<int>(layout.nodes.size())) {
				layout.nodes[idx].faceUp = true;
			}
		}
	}
	else if (age == Age::III) {
		std::vector<int> faceUpIndices = { 0, 1, 5, 6, 7, 8, 11, 12, 13, 14, 18, 19 };
		for (int idx : faceUpIndices) {
			if (idx < static_cast<int>(layout.nodes.size())) {
				layout.nodes[idx].faceUp = true;
			}
		}
	}
}

void setupBoardForAge(Board& board, Age age, const std::vector<Card>& ageDeck) {

	if (age == Age::I) {
		board.layout.buildFrom(ageDeck, getEdgesAge1());
	}
	else if (age == Age::II) {
		board.layout.buildFrom(ageDeck, getEdgesAge2());
	}
	else {
		board.layout.buildFrom(ageDeck, getEdgesAge3());
	}

	markFaceUpCards(board.layout, age);
	board.setAge(age);
}

void handlePlayerTurn(Board& board, Player& currentP, Player& opponentP, MilitaryTrack& militaryTrack, PlayerSide currentSide) {
	printSeparator('-', 50);
	std::cout << "Turn - " << currentP.getName() << "'s turn\n";

	auto available = board.availableBoardCards();
	if (available.empty()) {
		std::cout << "No cards available to play.\n";
		return;
	}

	while (true) {
		std::cout << "\n";
		printAvailableCards(available, currentP, opponentP);
		std::cout << "Choose a card to take (0-" << static_cast<int>(available.size()) - 1 << "): \n";
		int cardChoiceIdx = getPlayerChoice(static_cast<int>(available.size()));
		const auto& chosenPair = available[cardChoiceIdx];
		const Card& chosenCard = *chosenPair.first;

		std::cout << "\nYou chose: " << chosenCard.name << "\n";

		while (true) {
			std::cout << "\nChoose an action:\n";
			std::cout << " [0] Build the Card\n";
			std::cout << " [1] Discard for coins\n";
			std::cout << " [2] Build a Wonder\n";
			std::cout << " [3] Go back to card selection\n";
			int actionChoice = getPlayerChoice(4);

			if (actionChoice == 3) {
				std::cout << "Returning to card selection...\n";
				break;
			}

			ActionOutcome outcome;
			bool actionCompleted = false;

			if (actionChoice == 0) {
				std::cout << "\n=== BUILD CARD ===\n";
				std::cout << "Confirm build " << chosenCard.name << "?\n";
				std::cout << " [0] Yes, build it\n";
				std::cout << " [1] No, go back to action menu\n";
				int confirm = getPlayerChoice(2);

				if (confirm == 1) {
					std::cout << "Build cancelled. Returning to action menu...\n";
					continue;
				}

				outcome = executeBuildCard(currentP, opponentP, chosenCard);
				if (outcome.success) {
					board.takeCard(cardChoiceIdx);

					if (chosenCard.scienceSymbol != ScienceSymbol::None &&
						currentP.countSymbol(chosenCard.scienceSymbol) == 2) {
						std::cout << "\nYou collected two matching science symbols and can now choose a progress token\n";
						currentP.selectProgressToken(board.tokensPool);
					}

					if (chosenCard.color == CardColor::Red && chosenCard.shields > 0) {
						militaryTrack.addShield(currentSide, chosenCard.shields,
							(currentSide == PlayerSide::Player1 ? currentP : opponentP),
							(currentSide == PlayerSide::Player1 ? opponentP : currentP));
					}
					actionCompleted = true;
				}
				std::cout << "-> " << outcome.message << "\n";
			}

			else if (actionChoice == 1) {
				std::cout << "\n=== DISCARD CARD ===\n";
				int yellowCards = currentP.countCardsOfColor(CardColor::Yellow);
				int coinsToGain = 2 + yellowCards;
				std::cout << "You will gain " << coinsToGain << " coins (2 base + " << yellowCards << " yellow cards)\n";
				std::cout << "Confirm discard " << chosenCard.name << "?\n";
				std::cout << " [0] Yes, discard it\n";
				std::cout << " [1] No, go back to action menu\n";
				int confirm = getPlayerChoice(2);

				if (confirm == 1) {
					std::cout << "Discard cancelled. Returning to action menu...\n";
					continue;
				}

				outcome = executeDiscardCard(currentP, opponentP, chosenCard, board);
				if (outcome.success) {
					board.takeCard(cardChoiceIdx);
					actionCompleted = true;
				}
				std::cout << "-> " << outcome.message << "\n";
			}

			else if (actionChoice == 2) {
				std::cout << "\n=== BUILD WONDER ===\n";

				while (true) {
					printPlayerWonders(currentP, opponentP);
					auto& wonders = currentP.getWonders();

					if (wonders.empty() || std::all_of(wonders.begin(), wonders.end(),
						[](const Wonder& w) { return w.built; })) {
						outcome.message = "No wonders available to build.";
						std::cout << outcome.message << "\n";
						break;
					}

					std::cout << "Choose a wonder to build (0-" << static_cast<int>(wonders.size()) - 1
						<< "), or " << wonders.size() << " to go back to action menu:\n";
					int wonderChoiceIdx = getPlayerChoice(static_cast<int>(wonders.size()) + 1);

					if (wonderChoiceIdx == static_cast<int>(wonders.size())) {
						std::cout << "Wonder construction cancelled. Returning to action menu...\n";
						break;
					}

					if (wonders[wonderChoiceIdx].built) {
						std::cout << "This wonder is already built. Try another one.\n\n";
						continue;
					}

					std::cout << "\nConfirm build " << wonders[wonderChoiceIdx].name << "?\n";
					std::cout << " [0] Yes, build it\n";
					std::cout << " [1] No, choose another wonder\n";
					int confirm = getPlayerChoice(2);

					if (confirm == 1) {
						std::cout << "Build cancelled. Choose another wonder...\n\n";
						continue;
					}

					outcome = executeBuildWonder(currentP, opponentP,
						wonders[wonderChoiceIdx], chosenCard, board);

					if (outcome.success) {
						board.takeCard(cardChoiceIdx);

						if (outcome.shieldsGained > 0)
							militaryTrack.addShield(currentSide, outcome.shieldsGained,
								(currentSide == PlayerSide::Player1 ? currentP : opponentP),
								(currentSide == PlayerSide::Player1 ? opponentP : currentP));

						actionCompleted = true;
					}

					std::cout << "-> " << outcome.message << "\n";
					break;
				}
			}
			if (actionCompleted) return;

			if (actionChoice == 2 && !outcome.success) continue;

		}
	}
}

int main() {

	GameMode gameMode = selectGameMode();

	std::string player1Name, player2Name;
	getPlayerNames(gameMode, player1Name, player2Name);

	Player p1(player1Name), p2(player2Name);

	PlayerSide firstPlayer = selectFirstPlayer(gameMode, player1Name, player2Name);

	wonderSelectionPhase(p1, p2, player1Name, player2Name, firstPlayer);

	std::vector<Card> age1Deck = prepareAgeDeck(1);
	std::vector<Card> age2Deck = prepareAgeDeck(2);
	std::vector<Card> age3Deck = prepareAgeDeck(3);

	std::cout << "Press Enter to start the game...";
	std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	std::cin.get();

	Board board;
	MilitaryTrack militaryTrack;

	std::vector<ProgressToken>allTokens = getAllProgressTokens();
	std::mt19937 rng(static_cast<unsigned>(std::chrono::steady_clock::now().time_since_epoch().count()));
	std::shuffle(allTokens.begin(), allTokens.end(), rng);

	for (int i = 0; i < 5 && i < static_cast<int>(allTokens.size()); ++i) {
		board.tokensPool.push_back(allTokens[i]);
	}

	PlayerSide current = firstPlayer;
	int turnCount = 0;
	bool gameEnded = false;

	printSeparator('=', 50);
	std::cout << "        7 WONDERS DUEL \n";
	printSeparator('=', 50);

	for (int ageNum = 1; ageNum <= 3 && !gameEnded; ++ageNum) {
		Age currentAge = static_cast<Age>(ageNum);

		const std::vector<Card>* currentDeck = nullptr;

		if (ageNum == 1)currentDeck = &age1Deck;
		else if (ageNum == 2)currentDeck = &age2Deck;
		else currentDeck = &age3Deck;

		setupBoardForAge(board, currentAge, *currentDeck);

		printSeparator('*', 50);
		std::cout << "          STARTING AGE " << ageNum << " ***\n";
		printSeparator('*', 50);

		while (!board.finishedAge() && !gameEnded) {
			turnCount++;

			Player& currentP = (current == PlayerSide::Player1) ? p1 : p2;
			Player& opponentP = (current == PlayerSide::Player1) ? p2 : p1;

			printGameState(p1, p2, ageNum);
			printProgressTokens(board.tokensPool);
			printMilitaryTrack(militaryTrack, p1, p2);
			printCardPyramid(board.layout, currentAge);

			handlePlayerTurn(board, currentP, opponentP, militaryTrack, current);

			if (auto winner = checkImmediateVictory(p1, p2)) {
				gameEnded = true;
				std::string victoryType = p1.hasScienceVictory() || p2.hasScienceVictory() ? "SCIENTIFIC" : "MILITARY";
				std::cout << "\n!!! IMMEDIATE " << victoryType << " VICTORY FOR " << ((*winner == PlayerSide::Player1) ? p1.getName() : p2.getName()) << " !!!\n";
				break;
			}
			current = (current == PlayerSide::Player1) ? PlayerSide::Player2 : PlayerSide::Player1;
		}
	}

	if (!gameEnded)
		printFinalScore(p1, p2, turnCount, militaryTrack);

	return 0;
}