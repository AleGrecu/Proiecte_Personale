
// file: `src/main/java/org/example/websocket/NotificationHandler.java`
package org.example.websocket;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class NotificationHandler {

    private final SimpMessagingTemplate messagingTemplate;

    public void sendToUser(Long userId, Object payload) {
        Map<String, Object> message = new HashMap<>();
        message.put("type", "notification");
        message.put("payload", payload);

        String destination = "/topic/user/" + userId;
        messagingTemplate.convertAndSend(destination, message);

        log.info("Sent notification to user {} at destination {}", userId, destination);
    }

    public void broadcast(Object payload) {
        Map<String, Object> message = new HashMap<>();
        message.put("type", "broadcast");
        message.put("payload", payload);

        messagingTemplate.convertAndSend("/topic/notifications", message);

        log.info("Broadcast notification sent");
    }
}
