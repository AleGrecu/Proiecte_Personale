package org.example.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtTokenProvider jwtTokenProvider;

    @Override
    protected void doFilterInternal(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain) throws ServletException, IOException {

        try {
            String jwt = getJwtFromRequest(request);

            if (StringUtils.hasText(jwt) && jwtTokenProvider.validateToken(jwt)) {
                String email = jwtTokenProvider.getEmailFromToken(jwt);
                String role = jwtTokenProvider.getRoleFromToken(jwt);
                Long userId = jwtTokenProvider.getUserIdFromToken(jwt);

                // Asigurăm formatul corect pentru rol (Spring cere prefixul ROLE_)
                String roleName = role.startsWith("ROLE_") ? role : "ROLE_" + role;

                // Creăm autoritatea
                SimpleGrantedAuthority authority = new SimpleGrantedAuthority(roleName);

                // Construim un UserDetails care să conțină și ID-ul (opțional, dar util)
                // Aici folosim implementarea standard User din Spring,
                // dar username-ul este email-ul.
                UserDetails userDetails = new User(email, "", Collections.singletonList(authority));

                // NOTĂ: Dacă vrei să accesezi userId-ul mai târziu în controller,
                // ar trebui să folosești o clasă custom UserPrincipal în loc de 'User'.
                // Momentan, userId-ul extras este doar o variabilă locală.

                UsernamePasswordAuthenticationToken authentication =
                        new UsernamePasswordAuthenticationToken(
                                userDetails,
                                null,
                                userDetails.getAuthorities()
                        );

                authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                SecurityContextHolder.getContext().setAuthentication(authentication);

                log.debug("Set authentication for user: {}, role: {}", email, role);
            }
        } catch (Exception ex) {
            // Este important să nu oprim request-ul aici. Doar logăm eroarea.
            // Dacă autentificarea eșuează, utilizatorul rămâne "anonim",
            // iar SecurityConfig va decide dacă îi dă 403 sau nu.
            log.error("Could not set user authentication in security context", ex);
        }

        filterChain.doFilter(request, response);
    }

    /**
     * OPTIMIZARE CRITICĂ:
     * Această metodă spune filtrului să NU ruleze pe endpoint-urile publice.
     * Rezolvă potențiale conflicte cu Actuator și crește performanța.
     */
    @Override
    protected boolean shouldNotFilter(@NonNull HttpServletRequest request) {
        String path = request.getServletPath();
        return path.startsWith("/api/auth/") ||
                path.startsWith("/actuator/") ||
                path.startsWith("/swagger-ui") ||
                path.startsWith("/v3/api-docs");
    }

    private String getJwtFromRequest(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }
        return null;
    }
}