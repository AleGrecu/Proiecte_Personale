package org.example.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.dto.QRGenerateRequest;
import org.example.model.Bar;
import org.example.model.Transaction;
import org.example.model.User;
import org.example.repository.BarRepository;
import org.example.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class QRService {

    private final TransactionRepository transactionRepository;
    private final BarRepository barRepository;
    private final UserContextService userContextService;
    private final WebClient.Builder webClientBuilder;

    @Value("${qr-service.url}")
    private String qrServiceUrl;

    @Value("${qr-service.secret}")
    private String qrServiceSecret;

    @Transactional
    public Map<String, Object> generateQRCode(QRGenerateRequest request) {
        log.info("Generating QR code for bar {} with amount {}", request.getBarId(), request.getAmount());

        // Get authenticated user
        User currentUser = userContextService.getCurrentUser();

        // Validate bar exists
        Bar bar = barRepository.findById(request.getBarId())
                .orElseThrow(() -> new RuntimeException("Bar not found with id: " + request.getBarId()));

        if (!bar.getActive()) {
            throw new RuntimeException("Bar is not active");
        }

        // Calculate points (1 point per 1 RON)
        Integer points = request.getAmount().intValue();

        // Generate unique QR hash
        String qrCodeHash = generateQRHash(currentUser.getId(), bar.getId(), request.getAmount());

        // Create pending transaction
        Transaction transaction = Transaction.builder()
                .user(currentUser)
                .bar(bar)
                .amount(request.getAmount().doubleValue())
                .points(points)
                .timestamp(LocalDateTime.now())
                .qrCodeHash(qrCodeHash)
                .status("PENDING")
                .build();

        transaction = transactionRepository.save(transaction);

        // Call QR Service to generate QR code image
        String qrCodeImage = callQRServiceToGenerateImage(qrCodeHash);

        // Build response
        Map<String, Object> response = new HashMap<>();
        response.put("qrCodeHash", qrCodeHash);
        response.put("qrCodeImage", qrCodeImage);
        response.put("transactionId", transaction.getId());
        response.put("amount", request.getAmount());
        response.put("points", points);
        response.put("barName", bar.getName());
        response.put("expiresAt", LocalDateTime.now().plusMinutes(15)
                .format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));

        log.info("QR code generated successfully. Transaction ID: {}", transaction.getId());
        return response;
    }

    private String generateQRHash(Long userId, Long barId, java.math.BigDecimal amount) {
        try {
            String data = String.format("%d-%d-%s-%s-%s",
                    userId, barId, amount.toString(),
                    UUID.randomUUID().toString(),
                    System.currentTimeMillis());

            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data.getBytes(StandardCharsets.UTF_8));

            return Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            log.error("Error generating QR hash", e);
            throw new RuntimeException("Failed to generate QR hash", e);
        }
    }

    private String callQRServiceToGenerateImage(String qrCodeHash) {
        try {
            WebClient webClient = webClientBuilder
                    .baseUrl(qrServiceUrl)
                    .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                    .defaultHeader("X-QR-Service-Secret", qrServiceSecret)
                    .build();

            Map<String, String> requestBody = new HashMap<>();
            requestBody.put("data", qrCodeHash);

            Map<String, String> response = webClient.post()
                    .uri("/api/qr/generate")
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            if (response != null && response.containsKey("qrCodeImage")) {
                return response.get("qrCodeImage");
            }

            throw new RuntimeException("Failed to generate QR code image");

        } catch (Exception e) {
            log.error("Error calling QR service", e);
            // Return a placeholder or throw exception
            throw new RuntimeException("QR service temporarily unavailable", e);
        }
    }

    private User getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new RuntimeException("User not authenticated");
        }

        // This is a simplified version. In production, you'd fetch the user from the database
        // based on the authentication principal (email)
        String email = authentication.getName();
        log.debug("Current authenticated user: {}", email);

        // For now, we'll create a mock user. You should inject UserRepository and fetch the real user
        return User.builder()
                .id(1L) // This should be fetched from database
                .email(email)
                .build();
    }
}
