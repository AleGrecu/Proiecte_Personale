package org.example.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.model.Bar;
import org.example.model.Reward;
import org.example.model.RewardRedemption;
import org.example.model.User;
import org.example.repository.BarRepository;
import org.example.repository.RewardRedemptionRepository;
import org.example.repository.RewardRepository;
import org.example.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class RewardService {

    private final RewardRepository rewardRepository;
    private final RewardRedemptionRepository redemptionRepository;
    private final UserRepository userRepository;
    private final BarRepository barRepository;
    private final UserContextService userContextService;
    private final WebSocketService webSocketService;

    public List<Reward> getAllActiveRewards() {
        log.info("Fetching all active rewards");
        return rewardRepository.findByActiveTrueOrderByPointsCostAsc();
    }

    public List<Reward> getRewardsByBar(Long barId) {
        log.info("Fetching rewards for bar: {}", barId);

        // Validate bar exists
        Bar bar = barRepository.findById(barId)
                .orElseThrow(() -> new RuntimeException("Bar not found with id: " + barId));

        return rewardRepository.findByBarIdAndActiveTrue(barId);
    }

    public Reward getRewardById(Long id) {
        log.info("Fetching reward with id: {}", id);
        return rewardRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Reward not found with id: " + id));
    }

    @Transactional
    public RewardRedemption redeemReward(Long rewardId) {
        log.info("Redeeming reward with id: {}", rewardId);

        // Get current user
        User currentUser = userContextService.getCurrentUser();

        // Get reward
        Reward reward = getRewardById(rewardId);

        if (!reward.getActive()) {
            throw new RuntimeException("Reward is not active");
        }

        // Check if user has enough points
        if (currentUser.getPoints() < reward.getPointsCost()) {
            throw new RuntimeException(String.format(
                    "Insufficient points. Required: %d, Available: %d",
                    reward.getPointsCost(), currentUser.getPoints()
            ));
        }

        // Deduct points from user
        Integer oldPoints = currentUser.getPoints();
        Integer newPoints = oldPoints - reward.getPointsCost();
        currentUser.setPoints(newPoints);
        userRepository.save(currentUser);

        // Create redemption record
        RewardRedemption redemption = new RewardRedemption();
        redemption.setUserId(currentUser.getId());
        redemption.setRewardId(reward.getId());
        redemption.setPointsSpent(reward.getPointsCost());
        redemption.setRedeemedAt(LocalDateTime.now());

        redemption = redemptionRepository.save(redemption);

        // Send WebSocket notification
        webSocketService.sendPointsUpdate(
                currentUser.getId(),
                oldPoints,
                newPoints,
                "REWARD_REDEMPTION"
        );

        webSocketService.sendRewardRedeemed(
                currentUser.getId(),
                reward.getId(),
                reward.getName(),
                reward.getPointsCost()
        );

        log.info("Reward {} redeemed successfully by user {}. Points spent: {}",
                reward.getName(), currentUser.getId(), reward.getPointsCost());

        return redemption;
    }

    public List<RewardRedemption> getUserRedemptions() {
        User currentUser = userContextService.getCurrentUser();
        log.info("Fetching redemption history for user: {}", currentUser.getId());
        return redemptionRepository.findByUserIdOrderByRedeemedAtDesc(currentUser.getId());
    }

    public List<RewardRedemption> getRedemptionsByUserId(Long userId) {
        log.info("Fetching redemption history for user id: {}", userId);
        return redemptionRepository.findByUserIdOrderByRedeemedAtDesc(userId);
    }

    @Transactional
    public Reward createReward(Reward reward) {
        log.info("Creating new reward: {}", reward.getName());

        // Validate bar exists
        if (reward.getBar() != null && reward.getBar().getId() != null) {
            barRepository.findById(reward.getBar().getId())
                    .orElseThrow(() -> new RuntimeException("Bar not found"));
        }

        reward.setActive(true);
        return rewardRepository.save(reward);
    }

    @Transactional
    public Reward updateReward(Long id, Reward rewardDetails) {
        log.info("Updating reward with id: {}", id);
        Reward reward = getRewardById(id);

        reward.setName(rewardDetails.getName());
        reward.setDescription(rewardDetails.getDescription());
        reward.setPointsCost(rewardDetails.getPointsCost());
        reward.setActive(rewardDetails.getActive());

        if (rewardDetails.getBar() != null && rewardDetails.getBar().getId() != null) {
            Bar bar = barRepository.findById(rewardDetails.getBar().getId())
                    .orElseThrow(() -> new RuntimeException("Bar not found"));
            reward.setBar(bar);
        }

        return rewardRepository.save(reward);
    }

    @Transactional
    public void deleteReward(Long id) {
        log.info("Deactivating reward with id: {}", id);
        Reward reward = getRewardById(id);
        reward.setActive(false);
        rewardRepository.save(reward);
    }

    public Long getTotalRedemptionsCount() {
        return redemptionRepository.count();
    }

    public List<RewardRedemption> getAllRedemptions() {
        return redemptionRepository.findAll();
    }
}
