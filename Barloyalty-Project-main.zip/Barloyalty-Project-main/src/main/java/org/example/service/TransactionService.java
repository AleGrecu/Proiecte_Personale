package org.example.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.model.Transaction;
import org.example.model.User;
import org.example.repository.TransactionRepository;
import org.example.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class TransactionService {

    private final TransactionRepository transactionRepository;
    private final UserRepository userRepository;
    private final UserContextService userContextService;
    private final WebSocketService webSocketService;

    public List<Transaction> getUserTransactions() {
        User currentUser = userContextService.getCurrentUser();
        log.info("Fetching transactions for user: {}", currentUser.getId());
        return transactionRepository.findByUserOrderByTimestampDesc(currentUser);
    }

    public Transaction getTransactionById(Long id) {
        log.info("Fetching transaction with id: {}", id);
        Transaction transaction = transactionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Transaction not found with id: " + id));

        // Verify that the transaction belongs to the current user
        User currentUser = userContextService.getCurrentUser();
        if (!transaction.getUser().getId().equals(currentUser.getId())) {
            throw new RuntimeException("Unauthorized access to transaction");
        }

        return transaction;
    }

    @Transactional
    public void validateTransaction(String qrCodeHash) {
        log.info("Validating transaction with QR hash: {}", qrCodeHash);

        Transaction transaction = transactionRepository.findByQrCodeHash(qrCodeHash)
                .orElseThrow(() -> new RuntimeException("Transaction not found with QR code"));

        if (!"PENDING".equals(transaction.getStatus())) {
            throw new RuntimeException("Transaction is not in PENDING status");
        }

        // Check if transaction is not expired (15 minutes)
        LocalDateTime expirationTime = transaction.getTimestamp().plusMinutes(15);
        if (LocalDateTime.now().isAfter(expirationTime)) {
            transaction.setStatus("FAILED");
            transactionRepository.save(transaction);
            throw new RuntimeException("Transaction has expired");
        }

        // Update transaction status
        transaction.setStatus("COMPLETED");
        transactionRepository.save(transaction);

        // Update user points
        User user = transaction.getUser();
        Integer oldPoints = user.getPoints();
        Integer newPoints = oldPoints + transaction.getPoints();
        user.setPoints(newPoints);
        userRepository.save(user);

        // Send WebSocket notification
        webSocketService.sendPointsUpdate(
                user.getId(),
                oldPoints,
                newPoints,
                "TRANSACTION"
        );

        webSocketService.sendTransactionCompleted(
                user.getId(),
                transaction.getId(),
                transaction.getPoints()
        );

        log.info("Transaction validated successfully. User {} earned {} points",
                user.getId(), transaction.getPoints());
    }

    @Transactional
    public Transaction createTransaction(Transaction transaction) {
        log.info("Creating new transaction for user: {}", transaction.getUser().getId());
        transaction.setTimestamp(LocalDateTime.now());
        transaction.setStatus("PENDING");
        return transactionRepository.save(transaction);
    }

    public List<Transaction> getTransactionsByUserId(Long userId) {
        log.info("Fetching transactions for user id: {}", userId);
        return transactionRepository.findByUserIdOrderByTimestampDesc(userId);
    }

    @Transactional
    public void failTransaction(String qrCodeHash, String reason) {
        log.warn("Failing transaction with QR hash: {} - Reason: {}", qrCodeHash, reason);

        Transaction transaction = transactionRepository.findByQrCodeHash(qrCodeHash)
                .orElseThrow(() -> new RuntimeException("Transaction not found"));

        transaction.setStatus("FAILED");
        transactionRepository.save(transaction);
    }

    public Long getTotalTransactionsCount() {
        return transactionRepository.count();
    }

    public List<Transaction> getAllTransactions() {
        return transactionRepository.findAll();
    }
}
