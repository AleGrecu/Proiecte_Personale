package org.example.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.dto.PointsUpdateMessage;
import org.example.dto.WebSocketMessage;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class WebSocketService {

    private final SimpMessagingTemplate messagingTemplate;

    public void sendPointsUpdate(Long userId, Integer oldPoints, Integer newPoints, String reason) {
        PointsUpdateMessage pointsUpdate = PointsUpdateMessage.builder()
                .userId(userId)
                .oldPoints(oldPoints)
                .newPoints(newPoints)
                .pointsChange(newPoints - oldPoints)
                .reason(reason)
                .build();

        WebSocketMessage message = WebSocketMessage.builder()
                .type("POINTS_UPDATE")
                .message("Your points have been updated")
                .data(pointsUpdate)
                .timestamp(LocalDateTime.now())
                .build();

        // Send to specific user
        messagingTemplate.convertAndSendToUser(
                userId.toString(),
                "/queue/points",
                message
        );

        log.info("Sent points update to user {}: {} -> {}", userId, oldPoints, newPoints);
    }

    public void sendTransactionCompleted(Long userId, Long transactionId, Integer pointsEarned) {
        WebSocketMessage message = WebSocketMessage.builder()
                .type("TRANSACTION_COMPLETED")
                .message("Transaction completed successfully")
                .data(new TransactionCompletedData(transactionId, pointsEarned))
                .timestamp(LocalDateTime.now())
                .build();

        messagingTemplate.convertAndSendToUser(
                userId.toString(),
                "/queue/transactions",
                message
        );

        log.info("Sent transaction completed notification to user {}", userId);
    }

    public void sendRewardRedeemed(Long userId, String rewardName, Integer pointsSpent) {
        WebSocketMessage message = WebSocketMessage.builder()
                .type("REWARD_REDEEMED")
                .message("Reward redeemed successfully")
                .data(new RewardRedeemedData(rewardName, pointsSpent))
                .timestamp(LocalDateTime.now())
                .build();

        messagingTemplate.convertAndSendToUser(
                userId.toString(),
                "/queue/rewards",
                message
        );

        log.info("Sent reward redemption notification to user {}", userId);
    }

    @lombok.Data
    @lombok.AllArgsConstructor
    private static class TransactionCompletedData {
        private Long transactionId;
        private Integer pointsEarned;
    }

    @lombok.Data
    @lombok.AllArgsConstructor
    private static class RewardRedeemedData {
        private String rewardName;
        private Integer pointsSpent;
    }

    public void sendRewardRedeemed(Long userId, Long rewardId, String rewardName, Integer pointsSpent) {
        Map<String, Object> message = new HashMap<>();
        message.put("type", "REWARD_REDEEMED");
        message.put("userId", userId);
        message.put("rewardId", rewardId);
        message.put("rewardName", rewardName);
        message.put("pointsSpent", pointsSpent);
        message.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));

        log.info("Sending reward redemption notification to user {}: {} (-{} points)",
                userId, rewardName, pointsSpent);

        messagingTemplate.convertAndSendToUser(
                userId.toString(),
                "/queue/rewards",
                message
        );
    }

}
