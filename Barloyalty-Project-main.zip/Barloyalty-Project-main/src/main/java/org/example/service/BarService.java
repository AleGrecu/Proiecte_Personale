package org.example.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.model.Bar;
import org.example.repository.BarRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class BarService {

    private final BarRepository barRepository;

    public List<Bar> getAllActiveBars() {
        log.info("Fetching all active bars");
        return barRepository.findByActiveTrue();
    }

    public Bar getBarById(Long id) {
        log.info("Fetching bar with id: {}", id);
        return barRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Bar not found with id: " + id));
    }

    @Transactional
    public Bar createBar(Bar bar) {
        log.info("Creating new bar: {}", bar.getName());
        bar.setActive(true);
        return barRepository.save(bar);
    }

    @Transactional
    public Bar updateBar(Long id, Bar barDetails) {
        log.info("Updating bar with id: {}", id);
        Bar bar = getBarById(id);

        bar.setName(barDetails.getName());
        bar.setAddress(barDetails.getAddress());
        bar.setActive(barDetails.getActive());

        return barRepository.save(bar);
    }

    @Transactional
    public void deleteBar(Long id) {
        log.info("Deactivating bar with id: {}", id);
        Bar bar = getBarById(id);
        bar.setActive(false);
        barRepository.save(bar);
    }
}
