package org.example.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "bars")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Bar {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    private String address;

    @Column(name = "active", nullable = false)
    @Builder.Default
    private Boolean active = true;

}
