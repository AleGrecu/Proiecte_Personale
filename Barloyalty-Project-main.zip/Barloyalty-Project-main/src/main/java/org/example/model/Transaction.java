package org.example.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "transactions")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "bar_id", nullable = false)
    private Bar bar;

    @Column(nullable = false)
    private Double amount;

    @Column(nullable = false)
    private Integer points;

    @Column(nullable = false)
    private LocalDateTime timestamp;

    private String qrCodeHash;

    @Column(nullable = false)
    private String status; // "PENDING", "COMPLETED", "FAILED"
}
