package org.example.repository;

import org.example.model.Reward;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface RewardRepository extends JpaRepository<Reward, Long> {

    /**
     * Find all active rewards ordered by points cost ascending
     */
    List<Reward> findByActiveTrueOrderByPointsCostAsc();

    /**
     * Find active rewards by bar ID
     */
    List<Reward> findByBarIdAndActiveTrue(Long barId);

    /**
     * Find rewards by bar ID (including inactive)
     */
    List<Reward> findByBarId(Long barId);

    /**
     * Check if a reward with the given name exists for a bar
     */
    boolean existsByBarIdAndName(Long barId, String name);
}
