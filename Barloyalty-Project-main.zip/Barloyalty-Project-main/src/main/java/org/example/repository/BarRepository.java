package org.example.repository;

import org.example.model.Bar;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BarRepository extends JpaRepository<Bar, Long> {

    /**
     * Find all bars where active = true
     */
    List<Bar> findByActiveTrue();

    /**
     * Find bars by name (case-insensitive)
     */
    List<Bar> findByNameContainingIgnoreCase(String name);

    /**
     * Check if a bar with the given name exists
     */
    boolean existsByName(String name);
}
