package org.example.controller;

import org.example.dto.*;
import org.example.service.QRService;
import org.example.service.TransactionService;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/qr")
@RequiredArgsConstructor
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "QR Codes", description = "QR code generation and validation endpoints")
public class QRController {

    private final QRService qrService;
    private final TransactionService transactionService;
    private final MeterRegistry meterRegistry;

    @PostMapping("/generate")
    @Operation(summary = "Generate QR code for transaction")
    public ResponseEntity<Map<String, Object>> generateQR(@Valid @RequestBody QRGenerateRequest request) {
        Map<String, Object> response = qrService.generateQRCode(request);

        Counter.builder("qr_codes_generated_total")
                .description("Total number of QR codes generated")
                .register(meterRegistry)
                .increment();

        return ResponseEntity.ok(response);
    }

    @PostMapping("/validate")
    @Operation(summary = "Validate QR code and complete transaction")
    public ResponseEntity<Map<String, String>> validateQR(@Valid @RequestBody QRValidateRequest request) {
        transactionService.validateTransaction(request.getQrCodeHash());

        Counter.builder("transactions_validated_total")
                .description("Total number of transactions validated")
                .register(meterRegistry)
                .increment();

        return ResponseEntity.ok(Map.of(
                "status", "success",
                "message", "Transaction completed successfully"
        ));
    }
}
