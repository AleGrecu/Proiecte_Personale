package org.example.controller;

import org.example.model.Bar;
import org.example.service.BarService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bars")
@RequiredArgsConstructor
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Bars", description = "Bar management endpoints")
public class BarController {

    private final BarService barService;

    @GetMapping
    @Operation(summary = "Get all active bars")
    public ResponseEntity<List<Bar>> getAllBars() {
        return ResponseEntity.ok(barService.getAllActiveBars());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get bar by ID")
    public ResponseEntity<Bar> getBarById(@PathVariable Long id) {
        return ResponseEntity.ok(barService.getBarById(id));
    }
}
