package org.example.controller;


import org.example.model.*;
import org.example.service.RewardService;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rewards")
@RequiredArgsConstructor
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Rewards", description = "Reward management and redemption endpoints")
public class RewardController {

    private final RewardService rewardService;
    private final MeterRegistry meterRegistry;

    @GetMapping
    @Operation(summary = "Get all active rewards")
    public ResponseEntity<List<Reward>> getAllRewards() {
        return ResponseEntity.ok(rewardService.getAllActiveRewards());
    }

    @GetMapping("/bar/{barId}")
    @Operation(summary = "Get rewards by bar ID")
    public ResponseEntity<List<Reward>> getRewardsByBar(@PathVariable Long barId) {
        return ResponseEntity.ok(rewardService.getRewardsByBar(barId));
    }

    @PostMapping("/{id}/redeem")
    @Operation(summary = "Redeem a reward")
    public ResponseEntity<RewardRedemption> redeemReward(@PathVariable Long id) {
        RewardRedemption redemption = rewardService.redeemReward(id);

        // Increment metric
        Counter.builder("rewards_redeemed_total")
                .description("Total number of rewards redeemed")
                .register(meterRegistry)
                .increment();

        return ResponseEntity.ok(redemption);
    }

    @GetMapping("/redemptions")
    @Operation(summary = "Get user's reward redemption history")
    public ResponseEntity<List<RewardRedemption>> getUserRedemptions() {
        return ResponseEntity.ok(rewardService.getUserRedemptions());
    }
}