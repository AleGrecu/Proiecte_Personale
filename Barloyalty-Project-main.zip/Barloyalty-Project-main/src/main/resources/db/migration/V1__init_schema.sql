-- ============================================
-- BarLoyalty Database Schema
-- Bazat EXACT pe Java Entities
-- ============================================

-- Drop tables if exist (în ordine pentru foreign keys)
DROP TABLE IF EXISTS reward_redemptions CASCADE;
DROP TABLE IF EXISTS transactions CASCADE;
DROP TABLE IF EXISTS rewards CASCADE;
DROP TABLE IF EXISTS bars CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- ============================================
-- Table: users
-- ============================================
CREATE TABLE users (
                       id BIGSERIAL PRIMARY KEY,
                       email VARCHAR(255) UNIQUE NOT NULL,
                       password VARCHAR(255) NOT NULL,
                       full_name VARCHAR(255) NOT NULL,
                       role VARCHAR(50) NOT NULL DEFAULT 'CLIENT',
                       points INTEGER NOT NULL DEFAULT 0,
                       active BOOLEAN NOT NULL DEFAULT TRUE
);

-- ============================================
-- Table: bars
-- ============================================
CREATE TABLE bars (
                      id BIGSERIAL PRIMARY KEY,
                      name VARCHAR(255) NOT NULL,
                      address VARCHAR(500),
                      active BOOLEAN NOT NULL DEFAULT TRUE
);

-- ============================================
-- Table: rewards
-- ============================================
CREATE TABLE rewards (
                         id BIGSERIAL PRIMARY KEY,
                         bar_id BIGINT NOT NULL,
                         name VARCHAR(255) NOT NULL,
                         description TEXT,
                         points_cost INTEGER NOT NULL,
                         active BOOLEAN NOT NULL DEFAULT TRUE,
                         CONSTRAINT fk_reward_bar FOREIGN KEY (bar_id) REFERENCES bars(id) ON DELETE CASCADE
);

-- ============================================
-- Table: transactions
-- ============================================
CREATE TABLE transactions (
                              id BIGSERIAL PRIMARY KEY,
                              user_id BIGINT NOT NULL,
                              bar_id BIGINT NOT NULL,
                              amount DOUBLE PRECISION NOT NULL,
                              points INTEGER NOT NULL,
                              timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                              qr_code_hash VARCHAR(255) UNIQUE,
                              status VARCHAR(50) NOT NULL DEFAULT 'PENDING',
                              CONSTRAINT fk_transaction_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                              CONSTRAINT fk_transaction_bar FOREIGN KEY (bar_id) REFERENCES bars(id) ON DELETE CASCADE
);

-- ============================================
-- Table: reward_redemptions
-- ============================================
CREATE TABLE reward_redemptions (
                                    id BIGSERIAL PRIMARY KEY,
                                    user_id BIGINT NOT NULL,
                                    reward_id BIGINT NOT NULL,
                                    points_spent INTEGER NOT NULL,
                                    redeemed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- Indexes for Performance
-- ============================================
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_bars_active ON bars(active);
CREATE INDEX idx_rewards_bar ON rewards(bar_id);
CREATE INDEX idx_rewards_active ON rewards(active);
CREATE INDEX idx_transactions_user ON transactions(user_id);
CREATE INDEX idx_transactions_bar ON transactions(bar_id);
CREATE INDEX idx_transactions_status ON transactions(status);
CREATE INDEX idx_transactions_qr_hash ON transactions(qr_code_hash);
CREATE INDEX idx_transactions_timestamp ON transactions(timestamp DESC);
CREATE INDEX idx_redemptions_user ON reward_redemptions(user_id);
CREATE INDEX idx_redemptions_reward ON reward_redemptions(reward_id);

-- ============================================
-- SEED DATA
-- ============================================

-- Seed Users
-- Password pentru toți: "password123"
-- BCrypt hash: $2a$10$N9qo8uLOickgx2ZMRFlkeOh9W8ZMRFlkeOh9W8ZMRFlkeOh9W8iOy
INSERT INTO users (email, password, full_name, role, points, active) VALUES
                                                                         ('client1@test.com', '$2a$10$N9qo8uLOickgx2ZMRFlkeOh9W8ZMRFlkeOh9W8ZMRFlkeOh9W8iOy', 'Ion Popescu', 'CLIENT', 150, true),
                                                                         ('client2@test.com', '$2a$10$N9qo8uLOickgx2ZMRFlkeOh9W8ZMRFlkeOh9W8ZMRFlkeOh9W8iOy', 'Maria Ionescu', 'CLIENT', 200, true),
                                                                         ('admin@bar.com', '$2a$10$N9qo8uLOickgx2ZMRFlkeOh9W8ZMRFlkeOh9W8ZMRFlkeOh9W8iOy', 'Admin User', 'ADMIN', 0, true);

-- Seed Bars
INSERT INTO bars (name, address, active) VALUES
                                             ('The Irish Pub', 'Str. Republicii 15, Brașov', true),
                                             ('Sky Bar Lounge', 'Bd. Eroilor 23, Brașov', true),
                                             ('Rock Café', 'Piața Sfatului 10, Brașov', true);

-- Seed Rewards
INSERT INTO rewards (bar_id, name, description, points_cost, active) VALUES
-- The Irish Pub rewards
(1, 'Free Beer', 'O bere gratuită la alegere', 50, true),
(1, 'Appetizer Plate', 'Platou de gustări pentru 2 persoane', 100, true),
(1, 'VIP Table Friday', 'Masă VIP rezervată vineri seara', 250, true),
(1, 'Irish Whiskey Shot', 'Un shot de whiskey irlandez premium', 75, true),

-- Sky Bar Lounge rewards
(2, 'Cocktail Special', 'Un cocktail signature la alegere', 75, true),
(2, 'Bottle of Wine', 'O sticlă de vin din selecția casei', 200, true),
(2, 'VIP Lounge Access', 'Acces VIP pentru o seară', 300, true),
(2, 'Sunset Drinks for 2', 'Două băuturi la apus', 150, true),

-- Rock Café rewards
(3, 'Free Coffee', 'O cafea speciality la alegere', 30, true),
(3, 'Burger Combo', 'Burger + Cartofi + Băutură', 120, true),
(3, 'Concert VIP Pass', 'Acces VIP la concerte live', 500, true);

-- Seed Initial Transactions (completed)
INSERT INTO transactions (user_id, bar_id, amount, points, timestamp, status) VALUES
                                                                                  (1, 1, 50.00, 50, CURRENT_TIMESTAMP - INTERVAL '2 days', 'COMPLETED'),
                                                                                  (1, 2, 75.50, 75, CURRENT_TIMESTAMP - INTERVAL '1 day', 'COMPLETED'),
                                                                                  (2, 1, 100.00, 100, CURRENT_TIMESTAMP - INTERVAL '3 days', 'COMPLETED'),
                                                                                  (2, 3, 45.00, 45, CURRENT_TIMESTAMP - INTERVAL '5 hours', 'COMPLETED');

-- Update user points based on transactions
UPDATE users SET points = 125 WHERE id = 1;  -- 50 + 75
UPDATE users SET points = 145 WHERE id = 2;  -- 100 + 45

-- Seed some reward redemptions
INSERT INTO reward_redemptions (user_id, reward_id, points_spent, redeemed_at) VALUES
                                                                                   (1, 1, 50, CURRENT_TIMESTAMP - INTERVAL '12 hours'),  -- Free Beer
                                                                                   (2, 5, 75, CURRENT_TIMESTAMP - INTERVAL '2 days');    -- Cocktail Special

-- Adjust user points after redemptions
UPDATE users SET points = 75 WHERE id = 1;   -- 125 - 50
UPDATE users SET points = 70 WHERE id = 2;   -- 145 - 75

-- ============================================
-- Verificare Date
-- ============================================

-- Verifică userii
SELECT
    id,
    email,
    full_name,
    role,
    points,
    active
FROM users
ORDER BY id;

-- Verifică barurile
SELECT
    id,
    name,
    address,
    active
FROM bars
ORDER BY id;

-- Verifică rewards
SELECT
    r.id,
    b.name AS bar_name,
    r.name AS reward_name,
    r.points_cost,
    r.active
FROM rewards r
         JOIN bars b ON r.bar_id = b.id
ORDER BY b.id, r.points_cost;

-- Verifică tranzacțiile
SELECT
    t.id,
    u.email AS user_email,
    b.name AS bar_name,
    t.amount,
    t.points,
    t.status,
    t.timestamp
FROM transactions t
         JOIN users u ON t.user_id = u.id
         JOIN bars b ON t.bar_id = b.id
ORDER BY t.timestamp DESC;

-- Verifică redemptions
SELECT
    rr.id,
    u.email AS user_email,
    r.name AS reward_name,
    rr.points_spent,
    rr.redeemed_at
FROM reward_redemptions rr
         JOIN users u ON rr.user_id = u.id
         JOIN rewards r ON rr.reward_id = r.id
ORDER BY rr.redeemed_at DESC;

-- ============================================
-- Statistici Utile
-- ============================================

-- Total puncte per utilizator
SELECT
    u.id,
    u.email,
    u.full_name,
    u.points AS current_points,
    COALESCE(SUM(t.points), 0) AS total_earned,
    COALESCE(SUM(rr.points_spent), 0) AS total_spent
FROM users u
         LEFT JOIN transactions t ON u.id = t.user_id AND t.status = 'COMPLETED'
         LEFT JOIN reward_redemptions rr ON u.id = rr.user_id
WHERE u.role = 'CLIENT'
GROUP BY u.id, u.email, u.full_name, u.points;

-- Rewards populare
SELECT
    r.name,
    b.name AS bar_name,
    r.points_cost,
    COUNT(rr.id) AS times_redeemed
FROM rewards r
         JOIN bars b ON r.bar_id = b.id
         LEFT JOIN reward_redemptions rr ON r.id = rr.reward_id
WHERE r.active = true
GROUP BY r.id, r.name, b.name, r.points_cost
ORDER BY times_redeemed DESC, r.points_cost;

-- Baruri active cu statistici
SELECT
    b.id,
    b.name,
    COUNT(DISTINCT t.id) AS total_transactions,
    COALESCE(SUM(t.amount), 0) AS total_revenue,
    COUNT(DISTINCT r.id) AS total_rewards
FROM bars b
         LEFT JOIN transactions t ON b.id = t.bar_id AND t.status = 'COMPLETED'
         LEFT JOIN rewards r ON b.id = r.bar_id AND r.active = true
WHERE b.active = true
GROUP BY b.id, b.name
ORDER BY total_transactions DESC;

-- ============================================
-- COMENTARII PENTRU DOCUMENTAȚIE
-- ============================================

/*
CREDENȚIALE SEED:

Utilizatori Clienți:
- Email: client1@test.com | Password: password123 | Puncte: 75
- Email: client2@test.com | Password: password123 | Puncte: 70

Admin:
- Email: admin@bar.com | Password: password123

Baruri:
1. The Irish Pub - 4 rewards
2. Sky Bar Lounge - 4 rewards
3. Rock Café - 3 rewards

NOTĂ: Toate parolele sunt criptate cu BCrypt.
Pentru a genera o nouă parolă BCrypt pentru "password123":
https://bcrypt-generator.com/

Schema este compatibilă 100% cu entitățile Java din proiect.
*/