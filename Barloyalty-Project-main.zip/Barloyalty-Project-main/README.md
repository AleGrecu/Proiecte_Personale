# ProiectOF-BarLoyalty

### **1. Prezentare Generală**                         

#### 1.1. Despre BarLoyalty

   BarLoyalty este un sistem modern de management al fidelității, bazat pe arhitectură cloud-native și microservicii, destinat industriei HoReCA (baruri, restaurante, cafenele). Platforma permite clienților să acumuleze puncte pentru achizițiile lor și să răscumpere recompense, oferind în același timp proprietarilor de baruri instrumente puternice de management și analiză.   

####   1.2. Funcționalități Cheie

   Pentru Clienți

- Sistem de Puncte: 1 punct pentru fiecare 1 RON cheltuit
- Tranzacții QR: Generare și scanare coduri QR pentru validare achizițiilor
- Notificări Real-Time: Actualizări instant prin WebSocket
- Catalog Recompense: Browse și răscumpărare recompense
- Istoric Complet: Vizualizare tranzacții și recompense câștigate
- Multi-Bar: Folosire puncte la orice bar partener

Pentru Administratori

-Gestionare Baruri: CRUD complet pentru locații                                                                                                
-Gestionare Recompense: Creare și editare recompense per bar  
-Dashboard Analytics: Statistici detaliate despre activitate  
-Gestionare Utilizatori: Vizualizare și administrare conturi  
-Rapoarte: Export date pentru analiză business                                                                                                                                                                                                                                      

Exemplu Practic
Scenariul lui Ion:

Ion se înregistrează în aplicație cu email-ul ion@example.com  
Merge la "The Irish Pub" și comandă o bere (25 RON)  
Barmanul generează un QR code pentru tranzacție  
Ion scanează QR-ul din aplicație  
Sistemul validează tranzacția și Ion primește 25 puncte  
După 2 vizite (50 puncte acumulate), Ion poate răscumpăra o "Free Beer"
Ion răscumpără recompensa, punctele sunt deduse automat  
La următoarea vizită, Ion prezintă recompensa și primește berea gratuită

#### 1.3 Avantaje Competitive

![img.png](img.png)

### **2. Arhitectura Sistemului**

   Sistemul adoptă o Arhitectură Hibridă (Monolithic Gateway + Microservices).

Componente Logice
Core Gateway (Spring Boot): Acționează ca punct central de intrare. Gestionează logica de business, securitatea, starea utilizatorilor și conexiunile WebSocket.

QR Service (Python FastAPI): Un microserviciu stateless specializat în generarea imaginilor QR și procesarea grafică.

Data Persistence (PostgreSQL): Baza de date relațională pentru date structurate.

Object Storage (MinIO): Stocare compatibilă S3 pentru imaginile QR generate.

Client (Frontend): Aplicație web (React/Node) care consumă API-urile REST și subscrie la topic-urile WebSocket.

Fluxul de Comunicație
Client -> Gateway: REST API (JSON) pentru CRUD și Upgrade: websocket pentru evenimente.

Gateway -> QR Service: HTTP REST (Sync) pentru a cere generarea unui QR.

QR Service -> MinIO: Upload imagine generată.

Gateway -> PostgreSQL: JPA/Hibernate pentru persistență.

### 3. **_**Cerințe de Sistem**_**

   Conform configurației docker-compose.yml și pom.xml/requirements.txt, mediul de rulare necesită:

Hardware (Minim Recomandat)
CPU: 2 Core-uri (pentru procesare imagine și GC Java).

RAM: 4 GB (1GB JVM, 500MB Python, 500MB DB, 2GB OS/Overhead).

Disk: 10 GB SSD.

Software Stack
Container Runtime: Docker Engine 20.10+ & Docker Compose v2.

Baza de Date: PostgreSQL 15 (Imagine Alpine).

Storage: MinIO (Latest).

Backend A: Java 17 (Eclipse Temurin JDK).

Backend B: Python 3.11 (Slim).

### 4. Schema Bazei de Date

   Modelul de date este relațional, normalizat (3NF). Implementarea se face prin JPA Entities (org.example.model).
![img_1.png](img_1.png)

####    Constrângeri Critice
-Email-ul utilizatorului este UNIC.

-Balanța punctelor (points) este gestionată atomic pentru a preveni "Double Spending".

-Tranzacțiile au statusuri (PENDING, COMPLETED, FAILED).

### **5. Securitate: Autentificare și Autorizare (JWT)**

   Securitatea este "Stateless", implementată în pachetul org.example.security.

Mecanism:

Token: JSON Web Token (JWT).

Algoritm: HMAC-SHA256 (Keys.hmacShaKeyFor).

Secret: Definit în JWT_SECRET (minim 256 biți).

Expirație: 24 de ore (86400000 ms).

Componente de Securitate
JwtTokenProvider: Generează token-uri care includ userId și role (claims custom). Validează semnătura la fiecare request.

CustomUserDetailsService: Încarcă utilizatorul din DB și transformă entitatea User în obiect UserDetails compatibil Spring Security.

Roluri:

-ROLE_ADMIN: Acces total la gestionarea Barurilor și QR-urilor.  
-ROLE_CLIENT: Acces la scanare, vizualizare portofel și revendicare premii.

### **6. Componente Backend: Gateway Service (Java)**

   Aplicația Spring Boot (BarLoyalty Gateway) este creierul sistemului.

Module Principale (org.example.service)
AuthService: Gestionează înregistrarea și login-ul. Hash-uiește parolele folosind PasswordEncoder.

TransactionService:

* Validează hash-ul QR.

* Previne reutilizarea aceluiași cod QR (verificare în DB).

* Actualizează balanța utilizatorului în tranzacție atomică.

* BarService & RewardService: CRUD standard pentru administrare.

* UserContextService: Helper pentru extragerea utilizatorului curent din SecurityContextHolder.

* API Documentation (OpenAPI 3.0)
* Gateway-ul expune documentație Swagger automată la /swagger-ui.html, configurată prin clasa OpenApiConfig.

* Schemă de securitate: bearerAuth.

### **7. Microserviciu QR & Procesare Imagine (Python)**

   Serviciul rulează separat pentru a nu bloca thread-urile Java cu operațiuni CPU-intensive (procesare imagine).

Stack Tehnologic
Framework: FastAPI + Uvicorn.

Librării: qrcode (generare matrice), Pillow (procesare imagine/logo), minio (client S3).

Endpoint-uri
GET /health: Healthcheck pentru Docker Compose.

(Implicit) Logică de generare care primește date, creează PNG-ul și îl urcă în MinIO.

### **8. Comunicație Real-Time (WebSocket)**

   Sistemul elimină nevoia de "Polling" din partea clientului.

Configurare (WebSocketConfig.java)
1. [ ] Protocol: STOMP (Simple Text Oriented Messaging Protocol).
 
3. [ ] Endpoint Handshake: ws://localhost:8080/ws.

5. [ ] Broker: In-memory, rutează mesaje către /topic (broadcast) și /queue (private).

7. [ ] Fluxuri de Date (WebSocketService.java)   
 Events:

10. [ ] POINTS_UPDATE: Când un QR este scanat cu succes.

12. [ ] TRANSACTION_COMPLETED: Confirmare vizuală.

14. [ ] REWARD_REDEEMED: Confirmare scădere puncte.

Targetare:

2. [ ] Folosește convertAndSendToUser(userId, destination, payload).

4. [ ] Mesajele ajung doar la utilizatorul specificat, asigurând confidențialitatea.

### **9. Stocarea Obiectelor (MinIO)**

  - MinIO este folosit ca înlocuitor local pentru AWS S3.

Bucket: Stochează imaginile QR generate.  
Acces: Serviciul Python scrie (Upload), Gateway-ul sau Frontend-ul citesc (Download/Display).  
Config: Credențiale minioadmin / minioadmin (în dev).

### **10. Pipeline CI/CD și DevOps**

Automatizarea este asigurată prin GitHub Actions (pipeline.yml).

Stadii (Stages)  
Test Gateway:

Setup JDK 17.  
Rulare teste unitare JUnit (mvn test).  
Test QR Service:  
Setup Python 3.11.     
Instalare dependințe (pip install).  
Rulare teste (pytest).   
Build și Test React/Node.  
Build & Push Docker:  
Se execută doar pe ramura main.       
Construiește imaginile Docker pentru toate cele 3 servicii.  
Integration Test:
Pornește întregul stack (docker-compose up -d).
Așteaptă healthcheck-urile (cu curl și sleep).
Verifică dacă serviciile comunică între ele.

* ## Ghid Complet de Rulare + Screenshots BAR LOYALTY

**Pas 1: Pornire Servicii**
![img_2.png](img_2.png)
![img_3.png](img_3.png)
![img_4.png](img_4.png)

**Pas2: Verifica Statusul**

![img_5.png](img_5.png)

**Pas 3: Verifica Logs**

![img_6.png](img_6.png)

**Verificarea Baza de Date**  
**Pas 4: Conectare PostgreSQL**

![img_7.png](img_7.png)
![img_8.png](img_8.png)
![img_9.png](img_9.png)
![img_10.png](img_10.png)
![img_11.png](img_11.png)

**Pas 5:Gateway Health Check**

![img_12.png](img_12.png)

**QR Service Health**
![img_13.png](img_13.png)

**Gateway Matrics**
![img_14.png](img_14.png)

**ACCESEAZA Serverele**

![img_16.png](img_16.png)
![img_17.png](img_17.png)

**MiniIO functioneaza corect**

![img_18.png](img_18.png)

**MiniIO console login**

![img_19.png](img_19.png)

**GitHub Configuration**
![img_20.png](img_20.png)

**GitHub Actions Run**
![img_21.png](img_21.png)

**WebSocket Testing**
![img_22.png](img_22.png)
