from fastapi import FastAPI, HTTPException, Header, Depends
from pydantic import BaseModel
from typing import Optional
import qrcode
from io import BytesIO
import base64
from minio import Minio
from minio.error import S3Error
import os
import logging
from datetime import datetime
import hashlib

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="BarLoyalty QR Service",
    description="Microservice for generating and validating QR codes",
    version="1.0.0"
)

# Configuration
QR_SERVICE_SECRET = os.getenv("QR_SERVICE_SECRET", "qr-service-secret")
MINIO_ENDPOINT = os.getenv("MINIO_ENDPOINT", "minio:9000").replace("http://", "").replace("https://", "")
MINIO_ACCESS_KEY = os.getenv("MINIO_ACCESS_KEY", "minioadmin")
MINIO_SECRET_KEY = os.getenv("MINIO_SECRET_KEY", "5sRBS7TFLnoHdwvxgjnRlHSh9oaZ+zcT")
BUCKET_NAME = "qr-codes"

# Initialize MinIO client
try:
    minio_client = Minio(
        MINIO_ENDPOINT,
        access_key=MINIO_ACCESS_KEY,
        secret_key=MINIO_SECRET_KEY,
        secure=False
    )
    logger.info(f"MinIO client initialized with endpoint: {MINIO_ENDPOINT}")
except Exception as e:
    logger.error(f"Failed to initialize MinIO client: {e}")
    minio_client = None

# Ensure bucket exists
if minio_client:
    try:
        if not minio_client.bucket_exists(BUCKET_NAME):
            minio_client.make_bucket(BUCKET_NAME)
            logger.info(f"Created bucket: {BUCKET_NAME}")
        else:
            logger.info(f"Bucket {BUCKET_NAME} already exists")
    except S3Error as e:
        logger.error(f"Error with bucket: {e}")
    except Exception as e:
        logger.error(f"Unexpected error connecting to MinIO: {e}")

# Request/Response models
class QRGenerateRequest(BaseModel):
    hash: str
    amount: float
    barName: str

class QRGenerateResponse(BaseModel):
    qrCodeUrl: str
    qrCodeHash: str

class QRValidateRequest(BaseModel):
    qrCodeHash: str

class QRValidateResponse(BaseModel):
    valid: bool
    message: str

class HealthResponse(BaseModel):
    status: str
    timestamp: str
    service: str

# Dependency for authentication
def verify_service_secret(x_service_secret: Optional[str] = Header(None)):
    if not QR_SERVICE_SECRET:
        logger.warning("QR_SERVICE_SECRET not configured")
        return

    if x_service_secret != QR_SERVICE_SECRET:
        raise HTTPException(status_code=401, detail="Invalid service secret")

# Metrics storage
metrics = {
    "qr_codes_generated": 0,
    "qr_codes_validated": 0
}

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy",
        timestamp=datetime.utcnow().isoformat(),
        service="qr-service"
    )

@app.get("/metrics")
async def get_metrics():
    """Prometheus-style metrics endpoint"""
    return {
        "qr_codes_generated_total": metrics["qr_codes_generated"],
        "qr_codes_validated_total": metrics["qr_codes_validated"]
    }

@app.post("/api/qr/generate", response_model=QRGenerateResponse)
async def generate_qr(
    request: QRGenerateRequest,
    _: None = Depends(verify_service_secret)
):
    """Generate QR code for transaction"""
    if not minio_client:
        raise HTTPException(status_code=503, detail="Storage service unavailable")

    try:
        logger.info(f"Generating QR code for hash: {request.hash}")

        # Create QR code content
        qr_data = f"{request.hash}|{request.amount}|{request.barName}"

        # Generate QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(qr_data)
        qr.make(fit=True)

        # Create image
        img = qr.make_image(fill_color="black", back_color="white")

        # Convert to bytes
        img_bytes = BytesIO()
        img.save(img_bytes, format='PNG')
        img_bytes.seek(0)

        # Upload to MinIO
        object_name = f"{request.hash}.png"
        minio_client.put_object(
            BUCKET_NAME,
            object_name,
            img_bytes,
            length=img_bytes.getbuffer().nbytes,
            content_type="image/png"
        )

        # Generate presigned URL (valid for 24 hours)
        qr_code_url = minio_client.presigned_get_object(
            BUCKET_NAME,
            object_name,
            expires=86400  # 24 hours
        )

        # Update metrics
        metrics["qr_codes_generated"] += 1

        logger.info(f"QR code generated successfully: {object_name}")

        return QRGenerateResponse(
            qrCodeUrl=qr_code_url,
            qrCodeHash=request.hash
        )

    except S3Error as e:
        logger.error(f"MinIO error: {e}")
        raise HTTPException(status_code=500, detail=f"Storage error: {str(e)}")
    except Exception as e:
        logger.error(f"Error generating QR code: {e}")
        raise HTTPException(status_code=500, detail=f"Error generating QR code: {str(e)}")

@app.post("/api/qr/validate", response_model=QRValidateResponse)
async def validate_qr(
    request: QRValidateRequest,
    _: None = Depends(verify_service_secret)
):
    """Validate QR code"""
    if not minio_client:
        raise HTTPException(status_code=503, detail="Storage service unavailable")

    try:
        logger.info(f"Validating QR code: {request.qrCodeHash}")

        # Check if QR code exists in storage
        object_name = f"{request.qrCodeHash}.png"

        try:
            minio_client.stat_object(BUCKET_NAME, object_name)

            # Update metrics
            metrics["qr_codes_validated"] += 1

            logger.info(f"QR code validated successfully: {object_name}")

            return QRValidateResponse(
                valid=True,
                message="QR code is valid"
            )
        except S3Error as e:
            if e.code == "NoSuchKey":
                logger.warning(f"QR code not found: {object_name}")
                return QRValidateResponse(
                    valid=False,
                    message="QR code not found or expired"
                )
            raise

    except Exception as e:
        logger.error(f"Error validating QR code: {e}")
        raise HTTPException(status_code=500, detail=f"Error validating QR code: {str(e)}")

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "BarLoyalty QR Service",
        "version": "1.0.0",
        "status": "running"
    }

if __name__ == "__main__":
    import uvicorn
    # Pornim pe portul 8081 așa cum este definit în Dockerfile
    uvicorn.run(app, host="0.0.0.0", port=8081)