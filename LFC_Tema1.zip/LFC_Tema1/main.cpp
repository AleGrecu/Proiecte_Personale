﻿#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <stack>
#include "DeterministicFiniteAutomaton.h"

struct RegexTreeNode {
    char value;
    RegexTreeNode* left;
    RegexTreeNode* right;

    RegexTreeNode(char v, RegexTreeNode* L = nullptr, RegexTreeNode* R = nullptr)
        : value(v), left(L), right(R) {
    }
};

bool isSymbol(char c) {
    return (c >= 'a' && c <= 'z');
}

RegexTreeNode* buildSyntaxTree(const std::string& postfix) {
    std::stack<RegexTreeNode*> st;

    for (char c : postfix) {
        if (isSymbol(c)) {
            st.push(new RegexTreeNode(c));
        }
        else if (c == '.' || c == '|') {
            if (st.size() < 2) continue;
            RegexTreeNode* r = st.top(); st.pop();
            RegexTreeNode* l = st.top(); st.pop();
            st.push(new RegexTreeNode(c, l, r));
        }
        else if (c == '*' || c == '+') {
            if (st.empty()) continue;
            RegexTreeNode* l = st.top(); st.pop();
            st.push(new RegexTreeNode(c, l, nullptr));
        }
    }

    return st.empty() ? nullptr : st.top();
}

std::vector<std::string> mergeTreeGraphics(const std::vector<std::string>& left,
    const std::vector<std::string>& right,
    char root)
{
    int leftW = left.empty() ? 0 : left[0].size();
    int rightW = right.empty() ? 0 : right[0].size();

    int totalW = leftW + 2 + rightW;
    std::vector<std::string> result;

    
    std::string rootLine(totalW, ' ');
    int rootPos = leftW + 1;  

    if (rootPos >= totalW)
        rootPos = totalW - 1;

    rootLine[rootPos] = root;
    result.push_back(rootLine);

    std::string branchLine(totalW, ' ');
    if (!left.empty())
        branchLine[leftW / 2] = '/';

    if (!right.empty())
        branchLine[leftW + 2 + rightW / 2] = '\\';

    result.push_back(branchLine);

    int h = std::max(left.size(), right.size());
    std::vector<std::string> L = left;
    std::vector<std::string> R = right;

    while ((int)L.size() < h) 
        L.push_back(std::string(leftW, ' '));
    while ((int)R.size() < h) 
        R.push_back(std::string(rightW, ' '));

    for (int i = 0; i < h; i++) {
        result.push_back(L[i] + "  " + R[i]);
    }

    return result;
}

std::vector<std::string> buildTreeGraphic(RegexTreeNode* node) {
    if (!node) return { "" };

    if (!node->left && !node->right)
        return { std::string(1, node->value) };

    std::vector<std::string> leftPic, rightPic;

    if (node->left) 
        leftPic = buildTreeGraphic(node->left);
    if (node->right) 
        rightPic = buildTreeGraphic(node->right);

    return mergeTreeGraphics(leftPic, rightPic, node->value);
}

void printSyntaxTree(RegexTreeNode* root) {
    auto lines = buildTreeGraphic(root);

    for (auto& line : lines) {
        while (!line.empty() && line.back() == ' ')
            line.pop_back();

        std::cout << line << "\n";
    }
}

void deleteSyntaxTree(RegexTreeNode* node) {
    if (!node)
        return;

    deleteSyntaxTree(node->left);
    deleteSyntaxTree(node->right);

    delete node;
}

int main() {
    std::ifstream fin("regex.txt");
    if (!fin) {
        std::cout << "Nu pot deschide fisierul regex.txt!\n";
        return 1;
    }

    std::string regex;
    std::getline(fin, regex);
    fin.close();

    DeterministicFiniteAutomaton helper;

    std::string regexWithConcat = helper.addConcatOperators(regex);
    std::string postfix = helper.infixToPostfix(regexWithConcat);

    RegexTreeNode* root = buildSyntaxTree(postfix);

    DeterministicFiniteAutomaton dfa = helper.regexToDFA(regex);

    int opt = -1;

    do {
        std::cout << "\n===== MENIU =====\n";
		std::cout << "Expresia regulata: " << regex << "\n";
        std::cout << "1. Afisarea formei ploneze postfixate a expresiei regulate\n";
        std::cout << "2. Afisare arbore sintactic corespunzator expresiei regulate \n";
        std::cout << "3. Afisare automat DFA (in consola si in fisier)\n";
        std::cout << "4. Verificarea cuvintelor in automat\n";
        std::cout << "0. Iesire\n";
        std::cout << "Optiune: ";
        std::cin >> opt;

        switch (opt) {

        case 1:
            std::cout << "\nForma poloneza postfixata: " << postfix << "\n";
            break;

        case 2:
            std::cout << "\nArbore sintactic:\n";
            printSyntaxTree(root);
            break;

        case 3: {
            std::cout << "\nAUTOMAT DFA:\n";
            std::cout << dfa << "\n";
            std::ofstream fout("automaton.out");
            fout << dfa;
            fout.close();
            break;
        }

        case 4: {
            std::string word;
            std::cout << "Introduceti cuvinte (STOP pt. iesire):\n";
            while (true) {
                std::cout << "> ";
                std::cin >> word;
                if (word == "STOP") break;
                std::cout << (dfa.checkWord(word) ? "ACCEPTAT\n" : "RESPINS\n");
            }
            break;
        }

        case 0:
            std::cout << "La revedere!\n";
            break;

        default:
            std::cout << "Optiune invalida!\n";
        }

    } while (opt != 0);

    deleteSyntaxTree(root);
    return 0;
}
