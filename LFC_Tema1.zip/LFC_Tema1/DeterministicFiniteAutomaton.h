#pragma once
#include <set>
#include<map>
#include<algorithm>
#include <iostream>
#include<string>
#include<vector>
#include<stack>
#include<queue>

class DeterministicFiniteAutomaton
{
    private:
        std::set<int> states;//Q(set of states)
        std::set<char> alphabet;//suma
        std::map<std::pair<int, char>, int>transitionFunction;//delta mic
        int startState;//q0
        std::set<int>finalState;//F

     public:

         DeterministicFiniteAutomaton() : startState(0) {};
         DeterministicFiniteAutomaton(const std::set<int>& Q, const std::set<char>& Sigma,
             const std::map<std::pair<int, char>, int>& delta, int q0, const std::set<int>& F) :
             states(Q), alphabet(Sigma), transitionFunction(delta), startState(q0), finalState(F) {
         };

		 std::set<int> getStates() const;
		 std::set<char>getAlphabet() const;
		 std::map<std::pair<int, char>, int> getTransitionFunction() const;
		 int getStartState() const;
		 std::set<int> getFinalState() const;

		 void setStates(const std::set<int>& Q);
		 void setAlphabet(const std::set<char>& Sigma);
		 void setTransitionFunction(const std::map<std::pair<int, char>, int>& delta);
		 void setStartStates(int q0);
		 void setFinalStates(const std::set<int>& F);

		 void addTransition(int fromState, char symbol, int toState);

         bool verifyAutomaton() const;
		 bool checkWord(const std::string& word) const;
         void printAutomaton() const;

		 friend std::ostream& operator<<(std::ostream& os, const DeterministicFiniteAutomaton& dfa);

         ~DeterministicFiniteAutomaton()=default;


		 //Regex in AFD

		 const char EPS = '\0';

		 struct NFA {
			 int start;
			 int accept;
		 };

		 struct NFAgraph {
			 
			 std::vector<std::map<char, std::vector<int>>> transition;
		 };

		 int addState(NFAgraph& graph);
		 void addTransition(int from, char symbol, int to, NFAgraph& graph);
		
		 std::string addConcatOperators(const std::string& regex);
		 int precedence(char op);
		 std::string infixToPostfix(const std::string& regex);

		 NFA makeSymbolNFA(NFAgraph &graph,char a);
		 NFA makeUnionNFA(NFAgraph& graph,const NFA& afn1, const NFA& afn2);
		 NFA makeConcatNFA(NFAgraph& graph,const NFA& afn1, const NFA& afn2);
		 NFA makeKleeneStarNFA(NFAgraph& graph, const NFA& afn);
		 NFA makePlusNFA(NFAgraph& graph, const NFA& afn1);
		 NFA regexPostfixToNFA(const std::string& postfix, NFAgraph& graph,std::set<char>& alphabet);

		 std::set<int>epsilonClosure(const NFAgraph &graph,const std::set<int>& Subset);
		 std::set<int>moveOnSymbol(const NFAgraph& graph, const std::set<int>& Symbol, char a);//a un caracter din alfabet

		 DeterministicFiniteAutomaton NFAtoDFA(const NFAgraph &graph,const NFA& afn, const std::set<char>& alphabet);
		 DeterministicFiniteAutomaton regexToDFA(const std::string& regex);

};

