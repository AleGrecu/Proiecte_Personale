﻿#include "DeterministicFiniteAutomaton.h"
#include <iomanip> 

std::set<int> DeterministicFiniteAutomaton::getStates() const
{
	return states;
}

std::set<char> DeterministicFiniteAutomaton::getAlphabet() const
{
	return alphabet;
}

std::map<std::pair<int, char>, int> DeterministicFiniteAutomaton::getTransitionFunction() const
{
	return transitionFunction;
}

int DeterministicFiniteAutomaton::getStartState() const
{
	return startState;
}

std::set<int> DeterministicFiniteAutomaton::getFinalState() const
{
	return finalState;
}

void DeterministicFiniteAutomaton::setStates(const std::set<int>& Q)
{
	states = Q;
}

void DeterministicFiniteAutomaton::setAlphabet(const std::set<char>& Sigma)
{
	alphabet = Sigma;
}

void DeterministicFiniteAutomaton::setTransitionFunction(const std::map<std::pair<int, char>, int>& delta)
{
	transitionFunction = delta;
}

void DeterministicFiniteAutomaton::setStartStates(int q0)
{
	startState = q0;
}

void DeterministicFiniteAutomaton::setFinalStates(const std::set<int>& F)
{
	finalState = F;
}


void DeterministicFiniteAutomaton::addTransition(int fromState, char symbol, int toState)
{
	transitionFunction[{fromState, symbol}] = toState;
}

bool DeterministicFiniteAutomaton::verifyAutomaton() const
{
	if (states.find(startState) == states.end()) {
		std::cerr << "AFD invalid";
		return false;
	}
	for (int f : finalState) {
		if (states.find(f) == states.end()) {
			std::cerr << "AFD invalid";
			return false;
		}
	}
	for (auto& t : transitionFunction) {
		int fromState = t.first.first;
		char symbol = t.first.second;
		int toState = t.second;
		if (states.find(fromState) == states.end() || states.find(toState) == states.end()) {
			std::cerr << "AFD invalid";
			return false;
		}
		if (alphabet.find(symbol) == alphabet.end()) {
			std::cerr << "AFD invalid";
			return false;
		}
	}
	return true;
}

bool DeterministicFiniteAutomaton::checkWord(const std::string& word) const
{
	int currentState = startState;

	for (char symbol : word) {
		if (alphabet.find(symbol) == alphabet.end()) {
			return false; 
		}

		auto it = transitionFunction.find({ currentState, symbol });
		if (it == transitionFunction.end()) {
			return false;
		}
		currentState = it->second; 
	}
	return finalState.find(currentState) != finalState.end(); 
}

void DeterministicFiniteAutomaton::printAutomaton() const
{
	std::cout << *this;
}

std::ostream& operator<<(std::ostream& os, const DeterministicFiniteAutomaton& dfa)
{
	os << "AFD\n\n";

	os << "Stari (Q): { ";
	for (int s : dfa.states) os << s << " ";
	os << "}\n";

	os << "Alfabet (Sigma): { ";
	for (char c : dfa.alphabet) os << c << " ";
	os << "}\n";

	os << "Stare initila: " << dfa.startState << "\n";
	os << "Stare finala: { ";
	for (int f : dfa.finalState) os << f << " ";
	os << "}\n\n";

	//Tabela de tranzitie
	int w1 = 12, w2 = 12, w3 = 12;
	os << std::left
		<< std::setw(w1) << "FromState"
		<< std::setw(w2) << "Symbol"
		<< std::setw(w3) << "ToState" << "\n";

	os << std::string(w1 + w2 + w3, '-') << "\n";

	for (const auto& t : dfa.transitionFunction) {
		os << std::left
			<< std::setw(w1) << t.first.first
			<< std::setw(w2) << t.first.second
			<< std::setw(w3) << t.second
			<< "\n";
	}

	return os;
}



int DeterministicFiniteAutomaton::addState(NFAgraph& graph)
{
	graph.transition.push_back({});
	return (int)graph.transition.size() - 1;


}

void DeterministicFiniteAutomaton::addTransition(int from, char symbol, int to, NFAgraph& graph)
{
	graph.transition[from][symbol].push_back(to);
}



std::string DeterministicFiniteAutomaton::addConcatOperators(const std::string& regex)
{
	std::string result;
	auto isSymbol = [](char c) {
		return (c >= 'a' && c <= 'z');
		};

	for (size_t i = 0; i < regex.size(); ++i) {
		char c1 = regex[i];
		result.push_back(c1);

		if (i + 1 < regex.size()) {
			char c2 = regex[i + 1];
			bool c1_is_atom = isSymbol(c1) || c1 == ')' || c1 == '*' || c1 == '+';
			bool c2_is_atom = isSymbol(c2) || c2 == '(';

			if (c1_is_atom && c2_is_atom) {
				result.push_back('.');//concatenare
			}
		}
	}
	return result;
}


int DeterministicFiniteAutomaton::precedence(char op)
{
	if (op == '|')
		return 1;
	if (op == '.')
		return 2;
	return 0;

}

std::string DeterministicFiniteAutomaton::infixToPostfix(const std::string& regex)
{
	std::string output;
	std::stack<char> operators;
	auto isSymbol = [](char c) {
		return (c >= 'a' && c <= 'z');
		};
	for (char c : regex)
	{
		if (isSymbol(c)) {
			output.push_back(c);
		}
		else if (c == '(') {
			operators.push(c);
		}
		else if (c == ')') {
			while (!operators.empty() && operators.top() != '(') {
				output.push_back(operators.top());
				operators.pop();
			}
			if (!operators.empty()) operators.pop();
		}
		else if (c == '*' || c == '+') {
			output.push_back(c);
		}
		else if (c == '|' || c == '.') {
			while (!operators.empty() && precedence(operators.top()) >= precedence(c)) {
				if (operators.top() == '(') break;
				output.push_back(operators.top());
				operators.pop();
			}
			operators.push(c);
		}
	
	}
	while (!operators.empty()) {
		if (operators.top() != '(')
			output.push_back(operators.top());
		operators.pop();

	}

	return output;
}

DeterministicFiniteAutomaton::NFA DeterministicFiniteAutomaton::makeSymbolNFA(NFAgraph& graph, char a)
{
	NFA nfa;
	nfa.start = addState(graph);
	nfa.accept = addState(graph);
	addTransition(nfa.start, a, nfa.accept, graph);
	return nfa;
}

DeterministicFiniteAutomaton::NFA DeterministicFiniteAutomaton::makeUnionNFA(NFAgraph& graph, const NFA& afn1, const NFA& afn2)
{
	NFA nfa;
	nfa.start = addState(graph);
	nfa.accept = addState(graph);

	addTransition(nfa.start, EPS, afn1.start, graph);
	addTransition(nfa.start, EPS, afn2.start, graph);

	addTransition(afn1.accept, EPS, nfa.accept, graph);
	addTransition(afn2.accept, EPS, nfa.accept, graph);

	return nfa;

}

DeterministicFiniteAutomaton::NFA DeterministicFiniteAutomaton::makeConcatNFA(NFAgraph& graph, const NFA& afn1, const NFA& afn2)
{
	addTransition(afn1.accept, EPS, afn2.start, graph);
	NFA nfa;
	nfa.start = afn1.start;
	nfa.accept = afn2.accept;
	return nfa;
}

DeterministicFiniteAutomaton::NFA DeterministicFiniteAutomaton::makeKleeneStarNFA(NFAgraph& graph, const NFA& afn)
{
	NFA nfa;
	nfa.start = addState(graph);
	nfa.accept = addState(graph);

	addTransition(nfa.start, EPS, afn.start, graph);
	addTransition(nfa.start, EPS, nfa.accept, graph);
	addTransition(afn.accept, EPS, afn.start, graph);
	addTransition(afn.accept, EPS, nfa.accept, graph);

	return nfa;
}

DeterministicFiniteAutomaton::NFA DeterministicFiniteAutomaton::makePlusNFA(NFAgraph& graph, const NFA& afn1)
{
	NFA nfa;
	nfa.start = addState(graph);
	nfa.accept = addState(graph);

	addTransition(nfa.start, EPS, afn1.start, graph);
	addTransition(afn1.accept, EPS, afn1.start, graph);
	addTransition(afn1.accept, EPS, nfa.accept, graph);

	return nfa;
}

DeterministicFiniteAutomaton::NFA DeterministicFiniteAutomaton::regexPostfixToNFA(const std::string& postfix, NFAgraph& graph, std::set<char>& alphabet)
{
	std::stack<NFA>st;

	for (char c : postfix) {
		if (c >= 'a' && c <= 'z') {
			alphabet.insert(c);
			st.push(makeSymbolNFA(graph, c));
		}
		else if (c == '|') {
			NFA B = st.top(); st.pop();
			NFA A = st.top(); st.pop();
			st.push(makeUnionNFA(graph, A, B));
		}
		else if (c == '.') {
			NFA B = st.top(); st.pop();
			NFA A = st.top(); st.pop();
			st.push(makeConcatNFA(graph, A, B));
		}
		else if (c == '*') {
			NFA A = st.top(); st.pop();
			st.push(makeKleeneStarNFA(graph, A));
		}
		else if (c == '+') {
			NFA A = st.top(); st.pop();
			st.push(makePlusNFA(graph, A));
		}
	}
	return st.top();
}

std::set<int> DeterministicFiniteAutomaton::epsilonClosure(const NFAgraph& graph, const std::set<int>& Subset)
{
	std::set<int> closure = Subset;
	std::stack<int>st;

	for (int s : Subset)
	{
		st.push(s);
	}

	while (!st.empty())
	{
		int state = st.top();
		st.pop();
		auto it = graph.transition[state].find(EPS);
		if (it != graph.transition[state].end()) {
			for (int nextState : it->second) {
				if (closure.find(nextState) == closure.end()) {
					closure.insert(nextState);
					st.push(nextState);
				}
			}
		}
	}
	return closure;
}

std::set<int> DeterministicFiniteAutomaton::moveOnSymbol(const NFAgraph& graph, const std::set<int>& Symbol, char a)
{
	std::set<int>results;
	for (int s : Symbol)
	{
		auto it = graph.transition[s].find(a);
		if (it != graph.transition[s].end()) {
			for (int nextState : it->second) {
				results.insert(nextState);
			}
		}
	}
	return results;
}

DeterministicFiniteAutomaton DeterministicFiniteAutomaton::NFAtoDFA(const NFAgraph& graph, const NFA& afn, const std::set<char>& alphabet)
{
	std::set<int> dfaStates;
	std::map<std::pair<int, char>, int> dfaTransition;
	std::set<int> dfaFinalStates;
	int dfaStart = 0;

	std::map<std::set<int>, int> subsetIndex;
	std::vector<std::set<int>> indexSubset;

	std::set<int> startSet = epsilonClosure(graph, { afn.start });
	subsetIndex[startSet] = 0;
	indexSubset.push_back(startSet);
	dfaStates.insert(0);

	std::queue<int>q;
	q.push(0);

	while (!q.empty()) {
		int dState = q.front(); q.pop();
		std::set<int> subset = indexSubset[dState];

		for (char a : alphabet) {
			std::set<int> moved = moveOnSymbol(graph, subset, a);
			if (moved.empty()) continue;
			moved = epsilonClosure(graph, moved);

			if (subsetIndex.find(moved) == subsetIndex.end()) {
				int newIndex = (int)indexSubset.size();
				subsetIndex[moved] = newIndex;
				indexSubset.push_back(moved);
				dfaStates.insert(newIndex);
				q.push(newIndex);
			}

			int toIndex = subsetIndex[moved];
			dfaTransition[{dState, a}] = toIndex;
		}
	}
	for (auto& entry : subsetIndex) {
		const std::set<int>& subset = entry.first;
		int index = entry.second;
		if (subset.find(afn.accept) != subset.end()) {
			dfaFinalStates.insert(index);
		}
	}
	DeterministicFiniteAutomaton dfa(dfaStates, alphabet, dfaTransition, dfaStart, dfaFinalStates);
	return dfa;
}

DeterministicFiniteAutomaton DeterministicFiniteAutomaton::regexToDFA(const std::string& regex)
{
	NFAgraph graph;
	std::set<char> alphabet;
	std::string regexWithConcat = addConcatOperators(regex);
	std::string postfix = infixToPostfix(regexWithConcat);
	NFA afn = regexPostfixToNFA(postfix, graph, alphabet);
	DeterministicFiniteAutomaton dfa = NFAtoDFA(graph, afn, alphabet);
	return dfa;
}