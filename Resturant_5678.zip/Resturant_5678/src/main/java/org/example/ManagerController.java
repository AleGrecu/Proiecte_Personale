package org.example;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

public class ManagerController {
    private final DatabaseService db;
    private final User manager;

    public ManagerController(DatabaseService db, User manager) {
        this.db = db;
        this.manager = manager;
    }

    public User getManager() {
        return manager;
    }

    public DatabaseService getDb() {
        return db;
    }

    // ===== GESTIUNE PERSONAL =====
    public List<User> getAllWaiters() {
        EntityManager em = db.getEntityManager();
        TypedQuery<User> q = em.createQuery(
                "SELECT u FROM User u WHERE u.role = :role ORDER BY u.username",
                User.class
        );
        q.setParameter("role", User.Role.WAITER);
        return q.getResultList();
    }

    public boolean createWaiter(String username, String password) {
        EntityManager em = db.getEntityManager();
        try {
            em.getTransaction().begin();
            User waiter = new User(username, password, User.Role.WAITER);
            em.persist(waiter);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            return false;
        }
    }

    public boolean updateWaiter(User waiter, String newPassword) {
        EntityManager em = db.getEntityManager();
        try {
            em.getTransaction().begin();
            User managed = em.merge(waiter);
            managed.setPassword(newPassword);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            return false;
        }
    }

    public boolean deleteWaiter(User waiter) {
        EntityManager em = db.getEntityManager();
        try {
            em.getTransaction().begin();

            em.createQuery("DELETE FROM LinieComandaEntity l WHERE l.comanda.waiter = :w")
                    .setParameter("w", waiter)
                    .executeUpdate();

            em.createQuery("DELETE FROM ComandaEntity c WHERE c.waiter = :w")
                    .setParameter("w", waiter)
                    .executeUpdate();

            User managed = em.merge(waiter);
            em.remove(managed);

            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            return false;
        }
    }

    // ===== GESTIUNE MENIU =====
    public List<Produs> getAllProducts() {
        return db.incarcaToateProdusele();
    }

    public boolean createProduct(String nume, double pret, Categorie categorie) {
        EntityManager em = db.getEntityManager();
        try {
            em.getTransaction().begin();

            Produs produs;
            switch (categorie) {
                case PIZZA:
                    produs = new Pizza.Builder(nume, pret)
                            .cuBlat(Pizza.Blat.CLASIC)
                            .cuSos(Pizza.Sos.ROSU)
                            .build();
                    break;
                case BAUTURI_ALCOOLICE:
                    produs = new Bautura(nume, pret, 250, true);
                    break;
                case BAUTURI_RACORITOARE:
                    produs = new Bautura(nume, pret, 330, false);
                    break;
                case DESERT:
                case FEL_PRINCIPAL:
                case APERITIVE:
                    produs = new Mancare(nume, pret, 300, categorie, false);
                    break;
                default:
                    produs = new Mancare(nume, pret, 300);
            }

            em.persist(produs);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            return false;
        }
    }

    public boolean isOfferActive(String offerName) {
        EntityManager em = db.getEntityManager();
        try {
            OfertaConfig config = em.createQuery(
                            "SELECT o FROM OfertaConfig o WHERE o.nume = :nume",
                            OfertaConfig.class)
                    .setParameter("nume", offerName)
                    .getSingleResult();
            return config.isActiva();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean saveOfferConfig(String offerName, boolean active) {
        EntityManager em = db.getEntityManager();
        try {
            em.getTransaction().begin();

            OfertaConfig config;
            try {
                config = em.createQuery(
                                "SELECT o FROM OfertaConfig o WHERE o.nume = :nume",
                                OfertaConfig.class)
                        .setParameter("nume", offerName)
                        .getSingleResult();
                config.setActiva(active);
            } catch (Exception e) {
                config = new OfertaConfig(offerName, active);
                em.persist(config);
            }

            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            return false;
        }
    }

    public boolean updateProduct(Produs produs) {
        EntityManager em = db.getEntityManager();
        try {
            em.getTransaction().begin();
            em.merge(produs);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            return false;
        }
    }

    public boolean deleteProduct(Produs produs) {
        EntityManager em = db.getEntityManager();
        try {
            em.getTransaction().begin();
            Produs managed = em.merge(produs);
            em.remove(managed);
            em.getTransaction().commit();
            return true;
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            return false;
        }
    }

    // ===== ISTORIC GLOBAL =====
    public List<ComandaEntity> getAllOrders() {
        EntityManager em = db.getEntityManager();
        TypedQuery<ComandaEntity> q = em.createQuery(
                "SELECT c FROM ComandaEntity c ORDER BY c.dataOra DESC",
                ComandaEntity.class
        );
        return q.getResultList();
    }
}
