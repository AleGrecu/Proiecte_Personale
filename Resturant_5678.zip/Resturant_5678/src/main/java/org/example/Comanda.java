package org.example;

import java.util.ArrayList;
import java.util.List;

public class Comanda {
    private final double tva;

    private final List<LinieComandaEntity> linii = new ArrayList<>();

    public Comanda(double tva) {
        this.tva = tva;
    }

    public void adaugaProdus(Produs produs, int cantitate) {
        linii.add(new LinieComandaEntity(produs, cantitate));
    }

    public List<LinieComandaEntity> getLinii() {
        return List.copyOf(linii);
    }

    public double totalPreTax() {

        return linii.stream().mapToDouble(LinieComandaEntity::getSubtotal).sum();
    }

    public double totalWithPromotion(Promotion promo) {
        double subtotal = totalPreTax();
        double discount = Math.max(0.0, Math.min(promo.apply(this), subtotal));
        double taxable = subtotal - discount;
        return taxable * (1.0 + tva);
    }

    public double totalWithoutPromotion() {
        return totalPreTax() * (1.0 + tva);
    }

    public void afiseazaDetaliat() {
        afiseazaDetaliat(null);
    }

    public void afiseazaDetaliat(Promotion promo) {
        System.out.println("=== Comanda curentă ===");
        for (LinieComandaEntity linie : linii) {
            Produs p = linie.getProdus();

            double sub = linie.getSubtotal();
            System.out.printf("%2d x %-20s %8.2f RON   = %8.2f RON%n",
                    linie.getCantitate(), p.getNume(), p.getPret(), sub);
        }

        System.out.println("-----------------------------------------");

        double subtotal = totalPreTax();
        double discount = 0.0;
        if (promo != null) {
            discount = Math.max(0.0, Math.min(promo.apply(this), subtotal));
        }
        double taxable = subtotal - discount;
        double tvaVal = taxable * tva;
        double total = taxable + tvaVal;

        System.out.printf("Total (fara TVA): %28.2f RON%n", subtotal);
        if (promo != null && discount > 0.0) {
            System.out.printf("Discount: %36s-%.2f RON%n", "", discount);
        }
        System.out.printf("TVA %.0f%%: %36.2f RON%n", tva * 100, tvaVal);
        System.out.printf("Total de plata: %28.2f RON%n", total);
        System.out.println("========================\n");
    }

    public void afiseazaCuPromotii() {
        System.out.println("=== Comanda curentă ===");
        for (LinieComandaEntity linie : linii) {
            // CORECTAT: linie.subtotal() -> linie.getSubtotal()
            System.out.printf("%2d x %-20s %8.2f RON   = %8.2f RON%n",
                    linie.getCantitate(), linie.getProdus().getNume(),
                    linie.getProdus().getPret(), linie.getSubtotal());
        }

        System.out.println("-----------------------------------------");
        double subtotal = totalPreTax();
        System.out.printf("Subtotal: %36.2f RON%n", subtotal);


        List<PromotionEngine.DiscountLine> discounts = PromotionEngine.calculateDiscounts(linii);
        double totalDiscount = 0.0;
        for (PromotionEngine.DiscountLine d : discounts) {
            System.out.printf("  - %-30s -%.2f RON%n", d.getDescription(), d.getAmount());
            totalDiscount += d.getAmount();
        }

        double afterDiscount = subtotal - totalDiscount;
        double tvaAmount = afterDiscount * tva;
        double total = afterDiscount + tvaAmount;

        System.out.printf("TVA %.0f%%: %36.2f RON%n", tva * 100, tvaAmount);
        System.out.printf("Total de plată: %28.2f RON%n", total);
        System.out.println("========================\n");
    }
}