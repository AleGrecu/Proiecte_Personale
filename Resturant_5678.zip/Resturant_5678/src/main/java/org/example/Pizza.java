package org.example;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@DiscriminatorValue("PIZZA")
public final class Pizza extends Produs {

    public enum Blat { SUBTIRE, CLASIC, PUFFY }
    public enum Sos { ROSU, ALB, PICANT }

    @Enumerated(EnumType.STRING)
    private Blat blat;

    @Enumerated(EnumType.STRING)
    private Sos sos;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "pizza_toppinguri", joinColumns = @JoinColumn(name = "pizza_id"))
    @Column(name = "topping")
    private List<String> toppinguri = new ArrayList<>();

    // Constructor gol pentru JPA
    protected Pizza() {
        super();
    }

    private Pizza(String nume, double pret, Blat blat, Sos sos, List<String> toppinguri) {
        super(nume, pret, Categorie.PIZZA, eVegetarian(toppinguri));
        this.blat = blat;
        this.sos = sos;
        this.toppinguri = new ArrayList<>(toppinguri);
    }

    private static boolean eVegetarian(List<String> top) {
        return top.stream().noneMatch(t ->
                t.equalsIgnoreCase("salam") ||
                        t.equalsIgnoreCase("sunca") ||
                        t.equalsIgnoreCase("prosciutto") ||
                        t.equalsIgnoreCase("pepperoni") ||
                        t.equalsIgnoreCase("salam picant")
        );
    }

    public Blat getBlat() { return blat; }
    public Sos getSos() { return sos; }
    public List<String> getToppinguri() { return List.copyOf(toppinguri); }

    @Override
    protected String getSpecialInfo() {
        return "Pizza (" + blat + ", " + sos + ", " + toppinguri + ")";
    }

    public static class Builder {
        private final String nume;
        private final double pret;
        private Blat blat;
        private Sos sos;
        private final List<String> toppinguri = new ArrayList<>();

        public Builder(String nume, double pret) {
            this.nume = nume;
            this.pret = pret;
        }

        public Builder cuBlat(Blat blat) {
            this.blat = blat;
            return this;
        }

        public Builder cuSos(Sos sos) {
            this.sos = sos;
            return this;
        }

        public Builder adaugaTopping(String t) {
            toppinguri.add(t);
            return this;
        }

        public Pizza build() {
            if (blat == null || sos == null) {
                throw new IllegalStateException("Blatul și sosul sunt obligatorii!");
            }
            return new Pizza(nume, pret, blat, sos, toppinguri);
        }
    }
}
