package org.example;

import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;

public class Main {
    public static void main(String[] args) {
        DatabaseService db = new DatabaseService();
        initializeBasicData(db);
        db.close();

        MenuApp.main(args);
    }

    private static void initializeBasicData(DatabaseService db) {
        EntityManager em = db.getEntityManager();

        long tableCount = em.createQuery("SELECT COUNT(m) FROM Masa m", Long.class).getSingleResult();
        if (tableCount == 0) {
            em.getTransaction().begin();
            for (int i = 1; i <= 10; i++) {
                em.persist(new Masa(i, 4));
            }
            em.getTransaction().commit();
            System.out.println("✅ 10 mese au fost create");
        }

        try {
            em.createQuery("SELECT u FROM User u WHERE u.username = 'ion'", User.class).getSingleResult();
            System.out.println("✅ Utilizatorul 'ion' există deja");
        } catch (NoResultException e) {
            em.getTransaction().begin();
            em.persist(new User("ion", "1234", User.Role.WAITER));
            em.getTransaction().commit();
            System.out.println("✅ Utilizatorul 'ion' a fost creat");
        }

        try {
            em.createQuery("SELECT u FROM User u WHERE u.username = 'admin'", User.class).getSingleResult();
            System.out.println("✅ Utilizatorul 'admin' există deja");
        } catch (NoResultException e) {
            em.getTransaction().begin();
            em.persist(new User("admin", "admin", User.Role.MANAGER));
            em.getTransaction().commit();
            System.out.println("✅ Utilizatorul 'admin' (MANAGER) a fost creat");
        }

        long productCount = em.createQuery("SELECT COUNT(p) FROM Produs p", Long.class).getSingleResult();
        if (productCount == 0) {
            System.out.println("⚠️ Nu există produse în baza de date. Se inițializează...");
            initializeProducts(db);
        }
    }

    private static void initializeProducts(DatabaseService db) {
        Pizza pizzaMargherita = new Pizza.Builder("Pizza Margherita", 45.0)
                .cuBlat(Pizza.Blat.CLASIC)
                .cuSos(Pizza.Sos.ROSU)
                .adaugaTopping("mozzarella")
                .build();
        db.salvaProdus(pizzaMargherita);

        Pizza pizzaDiavola = new Pizza.Builder("Pizza Diavola", 60.0)
                .cuBlat(Pizza.Blat.CLASIC)
                .cuSos(Pizza.Sos.PICANT)
                .adaugaTopping("mozzarella")
                .adaugaTopping("salam picant")
                .build();
        db.salvaProdus(pizzaDiavola);

        Mancare pasteCarbonara = new Mancare("Paste Carbonara", 52.5, 400);
        db.salvaProdus(pasteCarbonara);

        Mancare lasagna = new Mancare("Lasagna", 55.0, 520);
        db.salvaProdus(lasagna);

        Mancare tiramisu = new Mancare("Tiramisu", 28.0, 180, Categorie.DESERT, true);
        db.salvaProdus(tiramisu);


        Bautura limonada = new Bautura("Limonada", 15.0, 400, false);
        db.salvaProdus(limonada);

        Bautura vinRosu = new Bautura("Vin Rosu", 25.0, 250, true);
        db.salvaProdus(vinRosu);

        System.out.println("✅ Produse adăugate cu succes!");
    }
}
