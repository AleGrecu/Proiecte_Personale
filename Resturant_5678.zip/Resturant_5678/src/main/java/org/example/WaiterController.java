package org.example;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class WaiterController {
    private final DatabaseService db;
    private final User waiter;

    public WaiterController(DatabaseService db, User waiter) {
        this.db = db;
        this.waiter = waiter;
    }

    public DatabaseService getDb() {
        return db;
    }

    public User getWaiter() {
        return waiter;
    }

    public List<Masa> getAllTables() {
        EntityManager em = db.getEntityManager();
        TypedQuery<Masa> query = em.createQuery("SELECT m FROM Masa m ORDER BY m.numar", Masa.class);
        return query.getResultList();
    }

    public List<Produs> getMenuProducts() {
        return db.incarcaToateProdusele();
    }

    public Optional<ComandaEntity> finalizeOrder(Masa masa, List<LinieComandaEntity> lines) {
        EntityManager em = db.getEntityManager();
        try {
            em.getTransaction().begin();

            Masa managedTable = em.merge(masa);
            User managedWaiter = em.merge(waiter);

            double subtotal = 0.0;
            for (LinieComandaEntity line : lines) {
                subtotal += line.getSubtotal();
            }

            double totalDiscount = 0.0;
            try {
                List<LinieComandaEntity> simpleLines = new ArrayList<>();
                for (LinieComandaEntity ent : lines) {
                    simpleLines.add(new LinieComandaEntity(ent.getProdus(), ent.getCantitate()));
                }
                var discounts = PromotionEngine.calculateDiscounts(simpleLines);
                for (var d : discounts) {
                    totalDiscount += d.getAmount();
                }
            } catch (Throwable ignored) {}

            double taxable = Math.max(0.0, subtotal - totalDiscount);
            double tva = new AppConfig().getTva();
            double tvaAmount = taxable * tva;
            double total = taxable + tvaAmount;

            ComandaEntity comanda = new ComandaEntity(managedTable, managedWaiter);
            comanda.setSubtotal(subtotal);
            comanda.setDiscount(totalDiscount);
            comanda.setTotal(total);

            for (LinieComandaEntity line : lines) {
                Produs managedProduct = em.merge(line.getProdus());
                LinieComandaEntity managedLine = new LinieComandaEntity(managedProduct, line.getCantitate());
                comanda.adaugaLinie(managedLine);
            }

            managedTable.setStatus(Masa.Status.OCUPATA);

            em.persist(comanda);
            em.getTransaction().commit();

            return Optional.of(comanda);

        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
            return Optional.empty();
        }
    }

    public List<ComandaEntity> getMyOrders() {
        EntityManager em = db.getEntityManager();
        TypedQuery<ComandaEntity> query = em.createQuery(
                "SELECT c FROM ComandaEntity c WHERE c.waiter = :waiter ORDER BY c.dataOra DESC",
                ComandaEntity.class
        );
        query.setParameter("waiter", waiter);
        return query.getResultList();
    }
}
