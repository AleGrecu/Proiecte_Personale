package org.example;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class RestaurantApp extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        DatabaseService db = new DatabaseService();

        LoginView loginView = new LoginView(db);
        Scene loginScene = new Scene(loginView, 400, 350);

        primaryStage.setTitle("La Andrei - Autentificare");
        primaryStage.setScene(loginScene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }
}
