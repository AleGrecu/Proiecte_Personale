// java
package org.example;

import jakarta.persistence.*;

@Entity
@Table(name = "mese")
public class Masa {

    public enum Status {
        LIBERA,
        OCUPATA,
        REZERVATA
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private int numar;

    @Column(nullable = false)
    private int capacitate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status = Status.LIBERA;

    protected Masa() {
        // JPA
    }

    public Masa(int numar, int capacitate) {
        this.numar = numar;
        this.capacitate = capacitate;
        this.status = Status.LIBERA;
    }

    public Long getId() {
        return id;
    }

    public int getNumar() {
        return numar;
    }

    public void setNumar(int numar) {
        this.numar = numar;
    }

    public int getCapacitate() {
        return capacitate;
    }

    public void setCapacitate(int capacitate) {
        this.capacitate = capacitate;
    }

    // Convenience alias used by UI code
    public int getLocuri() {
        return getCapacitate();
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        if (status == null) throw new IllegalArgumentException("Status cannot be null");
        this.status = status;
    }

    // Convenience boolean used by UI code
    public boolean isOcupata() {
        return this.status == Status.OCUPATA;
    }

    @Override
    public String toString() {
        return "Masa{" +
                "id=" + id +
                ", numar=" + numar +
                ", capacitate=" + capacitate +
                ", status=" + status +
                '}';
    }
}
