package org.example;

import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class LoginView extends VBox {
    private final DatabaseService db;
    private final TextField usernameField;
    private final PasswordField passwordField;

    public LoginView(DatabaseService db) {
        this.db = db;
        setSpacing(20);
        setPadding(new Insets(40));
        setAlignment(Pos.CENTER);
        setStyle("-fx-background-color: #2C3E50;");

        Label titleLabel = new Label("Autentificare");
        titleLabel.setStyle("-fx-font-size: 24px; -fx-text-fill: white; -fx-font-weight: bold;");

        usernameField = new TextField();
        usernameField.setPromptText("Utilizator");
        usernameField.setMaxWidth(300);

        passwordField = new PasswordField();
        passwordField.setPromptText("Parolă");
        passwordField.setMaxWidth(300);

        Button loginButton = new Button("Intră în cont");
        loginButton.setStyle("-fx-background-color: #27AE60; -fx-text-fill: white; -fx-font-size: 14px; -fx-padding: 10 30;");
        loginButton.setOnAction(e -> handleLogin());

        getChildren().addAll(titleLabel, usernameField, passwordField, loginButton);
    }

    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();

        if (username.isEmpty() || password.isEmpty()) {
            showAlert("Eroare", "Introduceți username și parolă!");
            return;
        }

        EntityManager em = db.getEntityManager();
        try {
            User user = em.createQuery("SELECT u FROM User u WHERE u.username = :username", User.class)
                    .setParameter("username", username)
                    .getSingleResult();

            if (!user.getPassword().equals(password)) {
                showAlert("Eroare", "Parolă incorectă!");
                return;
            }

            if (user.getRole() == User.Role.MANAGER) {
                Stage managerStage = new Stage();
                ManagerController managerController = new ManagerController(db, user);
                ManagerView managerView = new ManagerView(managerController);
                Scene managerScene = new Scene(managerView, 1200, 700);
                managerStage.setTitle("La Andrei - Manager Panel");
                managerStage.setScene(managerScene);
                managerStage.show();

                ((Stage) usernameField.getScene().getWindow()).close();

            } else if (user.getRole() == User.Role.WAITER) {
                Stage waiterStage = new Stage();
                WaiterController waiterController = new WaiterController(db, user);
                WaiterView waiterView = new WaiterView(waiterController);
                Scene waiterScene = new Scene(waiterView, 1400, 800);
                waiterStage.setTitle("La Andrei - Ospătar: " + user.getUsername());
                waiterStage.setScene(waiterScene);
                waiterStage.show();

                ((Stage) usernameField.getScene().getWindow()).close();

            } else {
                showAlert("Eroare", "Rol necunoscut!");
            }

        } catch (NoResultException e) {
            showAlert("Eroare", "Utilizator inexistent!");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Eroare", "Eroare la autentificare: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
