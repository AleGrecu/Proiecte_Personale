package org.example;

public enum Categorie {
    PIZZA,
    FEL_PRINCIPAL,
    DESERT,
    APERITIVE,
    BAUTURI_ALCOOLICE,
    BAUTURI_RACORITOARE
}
