package org.example;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class GuestController {
    private final DatabaseService db;

    public GuestController(DatabaseService db) {
        this.db = db;
    }

    public DatabaseService getDb() {
        return db;
    }

    public List<Produs> getFilteredProducts(
            Optional<Categorie> categorie,
            Optional<Double> minPrice,
            Optional<Double> maxPrice,
            Optional<Boolean> vegetarian,
            Optional<String> searchText
    ) {
        return db.incarcaToateProdusele().stream()
                .filter(p -> categorie.map(c -> p.getCategorie() == c).orElse(true))
                .filter(p -> minPrice.map(min -> p.getPret() >= min).orElse(true))
                .filter(p -> maxPrice.map(max -> p.getPret() <= max).orElse(true))
                .filter(p -> vegetarian.map(v -> p.isVegetarian() == v).orElse(true))
                .filter(p -> searchText.map(s -> p.getNume().toLowerCase().contains(s.toLowerCase())).orElse(true))
                .collect(Collectors.toList());
    }
}
