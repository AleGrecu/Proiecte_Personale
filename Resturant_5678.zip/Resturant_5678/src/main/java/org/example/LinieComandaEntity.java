package org.example;

import jakarta.persistence.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "linii_comanda")
public class LinieComandaEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "comanda_id", nullable = false)
    private ComandaEntity comanda;

    @ManyToOne
    @JoinColumn(name = "produs_id", nullable = false)
    private Produs produs;

    private int cantitate;

    @Column(name = "discounts_json", columnDefinition = "TEXT")
    private String discountsJson;


    @Transient
    private List<PromotionEngine.DiscountLine> appliedDiscounts = new ArrayList<>();

    private static final Gson gson = new Gson();
    private static final Type DISCOUNT_LIST_TYPE = new TypeToken<List<PromotionEngine.DiscountLine>>(){}.getType();

    protected LinieComandaEntity() {}

    public LinieComandaEntity(Produs produs, int cantitate) {
        this.produs = produs;
        this.cantitate = cantitate;
    }

    public Long getId() { return id; }
    public ComandaEntity getComanda() { return comanda; }
    public void setComanda(ComandaEntity comanda) { this.comanda = comanda; }
    public Produs getProdus() { return produs; }
    public void setProdus(Produs produs) { this.produs = produs; }
    public int getCantitate() { return cantitate; }
    public void setCantitate(int cantitate) { this.cantitate = cantitate; }

    public double getSubtotal() {
        return produs.getPret() * cantitate;
    }



    public List<PromotionEngine.DiscountLine> getAppliedDiscounts() {

        if (appliedDiscounts.isEmpty() && discountsJson != null && !discountsJson.isEmpty()) {
            try {
                appliedDiscounts = gson.fromJson(discountsJson, DISCOUNT_LIST_TYPE);
            } catch (Exception e) {
                appliedDiscounts = new ArrayList<>();
            }
        }
        return appliedDiscounts;
    }

    public void setAppliedDiscounts(List<PromotionEngine.DiscountLine> discounts) {
        this.appliedDiscounts = discounts != null ? new ArrayList<>(discounts) : new ArrayList<>();
        this.discountsJson = gson.toJson(this.appliedDiscounts);
    }

    public double getTotalDiscount() {
        return getAppliedDiscounts().stream()
                .mapToDouble(PromotionEngine.DiscountLine::getAmount)
                .sum();
    }

    @PrePersist
    @PreUpdate
    private void serializeDiscounts() {
        if (!appliedDiscounts.isEmpty()) {
            this.discountsJson = gson.toJson(appliedDiscounts);
        }
    }

    @PostLoad
    private void deserializeDiscounts() {
        if (discountsJson != null && !discountsJson.isEmpty()) {
            try {
                appliedDiscounts = gson.fromJson(discountsJson, DISCOUNT_LIST_TYPE);
            } catch (Exception e) {
                appliedDiscounts = new ArrayList<>();
            }
        }
    }
}
