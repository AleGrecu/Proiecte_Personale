package org.example;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.List;
import java.util.Optional;

public class GuestView extends BorderPane {
    private final GuestController controller;
    private final TableView<Produs> table = new TableView<>();
    private final ObservableList<Produs> tableItems = FXCollections.observableArrayList();

    private final Label detailsName = new Label();
    private final Label detailsPrice = new Label();

    // cart UI
    private final ObservableList<String> cartItems = FXCollections.observableArrayList();
    private final ListView<String> cartListView = new ListView<>(cartItems);

    public GuestView(DatabaseService db) {
        this.controller = new GuestController(db);
        buildUI();
        applyFilters("", null, false, "", "");
    }

    private void buildUI() {
        setStyle("-fx-background-color: #f5f5f5;");

        HBox topBar = new HBox(15);
        topBar.setPadding(new Insets(15));
        topBar.setAlignment(Pos.CENTER_LEFT);
        topBar.setStyle("-fx-background-color: white; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 10, 0, 0, 2);");

        TextField searchField = new TextField();
        searchField.setPromptText("🔍 Caută produs...");
        searchField.setPrefWidth(400);
        searchField.setStyle("-fx-font-size: 14px;");

        Button filterBtn = new Button("🔧 Filtre");
        filterBtn.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 8 20;");

        topBar.getChildren().addAll(searchField, filterBtn);
        setTop(topBar);

        VBox centerBox = new VBox(10);
        centerBox.setPadding(new Insets(15, 10, 15, 15));

        Label tableTitle = new Label("📋 Meniu");
        tableTitle.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #333;");

        table.setStyle("-fx-background-color: white;");
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Produs, String> nameCol = new TableColumn<>("Nume Produs");
        nameCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getNume()));

        TableColumn<Produs, String> catCol = new TableColumn<>("Categorie");
        catCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getCategorie().name()));

        TableColumn<Produs, String> priceCol = new TableColumn<>("Preț");
        priceCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(String.format("%.2f RON", c.getValue().getPret())));

        TableColumn<Produs, String> vegCol = new TableColumn<>("🌱");
        vegCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().isVegetarian() ? "✓" : ""));

        table.getColumns().addAll(nameCol, catCol, priceCol, vegCol);
        table.setItems(tableItems);

        VBox.setVgrow(table, Priority.ALWAYS);
        centerBox.getChildren().addAll(tableTitle, table);
        setCenter(centerBox);

        VBox rightPanel = new VBox(20);
        rightPanel.setPrefWidth(320);
        rightPanel.setPadding(new Insets(15));
        rightPanel.setStyle("-fx-background-color: white; -fx-border-color: #e0e0e0; -fx-border-width: 0 0 0 1;");

        VBox loginBox = new VBox(10);
        loginBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 15; -fx-border-color: #ddd; -fx-border-radius: 5; -fx-background-radius: 5;");

        Label loginTitle = new Label("👤 Login");
        loginTitle.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #333;");

        Button loginBtn = new Button("Autentificare");
        loginBtn.setMaxWidth(Double.MAX_VALUE);
        loginBtn.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 10;");

        loginBox.getChildren().addAll(loginTitle, loginBtn);

        VBox detailsBox = new VBox(15);
        detailsBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 15; -fx-border-color: #ddd; -fx-border-radius: 5; -fx-background-radius: 5;");

        Label detailsTitle = new Label("📄 Detalii Produs");
        detailsTitle.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #333;");

        detailsName.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #1976D2;");
        detailsName.setWrapText(true);

        detailsPrice.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #4CAF50;");

        HBox quantityBox = new HBox(10);
        quantityBox.setAlignment(Pos.CENTER_LEFT);
        Label qtyLabel = new Label("Cantitate:");
        Spinner<Integer> quantitySpinner = new Spinner<>(1, 99, 1);
        quantitySpinner.setPrefWidth(80);
        quantityBox.getChildren().addAll(qtyLabel, quantitySpinner);

        Button addToCartBtn = new Button("🛒 Adaugă în coș");
        addToCartBtn.setMaxWidth(Double.MAX_VALUE);
        addToCartBtn.setStyle("-fx-background-color: #FF9800; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 10;");
        addToCartBtn.setDisable(true);

        Label infoLabel = new Label("💡 Selectează un produs din meniu");
        infoLabel.setWrapText(true);
        infoLabel.setStyle("-fx-font-size: 11px; -fx-text-fill: #999; -fx-font-style: italic;");

        detailsBox.getChildren().addAll(detailsTitle, new Separator(), detailsName, detailsPrice, quantityBox, addToCartBtn, infoLabel);

        // spacer to push cart to bottom
        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        // small cart box at bottom-right
        VBox cartBox = new VBox(8);
        cartBox.setPadding(new Insets(10));
        cartBox.setStyle("-fx-background-color: #fff8e1; -fx-border-color: #ffd54f; -fx-border-radius: 6; -fx-background-radius: 6;");
        cartBox.setMaxWidth(Double.MAX_VALUE);
        cartBox.setPrefWidth(280);

        Label cartTitle = new Label("Comanda ta:");
        cartTitle.setStyle("-fx-font-weight: bold; -fx-text-fill: #795548;");
        cartListView.setPrefHeight(110);
        cartListView.setFocusTraversable(false);
        cartListView.setPlaceholder(new Label("Nicio produs adăugat"));

        cartBox.getChildren().addAll(cartTitle, cartListView);

        rightPanel.getChildren().addAll(loginBox, detailsBox, spacer, cartBox);
        setRight(rightPanel);

        searchField.setOnAction(e -> applyFilters(searchField.getText(), null, false, "", ""));
        filterBtn.setOnAction(e -> showFilterDialog(searchField.getText()));

        table.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                detailsName.setText(newSel.getNume());
                detailsPrice.setText(String.format("%.2f RON", newSel.getPret()));
                addToCartBtn.setDisable(false);
            } else {
                detailsName.setText("");
                detailsPrice.setText("");
                addToCartBtn.setDisable(true);
            }
        });

        loginBtn.setOnAction(e -> {
            Stage loginStage = new Stage();
            LoginView loginView = new LoginView(controller.getDb());
            Scene loginScene = new Scene(loginView, 500, 400);
            loginStage.setTitle("Autentificare Ospătar");
            loginStage.setScene(loginScene);
            loginStage.show();
        });

        // add to cart action: append product + qty to cart list
        addToCartBtn.setOnAction(e -> {
            Produs sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) return;
            int qty = quantitySpinner.getValue();
            String entry = String.format("%s x%d", sel.getNume(), qty);
            cartItems.add(entry);
            infoLabel.setText("✅ Adăugat: " + sel.getNume());
        });

    }

    private void showFilterDialog(String currentSearch) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("🔧 Filtre Avansate");
        dialog.setHeaderText("Configurează filtrele pentru meniu");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        ComboBox<String> categorieCombo = new ComboBox<>(
                FXCollections.observableArrayList("Toate", "APERITIVE", "FEL_PRINCIPAL", "DESERT", "BAUTURI_RACORITOARE", "BAUTURI_ALCOOLICE", "PIZZA")
        );
        categorieCombo.setValue("Toate");

        CheckBox vegetarianOnly = new CheckBox("Doar produse vegetariene");
        TextField minPrice = new TextField();
        minPrice.setPromptText("ex: 10");
        TextField maxPrice = new TextField();
        maxPrice.setPromptText("ex: 100");

        grid.add(new Label("Categorie:"), 0, 0);
        grid.add(categorieCombo, 1, 0);
        grid.add(vegetarianOnly, 0, 1, 2, 1);
        grid.add(new Label("Preț minim (RON):"), 0, 2);
        grid.add(minPrice, 1, 2);
        grid.add(new Label("Preț maxim (RON):"), 0, 3);
        grid.add(maxPrice, 1, 3);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.APPLY, ButtonType.CANCEL);

        dialog.showAndWait().ifPresent(result -> {
            if (result == ButtonType.APPLY) {
                applyFilters(currentSearch, categorieCombo.getValue(), vegetarianOnly.isSelected(),
                        minPrice.getText(), maxPrice.getText());
            }
        });
    }

    private void applyFilters(String searchText, String categorieValue, boolean vegetarianOnly,
                              String minPriceText, String maxPriceText) {
        Optional<Categorie> catOpt = Optional.empty();
        if (categorieValue != null && !"Toate".equals(categorieValue)) {
            try {
                catOpt = Optional.of(Categorie.valueOf(categorieValue));
            } catch (IllegalArgumentException ignored) {}
        }

        Optional<Double> minOpt = tryParseDouble(minPriceText);
        Optional<Double> maxOpt = tryParseDouble(maxPriceText);
        Optional<Boolean> vegOpt = vegetarianOnly ? Optional.of(true) : Optional.empty();
        Optional<String> searchOpt = (searchText == null || searchText.isBlank())
                ? Optional.empty()
                : Optional.of(searchText.trim());

        List<Produs> filtered = controller.getFilteredProducts(catOpt, minOpt, maxOpt, vegOpt, searchOpt);
        tableItems.setAll(filtered);
    }

    private Optional<Double> tryParseDouble(String text) {
        if (text == null || text.isBlank()) return Optional.empty();
        try {
            return Optional.of(Double.parseDouble(text.trim()));
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }
}
