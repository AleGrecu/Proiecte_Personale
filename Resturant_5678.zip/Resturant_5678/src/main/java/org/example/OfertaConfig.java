package org.example;

import jakarta.persistence.*;

@Entity
@Table(name = "oferte_config")
public class OfertaConfig {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String nume;

    @Column(nullable = false)
    private boolean activa;

    protected OfertaConfig() {}

    public OfertaConfig(String nume, boolean activa) {
        this.nume = nume;
        this.activa = activa;
    }

    public Long getId() { return id; }
    public String getNume() { return nume; }
    public boolean isActiva() { return activa; }
    public void setActiva(boolean activa) { this.activa = activa; }
}
