package org.example;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("MANCARE")
public final class Mancare extends Produs {
    private final int gramaj;

    // Constructor gol pentru JPA
    protected Mancare() {
        super();
        this.gramaj = 0;
    }

    public Mancare(String nume, double pret, int gramaj) {
        super(nume, pret, Categorie.FEL_PRINCIPAL, false);
        this.gramaj = gramaj;
    }

    public Mancare(String nume, double pret, int gramaj, Categorie categorie, boolean vegetarian) {
        super(nume, pret, categorie, vegetarian);
        this.gramaj = gramaj;
    }

    public int getGramaj() {
        return gramaj;
    }

    @Override
    protected String getSpecialInfo() {
        return "Gramaj: " + gramaj + "g";
    }
}
