package org.example;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.concurrent.Task;
import javafx.application.Platform;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MenuView extends BorderPane {
    private final ManagerController controller;

    // TAB 1: Personal
    private final TableView<User> employeesTable = new TableView<>();
    private final ObservableList<User> employeesData = FXCollections.observableArrayList();

    // TAB 2: Meniu
    private final TableView<Produs> menuTable = new TableView<>();
    private final ObservableList<Produs> menuData = FXCollections.observableArrayList();

    // TAB 3: Oferte
    private CheckBox happyHourCheck;
    private CheckBox mealDealCheck;
    private CheckBox partyPackCheck;


    private final TableView<ComandaEntity> ordersTable = new TableView<>();
    private final ObservableList<ComandaEntity> ordersData = FXCollections.observableArrayList();

    // Background executor for async loading
    private final ExecutorService bgExecutor = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r);
        t.setDaemon(true);
        return t;
    });

    public MenuView(ManagerController controller) {
        this.controller = controller;
        buildUI();
        loadEmployeesAsync();
        loadMenuProductsAsync();
        loadOrdersAsync();
    }

    private void buildUI() {
        setStyle("-fx-background-color: #ecf0f1;");

        TabPane tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        Tab employeesTab = createTab("👥 Angajați", buildEmployeesTab());
        Tab menuTab = createTab("🍕 Meniu", buildMenuTab());
        Tab offersTab = createTab("🎁 Oferte", buildOffersTab());
        Tab ordersTab = createTab("📊 Istoric Comenzi", buildOrdersTab());

        tabPane.getTabs().addAll(employeesTab, menuTab, offersTab, ordersTab);
        setCenter(tabPane);
    }

    private Tab createTab(String title, VBox content) {
        Tab tab = new Tab(title);
        tab.setContent(content);
        return tab;
    }

    // ===== TAB 1: PERSONAL =====
    private VBox buildEmployeesTab() {
        VBox box = new VBox(15);
        box.setPadding(new Insets(20));

        Label title = new Label("👥 Gestionare Ospătari");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        employeesTable.setStyle("-fx-background-color: white;");
        employeesTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<User, String> usernameCol = new TableColumn<>("Username");
        usernameCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getUsername()));

        TableColumn<User, String> roleCol = new TableColumn<>("Rol");
        roleCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getRole().name()));

        employeesTable.getColumns().addAll(usernameCol, roleCol);
        employeesTable.setItems(employeesData);

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER_LEFT);

        Button addBtn = new Button("➕ Adaugă Ospătar");
        addBtn.setStyle("-fx-background-color: #27AE60; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 10 20;");
        addBtn.setOnAction(e -> addEmployee());

        Button editBtn = new Button("✏ Editează");
        editBtn.setStyle("-fx-background-color: #3498DB; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 10 20;");
        editBtn.setOnAction(e -> editEmployee());

        Button deleteBtn = new Button("🗑 Șterge");
        deleteBtn.setStyle("-fx-background-color: #E74C3C; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 10 20;");
        deleteBtn.setOnAction(e -> deleteEmployee());

        buttonBox.getChildren().addAll(addBtn, editBtn, deleteBtn);

        VBox.setVgrow(employeesTable, Priority.ALWAYS);
        box.getChildren().addAll(title, employeesTable, buttonBox);
        return box;
    }

    private void addEmployee() {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Adaugă Ospătar");
        dialog.setHeaderText("Introdu datele noului ospătar:");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Parolă");

        grid.add(new Label("Username:"), 0, 0);
        grid.add(usernameField, 1, 0);
        grid.add(new Label("Parolă:"), 0, 1);
        grid.add(passwordField, 1, 1);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.showAndWait().ifPresent(result -> {
            if (result == ButtonType.OK) {
                String username = usernameField.getText().trim();
                String password = passwordField.getText().trim();
                if (!username.isEmpty() && !password.isEmpty()) {
                    if (controller.createWaiter(username, password)) {
                        loadEmployeesAsync();
                        showAlert("Succes", "Ospătarul a fost adăugat cu succes!");
                    } else {
                        showAlert("Eroare", "Nu s-a putut adăuga ospătarul!");
                    }
                }
            }
        });
    }

    private void editEmployee() {
        User selected = employeesTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Atenție", "Selectează un ospătar pentru editare!");
            return;
        }

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Editează Ospătar");
        dialog.setHeaderText("Modifică parola pentru: " + selected.getUsername());

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20));

        PasswordField newPasswordField = new PasswordField();
        newPasswordField.setPromptText("Parolă nouă");

        grid.add(new Label("Parolă nouă:"), 0, 0);
        grid.add(newPasswordField, 1, 0);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.showAndWait().ifPresent(result -> {
            if (result == ButtonType.OK) {
                String newPassword = newPasswordField.getText().trim();
                if (!newPassword.isEmpty()) {
                    if (controller.updateWaiter(selected, newPassword)) {
                        loadEmployeesAsync();
                        showAlert("Succes", "Parola a fost actualizată!");
                    } else {
                        showAlert("Eroare", "Nu s-a putut actualiza parola!");
                    }
                }
            }
        });
    }

    private void deleteEmployee() {
        User selected = employeesTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Atenție", "Selectează un ospătar pentru ștergere!");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirmare ștergere");
        confirm.setHeaderText("Ești sigur că vrei să ștergi ospătarul: " + selected.getUsername() + "?");
        confirm.setContentText("Această acțiune nu poate fi anulată!");

        confirm.showAndWait().ifPresent(result -> {
            if (result == ButtonType.OK) {
                if (controller.deleteWaiter(selected)) {
                    loadEmployeesAsync();
                    showAlert("Succes", "Ospătarul a fost șters!");
                } else {
                    showAlert("Eroare", "Nu s-a putut șterge ospătarul!");
                }
            }
        });
    }

    // ===== TAB 2: MENIU =====
    private VBox buildMenuTab() {
        HBox mainBox = new HBox(15);
        mainBox.setPadding(new Insets(20));

        VBox leftPanel = new VBox(15);
        leftPanel.setPrefWidth(700);

        Label title = new Label("🍕 Produse din Meniu");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        menuTable.setStyle("-fx-background-color: white;");
        menuTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Produs, String> nameCol = new TableColumn<>("Nume");
        nameCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getNume()));

        TableColumn<Produs, String> priceCol = new TableColumn<>("Preț");
        priceCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(String.format("%.2f RON", c.getValue().getPret())));

        TableColumn<Produs, String> categoryCol = new TableColumn<>("Categorie");
        categoryCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getCategorie().name()));

        menuTable.getColumns().addAll(nameCol, priceCol, categoryCol);
        menuTable.setItems(menuData);

        VBox.setVgrow(menuTable, Priority.ALWAYS);
        leftPanel.getChildren().addAll(title, menuTable);

        VBox rightPanel = buildMenuFormPanel();

        mainBox.getChildren().addAll(leftPanel, rightPanel);
        HBox.setHgrow(leftPanel, Priority.ALWAYS);

        VBox container = new VBox(mainBox);
        return container;
    }

    private VBox buildMenuFormPanel() {
        VBox panel = new VBox(15);
        panel.setPrefWidth(350);
        panel.setPadding(new Insets(15));
        panel.setStyle("-fx-background-color: white; -fx-border-color: #ddd; -fx-border-width: 1; -fx-border-radius: 5; -fx-background-radius: 5;");

        Label formTitle = new Label("📝 Gestionare Produs");
        formTitle.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #333;");

        Separator separator = new Separator();

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(12);

        Label nameLabel = new Label("Nume produs:");
        TextField nameField = new TextField();
        nameField.setPromptText("ex: Pizza Margherita");

        Label priceLabel = new Label("Preț (RON):");
        TextField priceField = new TextField();
        priceField.setPromptText("ex: 45.50");

        Label categoryLabel = new Label("Categorie:");
        ComboBox<Categorie> categoryCombo = new ComboBox<>();
        categoryCombo.getItems().addAll(Categorie.values());
        categoryCombo.setValue(Categorie.FEL_PRINCIPAL);
        categoryCombo.setMaxWidth(Double.MAX_VALUE);

        grid.add(nameLabel, 0, 0);
        grid.add(nameField, 0, 1);
        grid.add(priceLabel, 0, 2);
        grid.add(priceField, 0, 3);
        grid.add(categoryLabel, 0, 4);
        grid.add(categoryCombo, 0, 5);

        grid.setMaxWidth(Double.MAX_VALUE);
        nameField.setMaxWidth(Double.MAX_VALUE);
        priceField.setMaxWidth(Double.MAX_VALUE);

        VBox buttonBox = new VBox(10);

        Button addBtn = new Button("➕ Adaugă Produs Nou");
        addBtn.setMaxWidth(Double.MAX_VALUE);
        addBtn.setStyle("-fx-background-color: #27AE60; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 12;");
        addBtn.setOnAction(e -> {
            String name = nameField.getText().trim();
            String priceText = priceField.getText().trim();
            Categorie category = categoryCombo.getValue();

            if (name.isEmpty() || priceText.isEmpty()) {
                showAlert("Eroare", "Completează toate câmpurile!");
                return;
            }

            try {
                double price = Double.parseDouble(priceText);
                if (controller.createProduct(name, price, category)) {
                    loadMenuProductsAsync();
                    nameField.clear();
                    priceField.clear();
                    categoryCombo.setValue(Categorie.FEL_PRINCIPAL);
                    showAlert("Succes", "Produsul a fost adăugat!");
                } else {
                    showAlert("Eroare", "Nu s-a putut adăuga produsul!");
                }
            } catch (NumberFormatException ex) {
                showAlert("Eroare", "Preț invalid!");
            }
        });

        Button editBtn = new Button("✏ Editează Produsul Selectat");
        editBtn.setMaxWidth(Double.MAX_VALUE);
        editBtn.setStyle("-fx-background-color: #3498DB; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 12;");
        editBtn.setOnAction(e -> {
            Produs selected = menuTable.getSelectionModel().getSelectedItem();
            if (selected == null) {
                showAlert("Atenție", "Selectează un produs!");
                return;
            }

            String name = nameField.getText().trim();
            String priceText = priceField.getText().trim();

            if (name.isEmpty() || priceText.isEmpty()) {
                showAlert("Eroare", "Completează toate câmpurile!");
                return;
            }

            try {
                double price = Double.parseDouble(priceText);
                selected.setNume(name);
                selected.setPret(price);

                if (controller.updateProduct(selected)) {
                    loadMenuProductsAsync();
                    showAlert("Succes", "Produsul a fost actualizat!");
                } else {
                    showAlert("Eroare", "Nu s-a putut actualiza produsul!");
                }
            } catch (NumberFormatException ex) {
                showAlert("Eroare", "Preț invalid!");
            }
        });

        Button deleteBtn = new Button("🗑 Șterge Produsul Selectat");
        deleteBtn.setMaxWidth(Double.MAX_VALUE);
        deleteBtn.setStyle("-fx-background-color: #E74C3C; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 12;");
        deleteBtn.setOnAction(e -> {
            Produs selected = menuTable.getSelectionModel().getSelectedItem();
            if (selected == null) {
                showAlert("Atenție", "Selectează un produs pentru ștergere!");
                return;
            }

            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Confirmare ștergere");
            confirm.setHeaderText("Ștergi produsul: " + selected.getNume() + "?");
            confirm.showAndWait().ifPresent(result -> {
                if (result == ButtonType.OK) {
                    if (controller.deleteProduct(selected)) {
                        loadMenuProductsAsync();
                        nameField.clear();
                        priceField.clear();
                        showAlert("Succes", "Produsul a fost șters!");
                    } else {
                        showAlert("Eroare", "Nu s-a putut șterge produsul!");
                    }
                }
            });
        });

        Button clearBtn = new Button("🔄 Curăță Formular");
        clearBtn.setMaxWidth(Double.MAX_VALUE);
        clearBtn.setStyle("-fx-background-color: #95A5A6; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 12;");
        clearBtn.setOnAction(e -> {
            nameField.clear();
            priceField.clear();
            categoryCombo.setValue(Categorie.FEL_PRINCIPAL);
            menuTable.getSelectionModel().clearSelection();
        });

        buttonBox.getChildren().addAll(addBtn, editBtn, deleteBtn, clearBtn);

        menuTable.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                nameField.setText(newVal.getNume());
                priceField.setText(String.valueOf(newVal.getPret()));
                categoryCombo.setValue(newVal.getCategorie());
            }
        });

        panel.getChildren().addAll(formTitle, separator, grid, buttonBox);
        return panel;
    }

    // ===== TAB 3: OFERTE =====
    private VBox buildOffersTab() {
        VBox box = new VBox(15);
        box.setPadding(new Insets(20));
        box.setStyle("-fx-background-color: white;");

        Label title = new Label("⚙️ Configurare Oferte");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #333;");

        VBox offersBox = new VBox(12);
        offersBox.setPadding(new Insets(15));
        offersBox.setStyle("-fx-background-color: #f9f9f9; -fx-border-color: #ddd; -fx-border-width: 1; -fx-border-radius: 5; -fx-background-radius: 5;");

        happyHourCheck = new CheckBox("Happy Hour Drinks (50% la a doua băutură)");
        mealDealCheck = new CheckBox("Meal Deal (25% reducere la desert cu Pizza)");
        partyPackCheck = new CheckBox("Party Pack (Pizza gratuită la 4 comandate)");

        happyHourCheck.setStyle("-fx-font-size: 14px;");
        mealDealCheck.setStyle("-fx-font-size: 14px;");
        partyPackCheck.setStyle("-fx-font-size: 14px;");

        happyHourCheck.setSelected(controller.isOfferActive("HAPPY_HOUR"));
        mealDealCheck.setSelected(controller.isOfferActive("MEAL_DEAL"));
        partyPackCheck.setSelected(controller.isOfferActive("PARTY_PACK"));

        offersBox.getChildren().addAll(happyHourCheck, mealDealCheck, partyPackCheck);

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER_LEFT);
        buttonBox.setPadding(new Insets(15, 0, 0, 0));

        Button saveBtn = new Button("💾 Salvează Configurația");
        saveBtn.setStyle("-fx-background-color: #27AE60; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 12 25; -fx-font-size: 14px;");
        saveBtn.setOnAction(e -> saveOffers());

        Button resetBtn = new Button("🔄 Resetează");
        resetBtn.setStyle("-fx-background-color: #95A5A6; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 12 25; -fx-font-size: 14px;");
        resetBtn.setOnAction(e -> {
            happyHourCheck.setSelected(controller.isOfferActive("HAPPY_HOUR"));
            mealDealCheck.setSelected(controller.isOfferActive("MEAL_DEAL"));
            partyPackCheck.setSelected(controller.isOfferActive("PARTY_PACK"));
            showAlert("Info", "Configurația a fost resetată la valorile salvate.");
        });

        buttonBox.getChildren().addAll(saveBtn, resetBtn);

        Label infoLabel = new Label("ℹ️ Ofertele activate vor fi aplicate automat la comenzile noi.");
        infoLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #7f8c8d; -fx-font-style: italic;");
        infoLabel.setWrapText(true);

        box.getChildren().addAll(title, offersBox, buttonBox, infoLabel);
        return box;
    }

    private void saveOffers() {
        boolean success = true;

        success &= controller.saveOfferConfig("HAPPY_HOUR", happyHourCheck.isSelected());
        success &= controller.saveOfferConfig("MEAL_DEAL", mealDealCheck.isSelected());
        success &= controller.saveOfferConfig("PARTY_PACK", partyPackCheck.isSelected());

        if (success) {
            showAlert("✅ Succes",
                    "Configurația ofertelor a fost salvată!\n\n" +
                            "📊 Status curent:\n" +
                            "• Happy Hour: " + (happyHourCheck.isSelected() ? "✓ ACTIVĂ" : "✗ Dezactivată") + "\n" +
                            "• Meal Deal: " + (mealDealCheck.isSelected() ? "✓ ACTIVĂ" : "✗ Dezactivată") + "\n" +
                            "• Party Pack: " + (partyPackCheck.isSelected() ? "✓ ACTIVĂ" : "✗ Dezactivată")
            );
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Eroare");
            alert.setHeaderText("Nu s-a putut salva configurația");
            alert.setContentText("A apărut o eroare la salvarea ofertelor în baza de date.");
            alert.showAndWait();
        }
    }

    // ===== TAB 4: ISTORIC =====
    private VBox buildOrdersTab() {
        VBox box = new VBox(15);
        box.setPadding(new Insets(20));
        box.setStyle("-fx-background-color: white;");

        Label title = new Label("📊 Istoric Comenzi");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        ordersTable.setStyle("-fx-background-color: #ffffff; -fx-border-color: #bdc3c7;");
        ordersTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<ComandaEntity, String> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(String.valueOf(c.getValue().getId())));
        idCol.setPrefWidth(60);

        TableColumn<ComandaEntity, String> masaCol = new TableColumn<>("Masa");
        masaCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(String.valueOf(c.getValue().getMasa().getNumar())));
        masaCol.setPrefWidth(80);

        TableColumn<ComandaEntity, String> waiterCol = new TableColumn<>("Ospătar");
        waiterCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getWaiter().getUsername()));

        TableColumn<ComandaEntity, String> dataCol = new TableColumn<>("Data/Ora");
        dataCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(
                c.getValue().getDataOra().format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm"))
        ));
        dataCol.setPrefWidth(150);

        TableColumn<ComandaEntity, String> totalCol = new TableColumn<>("Total");
        totalCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(
                String.format("%.2f RON", c.getValue().getTotal())
        ));
        totalCol.setPrefWidth(120);

        ordersTable.getColumns().addAll(idCol, masaCol, waiterCol, dataCol, totalCol);
        ordersTable.setItems(ordersData);

        VBox.setVgrow(ordersTable, Priority.ALWAYS);
        box.getChildren().addAll(title, ordersTable);
        return box;
    }

    // ===== ASYNC LOADERS =====
    private void loadEmployeesAsync() {
        Task<List<User>> task = new Task<>() {
            @Override
            protected List<User> call() {
                return controller.getAllWaiters();
            }
        };
        task.setOnSucceeded(e -> employeesData.setAll(task.getValue()));
        task.setOnFailed(e -> Platform.runLater(() -> showAlert("Eroare", "Nu s-au putut încărca angajații.")));
        bgExecutor.execute(task);
    }

    private void loadMenuProductsAsync() {
        Task<List<Produs>> task = new Task<>() {
            @Override
            protected List<Produs> call() {
                return controller.getAllProducts();
            }
        };
        task.setOnSucceeded(e -> menuData.setAll(task.getValue()));
        task.setOnFailed(e -> Platform.runLater(() -> showAlert("Eroare", "Nu s-au putut încărca produsele.")));
        bgExecutor.execute(task);
    }

    private void loadOrdersAsync() {
        Task<List<ComandaEntity>> task = new Task<>() {
            @Override
            protected List<ComandaEntity> call() {
                return controller.getAllOrders();
            }
        };
        task.setOnSucceeded(e -> ordersData.setAll(task.getValue()));
        task.setOnFailed(e -> Platform.runLater(() -> showAlert("Eroare", "Nu s-a putut încărca istoricul comenzilor.")));
        bgExecutor.execute(task);
    }

    // Legacy synchronous methods kept for compatibility (not used by constructor)
    @SuppressWarnings("unused")
    private void loadEmployees() {
        employeesData.setAll(controller.getAllWaiters());
    }

    @SuppressWarnings("unused")
    private void loadMenuProducts() {
        menuData.setAll(controller.getAllProducts());
    }

    @SuppressWarnings("unused")
    private void loadOrders() {
        ordersData.setAll(controller.getAllOrders());
    }

    // Call this from your application shutdown/scene change to stop background threads
    public void shutdownBackground() {
        bgExecutor.shutdownNow();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void logout() {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirmare deconectare");
        confirm.setHeaderText("Ești sigur că vrei să te deconectezi?");
        confirm.setContentText("Vei fi redirecționat către ecranul de autentificare.");

        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            // implement scene change / logout behaviour in your app
        }
    }
}
