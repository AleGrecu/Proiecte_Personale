package org.example;

import javafx.collections.FXCollections;
import jakarta.persistence.EntityManager;

import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class WaiterView extends BorderPane {
    private final WaiterController controller;

    private final FlowPane tablesPane = new FlowPane();
    private final TableView<Produs> menuTable = new TableView<>();
    private final ObservableList<Produs> menuItems = FXCollections.observableArrayList();

    private final ListView<String> cartListView = new ListView<>();
    private final ObservableList<LinieComandaEntity> cartLines = FXCollections.observableArrayList();

    private final Label subtotalLabel = new Label("Subtotal: 0,00 RON");
    private final Label discountLabel = new Label("Discount: 0,00 RON");
    private final Label totalLabel = new Label("Total: 0,00 RON");

    private final Spinner<Integer> qtySpinner = new Spinner<>(1, 99, 1);
    private final Label detailsName = new Label();
    private final Label detailsPrice = new Label();

    private Masa selectedTable = null;
    private final Label orderTitle = new Label("Selectați o masă pentru a începe comanda");

    private final TableView<ComandaEntity> historyTable = new TableView<>();
    private final ObservableList<ComandaEntity> historyItems = FXCollections.observableArrayList();

    public WaiterView(WaiterController controller) {
        this.controller = controller;
        buildUI();
        loadTables();
        loadMenu();
        refreshHistory();
    }

    private void buildUI() {
        HBox header = new HBox(15);
        header.setPadding(new Insets(15));
        header.setAlignment(Pos.CENTER_LEFT);
        header.setStyle("-fx-background-color: #34495E;");

        Label titleLabel = new Label("Ospătar: " + controller.getWaiter().getUsername());
        titleLabel.setStyle("-fx-font-size: 20px; -fx-text-fill: white; -fx-font-weight: bold;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button refreshBtn = new Button("Reset & Refresh");
        refreshBtn.setStyle("-fx-background-color: #E74C3C; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 8 15;");
        refreshBtn.setOnAction(e -> resetTablesAndRefresh());

        header.getChildren().addAll(titleLabel, spacer, refreshBtn);
        setTop(header);

        TabPane tabPane = new TabPane();
        Tab orderTab = new Tab("Order", buildOrderTab());
        orderTab.setClosable(false);
        Tab historyTab = new Tab("Orders History", buildHistoryTab());
        historyTab.setClosable(false);
        tabPane.getTabs().addAll(orderTab, historyTab);
        setCenter(tabPane);
    }

    private VBox buildOrderTab() {
        HBox mainLayout = new HBox(10);
        mainLayout.setPadding(new Insets(10));

        VBox leftBox = new VBox(10);
        leftBox.setPrefWidth(400);

        ScrollPane tablesScroll = new ScrollPane(tablesPane);
        tablesScroll.setFitToWidth(true);
        tablesScroll.setStyle("-fx-background-color: white;");
        tablesPane.setHgap(10);
        tablesPane.setVgap(10);
        tablesPane.setPadding(new Insets(10));

        VBox.setVgrow(tablesScroll, Priority.ALWAYS);
        leftBox.getChildren().add(tablesScroll);

        VBox centerBox = new VBox(10);
        centerBox.setPadding(new Insets(10));

        HBox titleBox = new HBox(10);
        titleBox.setAlignment(Pos.CENTER_LEFT);
        orderTitle.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        Region titleSpacer = new Region();
        HBox.setHgrow(titleSpacer, Priority.ALWAYS);

        Button placeOrderBtn = new Button("Place Order");
        placeOrderBtn.setStyle("-fx-background-color: #27AE60; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 10 20;");
        placeOrderBtn.setOnAction(e -> placeOrder());
        titleBox.getChildren().addAll(orderTitle, titleSpacer, placeOrderBtn);

        Label menuTitle = new Label("Meniu");
        menuTitle.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

        menuTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        TableColumn<Produs, String> nameCol = new TableColumn<>("Nume");
        nameCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getNume()));
        TableColumn<Produs, String> priceCol = new TableColumn<>("Preț");
        priceCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(String.format("%.2f RON", c.getValue().getPret())));
        menuTable.getColumns().addAll(nameCol, priceCol);
        menuTable.setItems(menuItems);

        menuTable.getSelectionModel().selectedItemProperty().addListener((obs, oldS, newS) -> {
            if (newS != null) {
                detailsName.setText(newS.getNume());
                detailsPrice.setText(String.format("%.2f RON", newS.getPret()));
                qtySpinner.getValueFactory().setValue(1);
            }
        });

        VBox.setVgrow(menuTable, Priority.ALWAYS);
        centerBox.getChildren().addAll(titleBox, menuTitle, menuTable);

        VBox rightBox = new VBox(10);
        rightBox.setPrefWidth(350);
        rightBox.setPadding(new Insets(10));

        VBox detailsBox = new VBox(8);
        detailsBox.setStyle("-fx-background-color: #f9f9f9; -fx-padding: 10; -fx-border-color: #ddd; -fx-border-radius: 5;");
        Label detailsTitle = new Label("Detalii produs");
        detailsTitle.setStyle("-fx-font-weight: bold;");
        detailsName.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #1976D2;");
        detailsPrice.setStyle("-fx-font-size: 13px; -fx-text-fill: #27AE60;");

        HBox qtyBox = new HBox(8);
        qtyBox.setAlignment(Pos.CENTER_LEFT);
        Button minusBtn = new Button("-");
        Button plusBtn = new Button("+");
        minusBtn.setPrefWidth(40);
        plusBtn.setPrefWidth(40);
        qtySpinner.setPrefWidth(80);

        minusBtn.setOnAction(e -> {
            int v = qtySpinner.getValue();
            if (v > 1) qtySpinner.getValueFactory().setValue(v - 1);
        });
        plusBtn.setOnAction(e -> {
            int v = qtySpinner.getValue();
            if (v < 99) qtySpinner.getValueFactory().setValue(v + 1);
        });

        qtyBox.getChildren().addAll(minusBtn, qtySpinner, plusBtn);

        Button addBtn = new Button("Adaugă în comandă");
        addBtn.setMaxWidth(Double.MAX_VALUE);
        addBtn.setStyle("-fx-background-color: #FF9800; -fx-text-fill: white; -fx-font-weight: bold;");
        addBtn.setOnAction(e -> addToCart());

        detailsBox.getChildren().addAll(detailsTitle, detailsName, detailsPrice, qtyBox, addBtn);

        VBox cartBox = new VBox(8);
        cartBox.setStyle("-fx-background-color: white; -fx-padding: 10; -fx-border-color: #ddd; -fx-border-radius: 5;");
        Label cartTitle = new Label("Coș");
        cartTitle.setStyle("-fx-font-weight: bold;");

        VBox.setVgrow(cartListView, Priority.ALWAYS);

        HBox cartActions = new HBox(8);
        Button changeQtyBtn = new Button("Schimbă cantitate");
        Button removeBtn = new Button("Șterge");
        changeQtyBtn.setOnAction(e -> changeCartQuantity());
        removeBtn.setOnAction(e -> removeFromCart());
        cartActions.getChildren().addAll(changeQtyBtn, removeBtn);

        subtotalLabel.setStyle("-fx-font-size: 12px;");
        discountLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #E74C3C;");
        totalLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #27AE60;");

        cartBox.getChildren().addAll(cartTitle, cartListView, cartActions, new Separator(), subtotalLabel, discountLabel, totalLabel);

        rightBox.getChildren().addAll(detailsBox, cartBox);

        mainLayout.getChildren().addAll(leftBox, centerBox, rightBox);
        HBox.setHgrow(centerBox, Priority.ALWAYS);

        return new VBox(mainLayout);
    }

    private VBox buildHistoryTab() {
        VBox box = new VBox(10);
        box.setPadding(new Insets(10));

        Label title = new Label("Istoricul comenzilor mele");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        historyTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<ComandaEntity, String> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getId().toString()));

        TableColumn<ComandaEntity, String> masaCol = new TableColumn<>("Masa");
        masaCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty("Masa " + c.getValue().getMasa().getNumar()));

        TableColumn<ComandaEntity, String> dataCol = new TableColumn<>("Data");
        dataCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(
                c.getValue().getDataOra().format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm"))
        ));

        TableColumn<ComandaEntity, String> subtotalCol = new TableColumn<>("Subtotal");
        subtotalCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(String.format("%.2f RON", c.getValue().getSubtotal())));

        TableColumn<ComandaEntity, String> discountCol = new TableColumn<>("Discount");
        discountCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(String.format("-%.2f RON", c.getValue().getDiscount())));

        TableColumn<ComandaEntity, String> totalCol = new TableColumn<>("Total");
        totalCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(String.format("%.2f RON", c.getValue().getTotal())));

        historyTable.getColumns().addAll(idCol, masaCol, dataCol, subtotalCol, discountCol, totalCol);
        historyTable.setItems(historyItems);

        VBox.setVgrow(historyTable, Priority.ALWAYS);
        box.getChildren().addAll(title, historyTable);

        return box;
    }

    private void loadTables() {
        EntityManager em = controller.getDb().getEntityManager();
        em.clear(); // Clear cache to force fresh data

        List<Masa> tables = controller.getAllTables();
        tablesPane.getChildren().clear();

        for (Masa m : tables) {
            Button btn = new Button("Masa " + m.getNumar() + "\n" + m.getLocuri() + " locuri");
            btn.setPrefSize(110, 100);
            btn.setStyle(m.isOcupata()
                    ? "-fx-background-color: #E74C3C; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 14px;"
                    : "-fx-background-color: #27AE60; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 14px;");

            btn.setOnAction(e -> selectTable(m));
            tablesPane.getChildren().add(btn);
        }
    }

    private void loadMenu() {
        menuItems.setAll(controller.getMenuProducts());
    }

    private void selectTable(Masa masa) {
        this.selectedTable = masa;
        orderTitle.setText("Masa " + masa.getNumar() + " - Procesare comandă");
        cartLines.clear();
        refreshCart();
    }

    private void addToCart() {
        if (selectedTable == null) {
            showAlert("Eroare", "Selectați o masă mai întâi!");
            return;
        }

        Produs p = menuTable.getSelectionModel().getSelectedItem();
        if (p == null) {
            showAlert("Eroare", "Selectați un produs din meniu!");
            return;
        }

        int qty = qtySpinner.getValue();

        for (LinieComandaEntity line : cartLines) {
            if (line.getProdus().getId().equals(p.getId())) {
                line.setCantitate(line.getCantitate() + qty);
                refreshCart();
                return;
            }
        }

        LinieComandaEntity newLine = new LinieComandaEntity(p, qty);
        cartLines.add(newLine);
        refreshCart();
    }

    private void refreshCart() {
        cartListView.getItems().clear();

        double subtotal = 0.0;
        for (LinieComandaEntity line : cartLines) {
            cartListView.getItems().add(String.format("%d x %s  =  %.2f RON",
                    line.getCantitate(), line.getProdus().getNume(), line.getSubtotal()));
            subtotal += line.getSubtotal();
        }

        double totalDiscount = 0.0;
        try {
            List<LinieComandaEntity> simpleLines = new ArrayList<>();
            for (LinieComandaEntity ent : cartLines) {
                simpleLines.add(new LinieComandaEntity(ent.getProdus(), ent.getCantitate()));
            }

            var discounts = PromotionEngine.calculateDiscounts(simpleLines);
            for (var d : discounts) {
                cartListView.getItems().add(String.format("🎁 %s  =  -%.2f RON", d.getDescription(), d.getAmount()));
                totalDiscount += d.getAmount();
            }
        } catch (Exception ignored) {}

        double taxable = Math.max(0.0, subtotal - totalDiscount);
        double tva = new AppConfig().getTva();
        double tvaAmount = taxable * tva;
        double total = taxable + tvaAmount;

        subtotalLabel.setText(String.format("Subtotal: %.2f RON", subtotal));
        discountLabel.setText(String.format("Discount: -%.2f RON", totalDiscount));
        totalLabel.setText(String.format("Total: %.2f RON", total));
    }

    private void changeCartQuantity() {
        int idx = cartListView.getSelectionModel().getSelectedIndex();
        if (idx < 0) {
            showAlert("Atenție", "Selectați un produs din coș!");
            return;
        }

        String sel = cartListView.getSelectionModel().getSelectedItem();
        if (sel == null || sel.contains("🎁")) {
            showAlert("Atenție", "Nu puteți modifica o linie de discount!");
            return;
        }

        String[] parts = sel.split(" x ", 2);
        if (parts.length < 2) return;

        String name = parts[1].split("  =")[0].trim();

        TextInputDialog dialog = new TextInputDialog("1");
        dialog.setTitle("Schimbă cantitate");
        dialog.setHeaderText("Introduceți cantitatea pentru " + name);
        dialog.setContentText("Cantitate:");

        dialog.showAndWait().ifPresent(s -> {
            try {
                int newQty = Integer.parseInt(s.trim());
                if (newQty <= 0) {
                    showAlert("Eroare", "Cantitatea trebuie să fie mai mare decât 0!");
                    return;
                }

                for (LinieComandaEntity line : cartLines) {
                    if (line.getProdus().getNume().equals(name)) {
                        line.setCantitate(newQty);
                        break;
                    }
                }
                refreshCart();
            } catch (NumberFormatException e) {
                showAlert("Eroare", "Introduceți un număr valid!");
            }
        });
    }

    private void removeFromCart() {
        int idx = cartListView.getSelectionModel().getSelectedIndex();
        if (idx < 0) {
            showAlert("Atenție", "Selectați un produs din coș!");
            return;
        }

        String sel = cartListView.getSelectionModel().getSelectedItem();
        if (sel == null || sel.contains("🎁")) {
            showAlert("Atenție", "Nu puteți șterge o linie de discount!");
            return;
        }

        String[] parts = sel.split(" x ", 2);
        if (parts.length < 2) return;

        String name = parts[1].split("  =")[0].trim();

        cartLines.removeIf(l -> l.getProdus().getNume().equals(name));
        refreshCart();
    }

    private void placeOrder() {
        if (selectedTable == null) {
            showAlert("Eroare", "Selectați o masă!");
            return;
        }

        if (cartLines.isEmpty()) {
            showAlert("Eroare", "Coșul este gol!");
            return;
        }

        EntityManager em = controller.getDb().getEntityManager();

        try {
            em.getTransaction().begin();

            Masa managedTable = em.merge(selectedTable);
            User managedWaiter = em.merge(controller.getWaiter());

            double subtotal = 0.0;
            for (LinieComandaEntity line : cartLines) {
                subtotal += line.getSubtotal();
            }

            double totalDiscount = 0.0;
            try {
                List<LinieComandaEntity> simpleLines = new ArrayList<>();
                for (LinieComandaEntity ent : cartLines) {
                    simpleLines.add(new LinieComandaEntity(ent.getProdus(), ent.getCantitate()));
                }
                var discounts = PromotionEngine.calculateDiscounts(simpleLines);
                for (var d : discounts) {
                    totalDiscount += d.getAmount();
                }
            } catch (Throwable ignored) {}

            double taxable = Math.max(0.0, subtotal - totalDiscount);
            double tva = new AppConfig().getTva();
            double tvaAmount = taxable * tva;
            double total = taxable + tvaAmount;

            ComandaEntity comanda = new ComandaEntity(managedTable, managedWaiter);
            comanda.setSubtotal(subtotal);
            comanda.setDiscount(totalDiscount);
            comanda.setTotal(total);

            for (LinieComandaEntity line : cartLines) {
                Produs managedProduct = em.merge(line.getProdus());
                LinieComandaEntity managedLine = new LinieComandaEntity(managedProduct, line.getCantitate());
                comanda.adaugaLinie(managedLine);
            }

            managedTable.setStatus(Masa.Status.OCUPATA);

            em.persist(comanda);

            em.getTransaction().commit();

            showAlert("Succes", "Comanda a fost finalizată! ID: " + comanda.getId());
            cartLines.clear();
            refreshCart();
            selectedTable = null;
            orderTitle.setText("Selectați o masă pentru a începe comanda");
            loadTables();
            refreshHistory();

        } catch (Exception e) {
            e.printStackTrace();
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            showAlert("Eroare", "Eroare la salvarea comenzii: " + e.getMessage());
        }
    }

    private void refreshHistory() {
        try {
            List<ComandaEntity> orders = controller.getMyOrders();
            historyItems.setAll(orders);
            System.out.println("✓ Istoric actualizat: " + orders.size() + " comenzi încărcate.");
        } catch (Exception e) {
            showAlert("Eroare", "Nu s-a putut actualiza istoricul: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void resetTablesAndRefresh() {
        Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmAlert.setTitle("Confirmare Reset");
        confirmAlert.setHeaderText("Resetare mese și comenzi");
        confirmAlert.setContentText("Aceasta va reseta toate mesele la status LIBER și va șterge istoricul comenzilor. Continuați?");

        if (confirmAlert.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK) {
            return;
        }

        EntityManager em = controller.getDb().getEntityManager();

        try {
            em.getTransaction().begin();

            em.createQuery("DELETE FROM LinieComandaEntity").executeUpdate();
            em.createQuery("DELETE FROM ComandaEntity").executeUpdate();

            em.createQuery("UPDATE Masa m SET m.status = :status")
                    .setParameter("status", Masa.Status.LIBERA)
                    .executeUpdate();

            em.getTransaction().commit();

            em.clear();

            loadTables();
            refreshHistory();
            cartLines.clear();
            refreshCart();
            selectedTable = null;
            orderTitle.setText("Selectați o masă pentru a începe comanda");

            showAlert("Succes", "Mesele au fost resetate și comenzile șterse!");

        } catch (Exception e) {
            e.printStackTrace();
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            showAlert("Eroare", "Eroare la resetare: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
