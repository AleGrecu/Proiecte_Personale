package org.example;

import jakarta.persistence.*;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "tip_produs", discriminatorType = DiscriminatorType.STRING)
public abstract class Produs {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nume;

    private double pret;

    @Enumerated(EnumType.STRING)
    private Categorie categorie;

    private boolean vegetarian;

    // JPA requires a no-arg constructor
    protected Produs() {}

    protected Produs(String nume, double pret, Categorie categorie, boolean vegetarian) {
        this.nume = nume;
        this.pret = pret;
        this.categorie = categorie;
        this.vegetarian = vegetarian;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNume() { return nume; }
    public void setNume(String nume) { this.nume = nume; }

    public double getPret() { return pret; }
    public void setPret(double pret) { this.pret = pret; }

    public Categorie getCategorie() { return categorie; }
    public void setCategorie(Categorie categorie) { this.categorie = categorie; }

    public boolean isVegetarian() { return vegetarian; }
    public void setVegetarian(boolean vegetarian) { this.vegetarian = vegetarian; }

    // Subclasses provide specific info (gramaj, volum, pizza details...)
    protected abstract String getSpecialInfo();

    public void afiseaza() {
        System.out.printf("%-30s %8.2f RON   %s%n", nume, pret, getSpecialInfo());
    }

    @Override
    public String toString() {
        return "Produs{" +
                "id=" + id +
                ", nume='" + nume + '\'' +
                ", pret=" + pret +
                ", categorie=" + categorie +
                ", vegetarian=" + vegetarian +
                '}';
    }
}
