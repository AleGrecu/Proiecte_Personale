// java
package org.example;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;

public class Meniu {
    private final Map<Categorie, List<Produs>> produse = new HashMap<>();
    private final AppConfig config;

    public Meniu(AppConfig config) {
        this.config = config;
    }

    public Meniu() {
        this(ConfigLoader.load("config.json"));
    }

    public void adaugaProdus(Produs p) {
        produse.computeIfAbsent(p.getCategorie(), c -> new ArrayList<>()).add(p);
    }

    public List<Produs> getByCategorie(Categorie c) {
        return produse.getOrDefault(c, List.of());
    }

    public List<Produs> getVegetarieneSortate() {
        return produse.values().stream()
                .flatMap(List::stream)
                .filter(Produs::isVegetarian)
                .sorted(Comparator.comparing(Produs::getNume))
                .collect(Collectors.toList());
    }

    public double pretMediu(Categorie c) {
        return produse.getOrDefault(c, List.of())
                .stream()
                .mapToDouble(Produs::getPret)
                .average()
                .orElse(0.0);
    }

    public boolean existaPeste100() {
        return produse.values().stream()
                .flatMap(List::stream)
                .anyMatch(p -> p.getPret() > 100);
    }

    public Optional<Produs> cauta(String nume) {
        return produse.values().stream()
                .flatMap(List::stream)
                .filter(p -> p.getNume().equalsIgnoreCase(nume))
                .findFirst();
    }

    public String getRestaurantName() {
        return config.getRestaurantName();
    }

    public double getTva() {
        return config.getTva();
    }

    public boolean esteGol() {
        return produse.isEmpty();
    }

    private static class MeniuItemDTO {
        String tip;
        String nume;
        double pret;
        String categorie;
        boolean vegetarian;
        Integer gramaj;
        Integer volum;
        Boolean alcoolic;
        Pizza.Blat blat;
        Pizza.Sos sos;
        List<String> toppinguri;
    }

    public void exportToJson(Path outputPath) {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        List<MeniuItemDTO> list = new ArrayList<>();

        for (List<Produs> lp : produse.values()) {
            for (Produs p : lp) {
                MeniuItemDTO dto = new MeniuItemDTO();
                dto.nume = p.getNume();
                dto.pret = p.getPret();
                dto.categorie = p.getCategorie().name();
                dto.vegetarian = p.isVegetarian();

                if (p instanceof Mancare m) {
                    dto.tip = "Mancare";
                    dto.gramaj = m.getGramaj();
                } else if (p instanceof Bautura b) {
                    dto.tip = "Bautura";
                    dto.volum = b.getVolum();
                    dto.alcoolic = b.isAlcoolic();
                } else if (p instanceof Pizza piz) {
                    dto.tip = "Pizza";

                    try {
                        Method mGetBlat = piz.getClass().getMethod("getBlat");
                        Object blatVal = mGetBlat.invoke(piz);
                        if (blatVal instanceof Pizza.Blat) dto.blat = (Pizza.Blat) blatVal;
                    } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException ignored) {
                    }

                    try {
                        Method mGetSos = piz.getClass().getMethod("getSos");
                        Object sosVal = mGetSos.invoke(piz);
                        if (sosVal instanceof Pizza.Sos) dto.sos = (Pizza.Sos) sosVal;
                    } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException ignored) {
                    }

                    try {
                        Method mGetToppings = piz.getClass().getMethod("getToppinguri");
                        Object toppingsVal = mGetToppings.invoke(piz);
                        if (toppingsVal instanceof Collection) {
                            dto.toppinguri = new ArrayList<>();
                            for (Object o : (Collection<?>) toppingsVal) {
                                if (o != null) dto.toppinguri.add(o.toString());
                            }
                        }
                    } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException ignored) {
                    }
                } else {
                    dto.tip = "Necunoscut";
                }
                list.add(dto);
            }
        }

        try {
            if (outputPath.getParent() != null) {
                Files.createDirectories(outputPath.getParent());
            }
            String json = gson.toJson(list);
            Files.writeString(outputPath, json, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            System.out.println("Meniul a fost exportat în: " + outputPath);
        } catch (IOException e) {
            System.err.println("Eroare: Nu s-a putut salva fișierul de meniu. Verificați permisiunile sau spațiul pe disc.");
        }
    }

    public void incarcaDinJson(Path inputPath) {
        Gson gson = new Gson();
        Type listType = new TypeToken<List<MeniuItemDTO>>(){}.getType();

        try {
            String json = Files.readString(inputPath);
            List<MeniuItemDTO> list = gson.fromJson(json, listType);
            if (list == null) {
                throw new JsonParseException("Meniu gol sau invalid");
            }

            produse.clear();
            for (MeniuItemDTO dto : list) {
                Categorie cat = Categorie.valueOf(dto.categorie);
                Produs p = null;
                switch (dto.tip) {
                    case "Mancare" -> {
                        int g = dto.gramaj != null ? dto.gramaj : 0;
                        p = new Mancare(dto.nume, dto.pret, g, cat, dto.vegetarian);
                    }
                    case "Bautura" -> {
                        int v = dto.volum != null ? dto.volum : 0;
                        boolean alc = dto.alcoolic != null && dto.alcoolic;
                        p = new Bautura(dto.nume, dto.pret, v, alc);
                    }
                    case "Pizza" -> {
                        Pizza.Builder builder = new Pizza.Builder(dto.nume, dto.pret)
                                .cuBlat(dto.blat != null ? dto.blat : Pizza.Blat.CLASIC)
                                .cuSos(dto.sos != null ? dto.sos : Pizza.Sos.ROSU);
                        if (dto.toppinguri != null) {
                            for (String t : dto.toppinguri) builder.adaugaTopping(t);
                        }
                        p = builder.build();
                    }
                    default -> {
                        System.err.println("Avertisment: tip produs necunoscut `" + dto.tip + "` pentru `" + dto.nume + "`. Se ignoră.");
                    }
                }
                if (p != null) {
                    adaugaProdus(p);
                }
            }

            System.out.println("Meniul a fost încărcat din: " + inputPath);

        } catch (NoSuchFileException e) {
            System.err.println("Atenție: fișierul de meniu `" + inputPath + "` nu există. Se va folosi meniul implicit.");
            produse.clear();
        } catch (JsonParseException e) {
            System.err.println("Eroare: fișierul de meniu `" + inputPath + "` este corupt sau are format invalid. Vă rugăm să verificați fișierul sau să contactați suportul tehnic. Se va folosi meniul implicit.");
            produse.clear();
        } catch (IOException e) {
            System.err.println("Eroare la citirea fișierului de meniu `" + inputPath + "`: " + e.getMessage() + ". Se va folosi meniul implicit.");
            produse.clear();
        }
    }
}
