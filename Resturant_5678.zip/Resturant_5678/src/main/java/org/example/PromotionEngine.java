package org.example;

import java.util.*;
import java.util.stream.Collectors;

public class PromotionEngine {

    public static class DiscountLine {
        private final String description;
        private final double amount;

        public DiscountLine(String description, double amount) {
            this.description = description;
            this.amount = amount;
        }

        public String getDescription() { return description; }
        public double getAmount() { return amount; }
    }

    public static List<DiscountLine> calculateDiscounts(List<LinieComandaEntity> items) {
        List<DiscountLine> discounts = new ArrayList<>();

        discounts.addAll(applyHappyHour(items));

        discounts.addAll(applyMealDeal(items));

        discounts.addAll(applyPartyPack(items));

        return discounts;
    }

    private static List<DiscountLine> applyHappyHour(List<LinieComandaEntity> items) {
        List<DiscountLine> result = new ArrayList<>();
        List<LinieComandaEntity> bauturi = items.stream()
                .filter(l -> l.getProdus() instanceof Bautura)
                .sorted(Comparator.comparing(l -> l.getProdus().getPret()))
                .collect(Collectors.toList());

        int count = bauturi.stream().mapToInt(LinieComandaEntity::getCantitate).sum();
        if (count >= 2) {
            int freeCount = count / 2;
            double discount = 0.0;
            int remaining = freeCount;

            for (LinieComandaEntity l : bauturi) {
                int qty = Math.min(remaining, l.getCantitate());
                discount += qty * l.getProdus().getPret() * 0.5;
                remaining -= qty;
                if (remaining == 0) break;
            }

            if (discount > 0) {
                result.add(new DiscountLine("Happy Hour (a 2-a băutură -50%)", discount));
            }
        }
        return result;
    }

    private static List<DiscountLine> applyMealDeal(List<LinieComandaEntity> items) {
        List<DiscountLine> result = new ArrayList<>();

        boolean hasPizza = items.stream().anyMatch(l -> l.getProdus() instanceof Pizza);

        Optional<LinieComandaEntity> cheapestDessert = items.stream()
                .filter(l -> l.getProdus().getCategorie() == Categorie.DESERT)
                .min(Comparator.comparing(l -> l.getProdus().getPret()));

        if (hasPizza && cheapestDessert.isPresent()) {
            double discount = cheapestDessert.get().getProdus().getPret() * 0.25;
            result.add(new DiscountLine("Meal Deal (Pizza + Desert -25%)", discount));
        }

        return result;
    }

    private static List<DiscountLine> applyPartyPack(List<LinieComandaEntity> items) {
        List<DiscountLine> result = new ArrayList<>();

        List<LinieComandaEntity> pizzas = items.stream()
                .filter(l -> l.getProdus() instanceof Pizza)
                .sorted(Comparator.comparing(l -> l.getProdus().getPret()))
                .collect(Collectors.toList());

        int totalPizzas = pizzas.stream().mapToInt(LinieComandaEntity::getCantitate).sum();

        if (totalPizzas >= 4) {
            int freePizzas = totalPizzas / 4;
            double discount = 0.0;
            int remaining = freePizzas;

            for (LinieComandaEntity l : pizzas) {
                int qty = Math.min(remaining, l.getCantitate());
                discount += qty * l.getProdus().getPret();
                remaining -= qty;
                if (remaining == 0) break;
            }

            if (discount > 0) {
                result.add(new DiscountLine("Party Pack (4 Pizza = 1 gratis)", discount));
            }
        }

        return result;
    }
}
