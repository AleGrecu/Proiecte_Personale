package org.example;

public class AppConfig {
    private double tva = 0.09;
    private String restaurantName = "La Andrei";
    public AppConfig() {}

    public AppConfig(double tva, String restaurantName) {
        this.tva = tva;
        this.restaurantName = restaurantName;
    }

    public double getTva() {
        return tva;
    }

    public String getRestaurantName() {
        return restaurantName;
    }

    @Override
    public String toString() {
        return "AppConfig{tva=" + tva + ", restaurantName='" + restaurantName + "'}";
    }
}
