// language: java
package org.example;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class OrderView extends BorderPane {
    private final WaiterController controller;
    private final Masa masa;

    private final TableView<Produs> productsTable = new TableView<>();
    private final ObservableList<Produs> products = FXCollections.observableArrayList();

    private final ListView<String> cartListView = new ListView<>();
    private final ObservableList<LinieComandaEntity> cartLines = FXCollections.observableArrayList();

    private final Label detailName = new Label();
    private final Label detailPrice = new Label();
    private final Label totalsLabel = new Label();

    private final Spinner<Integer> qtySpinner = new Spinner<>(1, 99, 1);

    public OrderView(WaiterController controller, Masa masa) {
        this.controller = controller;
        this.masa = masa;
        buildUI();
        loadProducts();
        refreshCartView();
    }

    private void buildUI() {
        setPadding(new Insets(10));

        // Top: title and place-order button
        HBox top = new HBox(10);
        top.setAlignment(Pos.CENTER_LEFT);
        Label title = new Label("Masa " + masa.getNumar() + " - Procesare comandă");
        title.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button placeOrderBtn = new Button("Place Order");
        placeOrderBtn.setOnAction(e -> finalizeOrder());
        top.getChildren().addAll(title, spacer, placeOrderBtn);
        setTop(top);


        productsTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        TableColumn<Produs, String> nameCol = new TableColumn<>("Nume");
        nameCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getNume()));
        TableColumn<Produs, String> priceCol = new TableColumn<>("Preț");
        priceCol.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(String.format("%.2f RON", c.getValue().getPret())));
        productsTable.getColumns().addAll(nameCol, priceCol);
        productsTable.setItems(products);

        VBox leftBox = new VBox(8, new Label("Meniu"), productsTable);
        leftBox.setPadding(new Insets(10));
        leftBox.setPrefWidth(600);

        // Right: details + qty controls + cart
        VBox detailBox = new VBox(8);
        detailBox.setPadding(new Insets(10));
        detailBox.setStyle("-fx-background-color: #f9f9f9; -fx-border-color: #ddd;");
        detailName.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
        detailPrice.setStyle("-fx-text-fill: #2E7D32;");

        // qty control (minus, spinner, plus)
        Button minusBtn = new Button("-");
        Button plusBtn = new Button("+");
        minusBtn.setPrefWidth(40);
        plusBtn.setPrefWidth(40);
        qtySpinner.setPrefWidth(80);

        minusBtn.setOnAction(e -> {
            int v = qtySpinner.getValue();
            if (v > 1) qtySpinner.getValueFactory().setValue(v - 1);
        });
        plusBtn.setOnAction(e -> {
            int v = qtySpinner.getValue();
            if (v < 99) qtySpinner.getValueFactory().setValue(v + 1);
        });

        HBox qtyBox = new HBox(8, minusBtn, qtySpinner, plusBtn);
        qtyBox.setAlignment(Pos.CENTER_LEFT);

        Button addBtn = new Button("Adaugă în comandă");
        addBtn.setMaxWidth(Double.MAX_VALUE);
        addBtn.setOnAction(e -> addSelectedProductToCart(qtySpinner.getValue()));

        detailBox.getChildren().addAll(new Label("Detalii produs"), detailName, detailPrice, qtyBox, addBtn);

        // Cart area
        VBox cartBox = new VBox(8);
        cartBox.setPadding(new Insets(10));
        cartBox.setStyle("-fx-background-color: #ffffff; -fx-border-color: #ddd;");
        Label cartTitle = new Label("Coș");
        Button removeBtn = new Button("Șterge linie");
        Button changeQtyBtn = new Button("Schimbă cantitate");
        removeBtn.setOnAction(e -> removeSelectedCartLine());
        changeQtyBtn.setOnAction(e -> changeSelectedCartQuantity());
        totalsLabel.setStyle("-fx-font-weight: bold;");
        HBox cartActions = new HBox(8, changeQtyBtn, removeBtn);
        cartBox.getChildren().addAll(cartTitle, cartListView, cartActions, totalsLabel);

        VBox rightBox = new VBox(10, detailBox, cartBox);
        rightBox.setPrefWidth(360);

        // Put left and right in an HBox
        HBox center = new HBox(12, leftBox, rightBox);
        HBox.setHgrow(leftBox, Priority.ALWAYS);
        setCenter(center);

        // selection handling
        productsTable.getSelectionModel().selectedItemProperty().addListener((obs, oldS, newS) -> {
            if (newS != null) {
                detailName.setText(newS.getNume());
                detailPrice.setText(String.format("%.2f RON", newS.getPret()));
                qtySpinner.getValueFactory().setValue(1);
            } else {
                detailName.setText("");
                detailPrice.setText("");
            }
        });
    }

    private void loadProducts() {
        products.setAll(controller.getMenuProducts());
    }

    private void addSelectedProductToCart(int qty) {
        Produs p = productsTable.getSelectionModel().getSelectedItem();
        if (p == null) return;
        for (LinieComandaEntity l : new ArrayList<>(cartLines)) {
            if (l.getProdus().getId().equals(p.getId())) {
                l.setCantitate(l.getCantitate() + qty);
                refreshCartView();
                return;
            }
        }
        LinieComandaEntity line = new LinieComandaEntity(p, qty);
        cartLines.add(line);
        refreshCartView();
    }

    private void refreshCartView() {
        cartListView.getItems().clear();
        double subtotal = 0.0;
        for (LinieComandaEntity l : cartLines) {
            cartListView.getItems().add(String.format("%d x %s  ->  %.2f RON", l.getCantitate(), l.getProdus().getNume(), l.getSubtotal()));
            subtotal += l.getSubtotal();
        }
        double discount = 0.0;
        try {
            List<LinieComandaEntity> simpleLines = new ArrayList<>();
            for (LinieComandaEntity ent : cartLines) simpleLines.add(new LinieComandaEntity(ent.getProdus(), ent.getCantitate()));
            var discounts = PromotionEngine.calculateDiscounts(simpleLines);
            for (var d : discounts) {
                cartListView.getItems().add(String.format("DISCOUNT: %s  ->  -%.2f RON", d.getDescription(), d.getAmount()));
                discount += d.getAmount();
            }
        } catch (Throwable ignored) {}
        double taxable = Math.max(0.0, subtotal - discount);
        double tva = new AppConfig().getTva();
        double tvaAmount = taxable * tva;
        double total = taxable + tvaAmount;
        totalsLabel.setText(String.format("Subtotal: %.2f RON   Discount: -%.2f RON   TVA %.0f%%: %.2f RON   Total: %.2f RON",
                subtotal, discount, tva * 100, tvaAmount, total));
    }

    private void removeSelectedCartLine() {
        int idx = cartListView.getSelectionModel().getSelectedIndex();
        if (idx < 0) return;
        String sel = cartListView.getSelectionModel().getSelectedItem();
        if (sel == null || sel.startsWith("DISCOUNT:")) return;
        String name = sel.split(" x ", 2)[1].split("  ->")[0];
        cartLines.removeIf(l -> l.getProdus().getNume().equals(name));
        refreshCartView();
    }

    private void changeSelectedCartQuantity() {
        int idx = cartListView.getSelectionModel().getSelectedIndex();
        if (idx < 0) return;
        String sel = cartListView.getSelectionModel().getSelectedItem();
        if (sel == null || sel.startsWith("DISCOUNT:")) return;
        String name = sel.split(" x ", 2)[1].split("  ->")[0];
        TextInputDialog dlg = new TextInputDialog("1");
        dlg.setTitle("Schimbă cantitate");
        dlg.setHeaderText("Introdu cantitatea pentru " + name);
        dlg.setContentText("Cantitate:");
        dlg.showAndWait().ifPresent(s -> {
            try {
                int q = Integer.parseInt(s.trim());
                if (q <= 0) return;
                for (LinieComandaEntity l : cartLines) {
                    if (l.getProdus().getNume().equals(name)) {
                        l.setCantitate(q);
                        break;
                    }
                }
                refreshCartView();
            } catch (NumberFormatException ignored) {}
        });
    }

    private void finalizeOrder() {
        if (cartLines.isEmpty()) {
            showAlert("Eroare", "Coșul este gol!");
            return;
        }
        List<LinieComandaEntity> toSave = new ArrayList<>(cartLines);
        Optional<ComandaEntity> persisted = controller.finalizeOrder(masa, toSave);
        if (persisted.isPresent()) {
            showAlert("Succes", "Comanda a fost finalizată (ID: " + persisted.get().getId() + ")");
            cartLines.clear();
            refreshCartView();
        } else {
            showAlert("Eroare", "Eroare la salvarea comenzii!");
        }
    }

    private void showAlert(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle(title);
        a.setHeaderText(null);
        a.setContentText(msg);
        a.showAndWait();
    }
}
