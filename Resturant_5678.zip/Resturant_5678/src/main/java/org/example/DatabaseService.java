package org.example;

import jakarta.persistence.*;
import java.util.List;
import java.util.Optional;

public class DatabaseService {
    private static final EntityManagerFactory emf =
            Persistence.createEntityManagerFactory("restaurantPU");

    private final EntityManager em;

    public DatabaseService() {
        this.em = emf.createEntityManager();
    }
    public EntityManager getEntityManager() {
        return em;
    }

    // Salvează un produs în baza de date
    public void salvaProdus(Produs produs) {
        try {
            em.getTransaction().begin();
            em.persist(produs);
            em.getTransaction().commit();
            System.out.println("✅ Produs salvat: " + produs.getNume());
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            System.err.println("❌ Eroare la salvarea produsului: " + e.getMessage());
        }
    }
    public void salvaMasa(Masa masa) {
        try {
            em.getTransaction().begin();
            em.persist(masa);
            em.getTransaction().commit();
            System.out.println("✅ Masa salvată: " + masa.getNumar());
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            System.err.println("❌ Eroare la salvarea mesei: " + e.getMessage());
        }
    }
    //Aceasta este o metodă de Read (Find All) pentru Repository-ul de Mese.
    public List<Masa> incarcaMese() {
        try {
            return em.createQuery("SELECT m FROM Masa m ORDER BY m.numar", Masa.class).getResultList();
        } catch (Exception e) {
            System.err.println("❌ Eroare la încărcarea meselor: " + e.getMessage());
            return List.of();
        }
    }
    public Optional<Masa> gasesteMasaByNumar(int numar) {
        try {
            Masa m = em.createQuery("SELECT m FROM Masa m WHERE m.numar = :numar", Masa.class)
                    .setParameter("numar", numar)
                    .getSingleResult();
            return Optional.ofNullable(m);
        } catch (jakarta.persistence.NoResultException e) {
            return Optional.empty();
        } catch (Exception e) {
            System.err.println("❌ Eroare la căutarea mesei: " + e.getMessage());
            return Optional.empty();
        }
    }
    public void actualizeazaMasa(Masa masa) {
        try {
            em.getTransaction().begin();
            em.merge(masa);
            em.getTransaction().commit();
            System.out.println("✅ Masa actualizată: " + masa.getNumar());
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            System.err.println("❌ Eroare la actualizarea mesei: " + e.getMessage());
        }
    }
    public void stergeMasa(Long id) {
        try {
            em.getTransaction().begin();
            Masa m = em.find(Masa.class, id);
            if (m != null) em.remove(m);
            em.getTransaction().commit();
            System.out.println("✅ Masa ștearsă: " + id);
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            System.err.println("❌ Eroare la ștergerea mesei: " + e.getMessage());
        }
    }

    // Încarcă toate produsele din baza de date
    public List<Produs> incarcaToateProdusele() {
        try {
            return em.createQuery("SELECT p FROM Produs p", Produs.class).getResultList();
        } catch (Exception e) {
            System.err.println("❌ Eroare la încărcarea produselor: " + e.getMessage());
            return List.of();
        }
    }

    // Găsește un produs după ID
    public Optional<Produs> gasesteById(Long id) {
        try {
            Produs produs = em.find(Produs.class, id);
            return Optional.ofNullable(produs);
        } catch (Exception e) {
            System.err.println("❌ Eroare la căutarea produsului: " + e.getMessage());
            return Optional.empty();
        }
    }

    // Actualizează un produs existent
    public void actualizeazaProdus(Produs produs) {
        try {
            em.getTransaction().begin();
            em.merge(produs);
            em.getTransaction().commit();
            System.out.println("✅ Produs actualizat: " + produs.getNume());
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            System.err.println("❌ Eroare la actualizarea produsului: " + e.getMessage());
        }
    }

    // Șterge un produs din baza de date
    public void stergeProdus(Long id) {
        try {
            em.getTransaction().begin();
            Produs produs = em.find(Produs.class, id);
            if (produs != null) {
                em.remove(produs);
                System.out.println("✅ Produs șters: " + produs.getNume());
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            System.err.println("❌ Eroare la ștergerea produsului: " + e.getMessage());
        }
    }

    // Închide EntityManager
    public void close() {
        if (em != null && em.isOpen()) {
            em.close();
        }
    }

    // Închide EntityManagerFactory (la oprirea aplicației)
    public static void closeFactory() {
        if (emf != null && emf.isOpen()) {
            emf.close();
        }
    }
}
