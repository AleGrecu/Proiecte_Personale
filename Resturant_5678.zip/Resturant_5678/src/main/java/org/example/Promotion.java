package org.example;

@FunctionalInterface
public interface Promotion {
    double apply(Comanda comanda);
}
