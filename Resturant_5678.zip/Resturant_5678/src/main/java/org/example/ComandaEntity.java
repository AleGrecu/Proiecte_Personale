package org.example;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "comenzi")
public class ComandaEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "masa_id", nullable = false)
    private Masa masa;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "waiter_id", nullable = false)
    private User waiter;


    @Column(nullable = false)
    private LocalDateTime dataOra;

    @OneToMany(mappedBy = "comanda", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<LinieComandaEntity> linii = new ArrayList<>();

    private double subtotal;
    private double discount;
    private double total;

    protected ComandaEntity() {}

    public ComandaEntity(Masa masa, User waiter) {
        this.masa = masa;
        this.waiter = waiter;
        this.dataOra = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public Masa getMasa() { return masa; }
    public User getWaiter() { return waiter; }
    public LocalDateTime getDataOra() { return dataOra; }
    public List<LinieComandaEntity> getLinii() { return linii; }
    public double getSubtotal() { return subtotal; }
    public double getDiscount() { return discount; }
    public double getTotal() { return total; }

    public void setSubtotal(double subtotal) { this.subtotal = subtotal; }
    public void setDiscount(double discount) { this.discount = discount; }
    public void setTotal(double total) { this.total = total; }

    public void adaugaLinie(LinieComandaEntity linie) {
        linii.add(linie);
        linie.setComanda(this);
    }
}
