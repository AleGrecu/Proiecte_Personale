package org.example;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("BAUTURA")
public final class Bautura extends Produs {
    private final int volum;
    private final boolean alcoolic;

    protected Bautura() {
        super();
        this.volum = 0;
        this.alcoolic = false;
    }

    public Bautura(String nume, double pret, int volum, boolean alcoolic) {
        super(nume, pret, alcoolic ? Categorie.BAUTURI_ALCOOLICE : Categorie.BAUTURI_RACORITOARE, true);
        this.volum = volum;
        this.alcoolic = alcoolic;
    }

    public int getVolum() {
        return volum;
    }

    public boolean isAlcoolic() {
        return alcoolic;
    }

    @Override
    protected String getSpecialInfo() {
        return "Volum: " + volum + "ml" + (alcoolic ? " (Alcoolic)" : "");
    }
}
