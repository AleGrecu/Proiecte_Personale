package org.example;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MenuApp extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        DatabaseService db = new DatabaseService();

        GuestView guestView = new GuestView(db);
        Scene scene = new Scene(guestView, 1200, 700);

        primaryStage.setTitle("La Andrei - Restaurant");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
