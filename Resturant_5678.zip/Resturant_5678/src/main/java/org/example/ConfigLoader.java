package org.example;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.*;

public class ConfigLoader {
    public static AppConfig load(String configPath) {
        Gson gson = new Gson();


        Path path = Paths.get(configPath);
        try {
            String content = Files.readString(path);
            AppConfig cfg = gson.fromJson(content, AppConfig.class);
            if (cfg == null) throw new JsonParseException("Config parsed to null");
            return cfg;
        } catch (NoSuchFileException e) {
            System.err.println("Atenție: fișierul de configurare `" + configPath + "` nu a fost găsit pe disc. Se încearcă încărcarea din resursele programului...");

        } catch (JsonParseException e) {
            System.err.println("Eroare: fișierul de configurare `" + configPath + "` este corupt sau are format invalid. Se va folosi configurația implicită. Vă rugăm verificați `" + configPath + "`.");
            return new AppConfig();
        } catch (IOException e) {
            System.err.println("Eroare la citirea fișierului de configurare `" + configPath + "`: " + e.getMessage() + ". Se va folosi configurația implicită.");
            return new AppConfig();
        }


        try (InputStream is = ConfigLoader.class.getClassLoader().getResourceAsStream(configPath)) {
            if (is == null) {
                System.err.println("Atenție: fișierul de configurare încorporat `" + configPath + "` nu a fost găsit. Se va folosi configurația implicită.");
                return new AppConfig();
            }
            AppConfig cfg = gson.fromJson(new InputStreamReader(is), AppConfig.class);
            if (cfg == null) throw new JsonParseException("Config parsed to null from resource");
            return cfg;
        } catch (JsonParseException e) {
            System.err.println("Eroare: fișierul de configurare încorporat `" + configPath + "` este corupt sau are format invalid. Se va folosi configurația implicită.");
            return new AppConfig();
        } catch (IOException e) {
            System.err.println("Eroare la citirea fișierului de configurare încorporat `" + configPath + "`: " + e.getMessage() + ". Se va folosi configurația implicită.");
            return new AppConfig();
        }
    }
}
