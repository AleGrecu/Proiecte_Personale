module org.example {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.hibernate.orm.core;
    requires jakarta.persistence;
    requires com.google.gson;

    opens org.example to org.hibernate.orm.core, javafx.base;
    exports org.example;
}
