package org.example;

import java.util.List;
import java.util.ArrayList;
import java.util.Random;

public class GameController {
    private final Board board = new Board();
    private final ComputerPlayer ai = new ComputerPlayer();
    private boolean started = false;
    private boolean playerFirst = true;


    private char playerSymbol = 'X';
    private char aiSymbol = 'O';

    private boolean playerSuperAvailable = true;
    private boolean aiSuperAvailable = true;
    private final Random rng = new Random();


    public void start(boolean playerFirst) {
        this.playerFirst = playerFirst;
        board.reset();

        playerSuperAvailable = true;
        aiSuperAvailable = true;
        started = true;
        if (!playerFirst && !board.isFull()) {
            ai.makeMove(board, aiSymbol);
        }
    }

    public void reset() {
        board.reset();
        started = false;

        playerSuperAvailable = true;
        aiSuperAvailable = true;
    }

    public boolean isStarted() {
        return started;
    }

    public void setStarted(boolean s) {
        started = s;
    }

    public void setPlayerSymbol(char sym) {
        if (sym != 'X' && sym != 'O') return;
        this.playerSymbol = sym;
        this.aiSymbol = (sym == 'X') ? 'O' : 'X';
    }

    public boolean playerMove(int row, int col) {
        if (!started) return false;
        return board.set(row, col, playerSymbol);
    }

    public int[] aiMove() {
        if (!started) return null;
        List<int[]> moves = board.availableMoves();
        if (moves.isEmpty()) return null;
        ai.makeMove(board, aiSymbol);
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                if (board.get(i, j) == aiSymbol) {
                    return new int[]{i, j};
                }
        return null;
    }

    public char getCell(int row, int col) {
        return board.get(row, col);
    }

    public char checkWinner() {
        return board.checkWinner();
    }

    public boolean isFull() {
        return board.isFull();
    }

    public boolean isPlayerFirst() {
        return playerFirst;
    }


    public char[][] getBoardCopy() {
        char[][] copy = new char[3][3];
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                copy[i][j] = board.get(i, j);
        return copy;
    }


    public int availableMovesCount() {
        return board.availableMoves().size();
    }


    public boolean canPlayerUseSuper() {
        return started && playerSuperAvailable;
    }

    public boolean canAiUseSuper() {
        return started && aiSuperAvailable;
    }

    public boolean playerUseSuper(int row, int col) {
        if (!canPlayerUseSuper()) return false;
        if (board.get(row, col) != aiSymbol) return false;
        boolean removed = board.clear(row, col);
        if (removed) playerSuperAvailable = false;
        return removed;
    }

    public int[] aiUseSuper() {
        if (!canAiUseSuper()) return null;
        List<int[]> occupied = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board.get(i, j) == playerSymbol) occupied.add(new int[]{i, j});
            }
        }
        if (occupied.isEmpty()) return null;
        int idx = rng.nextInt(occupied.size());
        int[] chosen = occupied.get(idx);
        boolean removed = board.clear(chosen[0], chosen[1]);
        if (removed) aiSuperAvailable = false;
        return removed ? chosen : null;
    }
}
