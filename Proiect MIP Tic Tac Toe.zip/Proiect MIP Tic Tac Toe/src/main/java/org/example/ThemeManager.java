package org.example;

import javax.swing.*;
import java.awt.*;


public final class ThemeManager {

    private ThemeManager() { }

    public static void applyTheme(Container root, JLabel timerLabel, JButton[][] buttons, String themeName) {
        if (themeName == null) themeName = "Classic";
        themeName = themeName.trim();

        Color bg;
        Color timerFg = Color.BLACK;
        Color defaultBtnBg = Color.WHITE;
        Color defaultBtnFg = Color.BLACK;
        Color[] palette = null;
        boolean forceBlackForButtons = false;

        switch (themeName) {
            case "Dark":
                bg = new Color(34, 34, 34);
                defaultBtnBg = new Color(64, 64, 64);
                defaultBtnFg = Color.WHITE;
                timerFg = Color.WHITE;
                break;

            case "Colorful":

                bg = new Color(245, 238, 255);
                defaultBtnBg = new Color(255, 250, 252);
                defaultBtnFg = new Color(40, 30, 50);
                timerFg = new Color(70, 45, 90);
                palette = new Color[] {
                    new Color(255, 123, 186),
                    new Color(255, 179, 128),
                    new Color(255, 235, 128),
                    new Color(160, 235, 170),
                    new Color(140, 190, 255),
                    new Color(190, 140, 255)
                };
                break;

            case "Neon":
                bg = new Color(10, 10, 25);
                defaultBtnBg = new Color(20, 20, 35);

                defaultBtnFg = Color.BLACK;
                timerFg = new Color(0, 255, 204);
                palette = new Color[] {
                    new Color(255, 20, 147),
                    new Color(0, 255, 204),
                    new Color(255, 255, 0),
                    new Color(0, 200, 255),
                    new Color(180, 0, 255)
                };
                forceBlackForButtons = true;
                break;

            case "Galaxy":
                bg = new Color(5, 10, 30);
                defaultBtnBg = new Color(20, 30, 60);
                defaultBtnFg = new Color(200, 220, 255);
                timerFg = new Color(180, 200, 255);
                palette = new Color[] {
                    new Color(40, 48, 72),
                    new Color(60, 40, 120),
                    new Color(100, 160, 255),
                    new Color(255, 150, 255),
                    new Color(255, 200, 100)
                };
                break;

            case "Dessert":

                bg = new Color(255, 235, 220);
                defaultBtnBg = new Color(255, 240, 225);
                defaultBtnFg = new Color(70, 40, 20);
                timerFg = new Color(120, 70, 30);
                palette = new Color[] {
                    new Color(255, 153, 170),
                    new Color(255, 210, 150),
                    new Color(255, 190, 140),
                    new Color(220, 180, 140),
                    new Color(230, 210, 255),
                    new Color(255, 245, 200)
                };
                break;

            default:
                bg = Color.WHITE;
                defaultBtnBg = Color.WHITE;
                defaultBtnFg = Color.BLACK;
                timerFg = Color.BLACK;
                break;
        }


        Color labelFg = timerFg;

        if (root != null) {
            root.setBackground(bg);
            if (root instanceof JComponent) ((JComponent) root).setOpaque(true);
            applyBackgroundRecursively(root, bg, labelFg);
        }


        if (timerLabel != null) {
            timerLabel.setForeground(timerFg);
            timerLabel.setBackground(bg);
            timerLabel.setOpaque(true);
        }


        if (buttons != null) {
            int rows = buttons.length;
            int cols = (rows > 0 && buttons[0] != null) ? buttons[0].length : 0;
            for (int i = 0; i < rows; i++) {
                if (buttons[i] == null) continue;
                for (int j = 0; j < buttons[i].length; j++) {
                    JButton b = buttons[i][j];
                    if (b == null) continue;
                    if (palette != null && palette.length > 0 && cols > 0) {
                        int idx = (i * cols + j) % palette.length;
                        if (idx < 0) idx = 0;
                        Color btnColor = palette[idx];
                        b.setBackground(btnColor);

                        if (forceBlackForButtons) {
                            b.setForeground(Color.BLACK);
                        } else {
                            b.setForeground(contrastColor(btnColor, defaultBtnFg));
                        }
                    } else {
                        b.setBackground(defaultBtnBg);
                        b.setForeground(defaultBtnFg);
                    }
                    if (b instanceof JComponent) ((JComponent) b).setOpaque(true);
                    b.setBorderPainted(true);
                }
            }
        }
    }


    private static void applyBackgroundRecursively(Component comp, Color bg, Color labelFg) {
        if (comp == null) return;
        if (comp instanceof JComponent) {
            ((JComponent) comp).setBackground(bg);
            ((JComponent) comp).setOpaque(true);
        }

        if (comp instanceof JLabel) ((JLabel) comp).setForeground(labelFg);
        if (comp instanceof JTextField) {
            ((JTextField) comp).setBackground(bg);
            ((JTextField) comp).setOpaque(true);
            ((JTextField) comp).setForeground(labelFg);
        }
        if (comp instanceof JCheckBox) {
            ((JCheckBox) comp).setBackground(bg);
            ((JCheckBox) comp).setOpaque(true);
            ((JCheckBox) comp).setForeground(labelFg);
        }
        if (comp instanceof Container) {
            for (Component child : ((Container) comp).getComponents()) {
                applyBackgroundRecursively(child, bg, labelFg);
            }
        }
    }


    private static Color contrastColor(Color bg, Color fallback) {
        if (bg == null) return fallback == null ? Color.BLACK : fallback;

        double r = bg.getRed() / 255.0;
        double g = bg.getGreen() / 255.0;
        double b = bg.getBlue() / 255.0;
        double luminance = 0.299 * r + 0.587 * g + 0.114 * b;

        return luminance > 0.6 ? Color.BLACK : Color.WHITE;
    }
}
