package org.example;

import java.util.List;
import java.util.Random;


public class ComputerPlayer {
    private final Random rnd = new Random();


    public int[] makeMove(Board board, char symbol) {
        if (board == null) return null;
        List<int[]> moves = board.availableMoves();
        if (moves == null || moves.isEmpty()) return null;
        int idx = rnd.nextInt(moves.size());
        int[] mv = moves.get(idx);
        boolean ok = board.set(mv[0], mv[1], symbol);
        if (!ok) {
            for (int[] m : moves) {
                if (board.set(m[0], m[1], symbol)) return new int[]{m[0], m[1]};
            }
            return null;
        }
        return new int[]{mv[0], mv[1]};
    }
}
