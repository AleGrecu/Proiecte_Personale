package org.example;

import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        Font uiBase = new Font("Georgia", Font.PLAIN, 14);
        UIManager.put("Label.font", uiBase);
        UIManager.put("Button.font", uiBase);
        UIManager.put("RadioButton.font", uiBase);
        UIManager.put("TextField.font", uiBase);
        UIManager.put("CheckBox.font", uiBase);

        SwingUtilities.invokeLater(() -> new Game());
    }

    public static class Game extends JFrame {
        private final Font elegantBase = new Font("Georgia", Font.PLAIN, 14);
        private final JButton[][] buttons = new JButton[3][3];
        private final GameController controller = new GameController();

        private boolean playerFirst = true;
        private String selectedTheme = "Classic";
        private char playerSymbol = 'X';

        private String playerName = "Player";

        private JLabel timerLabel;
        private javax.swing.Timer swingTimer;
        private int timeRemaining = 120;

        private JButton superBtn;
        private boolean superModeActive = false;

        public Game() {
            super("TicTacToe");
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            setResizable(false);
            initialize();
            pack();
            setLocationRelativeTo(null);

            showControlsDialog();

            setVisible(true);
        }

        public void setPlayerName(String name) {
            if (name == null || name.trim().isEmpty()) this.playerName = "Player";
            else this.playerName = name.trim();
        }
        public String getPlayerName() { return playerName; }

        public void setPlayerSymbol(char sym) {
            if (sym != 'X' && sym != 'O') return;
            this.playerSymbol = sym;
            controller.setPlayerSymbol(sym);
        }

        private void initialize() {
            JPanel mainPanel = new JPanel(new BorderLayout());

            timerLabel = new JLabel("Time: 02:00", SwingConstants.CENTER);
            timerLabel.setFont(new Font("Georgia", Font.BOLD, 18));
            timerLabel.setBorder(BorderFactory.createEmptyBorder(6,6,6,6));
            mainPanel.add(timerLabel, BorderLayout.NORTH);

            JPanel game = new JPanel(new GridLayout(3, 3));
            game.setPreferredSize(new Dimension(350, 350));

            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    final int r = i, c = j;
                    buttons[i][j] = new JButton("");
                    // use Georgia bold for large cell text
                    buttons[i][j].setFont(new Font("Georgia", Font.BOLD, 36));
                    buttons[i][j].setOpaque(true);
                    buttons[i][j].setBorderPainted(true);

                    buttons[i][j].addActionListener(ev -> {
                        if (!controller.isStarted()) {
                            JOptionPane.showMessageDialog(this, "Press Start (open controls) first.");
                            return;
                        }
                        handlePlayerMove(r, c);
                    });
                    game.add(buttons[i][j]);
                }
            }

            add(mainPanel);
            mainPanel.add(game, BorderLayout.CENTER);


            JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER));
            superBtn = new JButton("Superpower");
            superBtn.setFont(new Font("Georgia", Font.BOLD, 14));
            superBtn.setEnabled(false);
            superBtn.addActionListener(e -> {
                if (!controller.isStarted()) return;
                // toggle mode
                if (superModeActive) {
                    superModeActive = false;
                    superBtn.setText("Superpower");
                } else {
                    if (!controller.canPlayerUseSuper()) {
                        JOptionPane.showMessageDialog(this, "Superpower already used this round.");
                        return;
                    }
                    superModeActive = true;
                    superBtn.setText("Cancel Superpower");
                }
                refreshButtons();
            });
            bottom.add(superBtn);
            mainPanel.add(bottom, BorderLayout.SOUTH);

            resetBoard();


            applyTheme(selectedTheme);
        }

        private void showControlsDialog() {
            ControlsDialog dlg = new ControlsDialog(this, selectedTheme);
            dlg.setVisible(true);
            String sel = dlg.getSelectedTheme();
            if (sel != null) {
                selectedTheme = sel;
                applyTheme(selectedTheme);
            } else {
                applyTheme(selectedTheme);
            }
        }

        private void startGame(boolean playerGoesFirst) {
            this.playerFirst = playerGoesFirst;
            controller.start(playerGoesFirst);
            controller.setStarted(true);
            superModeActive = false;
            refreshButtons();
            applyTheme(selectedTheme);
            startTimer();
        }

        private void resetBoard() {
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++) {
                    buttons[i][j].setText("");
                    buttons[i][j].setEnabled(false);
                }
            timeRemaining = 120;
            updateTimerLabel();
            superModeActive = false;
            if (superBtn != null) superBtn.setEnabled(false);
        }

        private void handlePlayerMove(int row, int col) {

            char opponent = (playerSymbol == 'X') ? 'O' : 'X';
            if (superModeActive) {
                if (!controller.canPlayerUseSuper()) {
                    JOptionPane.showMessageDialog(this, "You cannot use the superpower anymore this round.");
                    superModeActive = false;
                    superBtn.setText("Superpower");
                    refreshButtons();
                    return;
                }
                if (controller.getCell(row, col) != opponent) {
                    JOptionPane.showMessageDialog(this, "Select a cell containing the opponent's symbol to remove.");
                    return;
                }
                boolean removed = controller.playerUseSuper(row, col);
                superModeActive = false;
                superBtn.setText("Superpower");
                refreshButtons();
                if (removed) {
                    JOptionPane.showMessageDialog(this, "You used Superpower: removed an opponent symbol!");
                }

                char winner = controller.checkWinner();
                if (winner != '\0') {
                    stopTimer();
                    announceWinner(winner);
                    return;
                }
                if (controller.isFull()) {
                    stopTimer();
                    announceDraw();
                    return;
                }


                handleAiResponse();
                return;
            }


            if (!controller.playerMove(row, col)) return;
            refreshButtons();

            char winner = controller.checkWinner();
            if (winner != '\0') {
                stopTimer();
                announceWinner(winner);
                return;
            }
            if (controller.isFull()) {
                stopTimer();
                announceDraw();
                return;
            }

            handleAiResponse();
        }


        private void handleAiResponse() {

            if (!controller.isStarted()) return;

            if (controller.canAiUseSuper()) {
                boolean hasPlayerSymbols = false;
                for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) if (controller.getCell(i, j) == playerSymbol) hasPlayerSymbols = true;
                if (hasPlayerSymbols && Math.random() < 0.5) {
                    int[] removed = controller.aiUseSuper();
                    if (removed != null) {
                        refreshButtons();
                        JOptionPane.showMessageDialog(this, "Opponent used Superpower and removed one of your symbols!");
                        char winner = controller.checkWinner();
                        if (winner != '\0') {
                            stopTimer();
                            announceWinner(winner);
                            return;
                        }
                        if (controller.isFull()) {
                            stopTimer();
                            announceDraw();
                            return;
                        }
                    }
                }
            }

            controller.aiMove();
            refreshButtons();

            char winner = controller.checkWinner();
            if (winner != '\0') {
                stopTimer();
                announceWinner(winner);
            } else if (controller.isFull()) {
                stopTimer();
                announceDraw();
            }
        }

        private void refreshButtons() {
            char opponent = (playerSymbol == 'X') ? 'O' : 'X';
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++) {
                    char v = controller.getCell(i, j);
                    buttons[i][j].setText(v == '\0' ? "" : String.valueOf(v));
                    boolean enabled;
                    if (!controller.isStarted()) enabled = false;
                    else if (superModeActive) {

                        enabled = (v == opponent);
                    } else {
                        enabled = (v == '\0');
                    }
                    buttons[i][j].setEnabled(enabled && controller.isStarted());
                }
            if (superBtn != null) {
                superBtn.setEnabled(controller.isStarted() && controller.canPlayerUseSuper());
                if (!controller.canPlayerUseSuper()) {
                    superModeActive = false;
                    superBtn.setText("Superpower");
                }
            }
        }

        private void announceWinner(char winner) {
            String winnerName = (winner == playerSymbol) ? playerName : "Player_2";
            ResultDialog res = new ResultDialog(this, winnerName + " wins!!!", selectedTheme);
            res.setVisible(true);
            if (res.isRestart()) {
                controller.start(controller.isPlayerFirst());
                controller.setStarted(true);
                superModeActive = false;
                refreshButtons();
                startTimer();
            } else {
                System.exit(0);
            }
        }

        private void announceDraw() {
            ResultDialog res = new ResultDialog(this, "Draw!", selectedTheme);
            res.setVisible(true);
            if (res.isRestart()) {
                controller.start(controller.isPlayerFirst());
                controller.setStarted(true);
                superModeActive = false;
                refreshButtons();
                startTimer();
            } else {
                System.exit(0);
            }
        }


        private void applyTheme(String theme) {
            ThemeManager.applyTheme(getContentPane(), timerLabel, buttons, theme);
            selectedTheme = theme == null ? "Classic" : theme;
        }


        private void startTimer() {
            stopTimer();
            timeRemaining = 120;
            updateTimerLabel();
            swingTimer = new javax.swing.Timer(1000, e -> {
                timeRemaining--;
                updateTimerLabel();
                if (timeRemaining <= 0) {
                    stopTimer();
                    handleTimeExpired();
                }
            });
            swingTimer.setRepeats(true);
            swingTimer.start();
        }

        private void stopTimer() {
            if (swingTimer != null && swingTimer.isRunning()) swingTimer.stop();
        }

        private void updateTimerLabel() {
            int mm = timeRemaining / 60;
            int ss = timeRemaining % 60;
            timerLabel.setText(String.format("Time: %02d:%02d", mm, ss));
        }

        private void handleTimeExpired() {
            controller.setStarted(false);
            refreshButtons();
            ResultDialog res = new ResultDialog(this, "Time expired", selectedTheme);
            res.setVisible(true);
            if (res.isRestart()) {
                controller.start(controller.isPlayerFirst());
                controller.setStarted(true);
                superModeActive = false;
                refreshButtons();
                startTimer();
            } else {
                System.exit(0);
            }
        }

        static class ControlsDialog extends JDialog {
            private String selectedTheme = null;

            ControlsDialog(Game owner, String currentTheme) {
                super(owner, "Controls", true);
                setLayout(new BorderLayout(10, 10));

                JPanel northPanel = new JPanel(new BorderLayout());
                JPanel leftStack = new JPanel();
                leftStack.setLayout(new BoxLayout(leftStack, BoxLayout.Y_AXIS));
                JPanel namePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
                namePanel.add(new JLabel("Player name:"));
                JTextField nameField = new JTextField(owner.getPlayerName(), 15);

                nameField.setFont(new Font("Georgia", Font.PLAIN, 14));
                namePanel.add(nameField);
                JCheckBox iGoFirst = new JCheckBox("I go first", true);
                iGoFirst.setFont(new Font("Georgia", Font.PLAIN, 14));
                leftStack.add(namePanel);
                JPanel chkContainer = new JPanel(new FlowLayout(FlowLayout.LEFT));
                chkContainer.add(iGoFirst);
                leftStack.add(chkContainer);
                northPanel.add(leftStack, BorderLayout.WEST);

                JLabel titleLabel = new JLabel("Tic Tac Toe", SwingConstants.RIGHT);
                titleLabel.setFont(new Font("Georgia", Font.BOLD, 16));
                titleLabel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 12));
                northPanel.add(titleLabel, BorderLayout.EAST);

                add(northPanel, BorderLayout.NORTH);


                JPanel themePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
                JButton themeBtn = new JButton("Theme...");
                JButton symbolBtn = new JButton("Choose Symbol...");

                themeBtn.setFont(new Font("Georgia", Font.BOLD, 14));
                symbolBtn.setFont(new Font("Georgia", Font.BOLD, 14));
                themePanel.add(themeBtn);
                themePanel.add(symbolBtn);

                JPanel startPanel = new JPanel(new GridBagLayout());
                JButton startBtn = new JButton("Start");

                startBtn.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 24));
                startBtn.setPreferredSize(new Dimension(200, 64));
                startBtn.setFocusPainted(false);
                startBtn.setOpaque(true);
                startBtn.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Color.DARK_GRAY, 2),
                        BorderFactory.createEmptyBorder(8, 14, 8, 14)
                ));
                GridBagConstraints gbc = new GridBagConstraints();
                gbc.gridx = 0;
                gbc.gridy = 0;
                gbc.weightx = 1.0;
                gbc.weighty = 1.0;
                gbc.anchor = GridBagConstraints.CENTER;
                startPanel.add(startBtn, gbc);

                add(startPanel, BorderLayout.CENTER);
                add(themePanel, BorderLayout.SOUTH);

                themeBtn.addActionListener(e -> {
                    ThemeDialog td = new ThemeDialog(owner, currentTheme);
                    td.setVisible(true);
                    String sel = td.getSelectedTheme();
                    if (sel != null) {
                        selectedTheme = sel;
                        owner.applyTheme(sel);
                        applyDialogTheme(sel, startBtn, themeBtn, symbolBtn);

                        startBtn.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 24));
                        themeBtn.setFont(new Font("Georgia", Font.BOLD, 14));
                        symbolBtn.setFont(new Font("Georgia", Font.BOLD, 14));
                    }
                });

                symbolBtn.addActionListener(e -> {
                    SymbolDialog sd = new SymbolDialog(owner, owner.playerSymbol);
                    sd.setVisible(true);
                    char sel = sd.getSelectedSymbol();
                    if (sel != '\0') {
                        owner.setPlayerSymbol(sel);
                    }
                });

                startBtn.addActionListener(e -> {
                    owner.setPlayerName(nameField.getText());
                    owner.startGame(iGoFirst.isSelected());
                    dispose();
                });

                applyDialogTheme(currentTheme, startBtn, themeBtn, symbolBtn);

                startBtn.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 24));
                themeBtn.setFont(new Font("Georgia", Font.BOLD, 14));
                symbolBtn.setFont(new Font("Georgia", Font.BOLD, 14));

                setSize(560, 360);
                setLocationRelativeTo(owner);
            }

            String getSelectedTheme() {
                return selectedTheme;
            }

            private void applyDialogTheme(String theme, JButton... buttonsToStyle) {
                JButton[][] btns = new JButton[1][buttonsToStyle.length];
                for (int i = 0; i < buttonsToStyle.length; i++) btns[0][i] = buttonsToStyle[i];
                ThemeManager.applyTheme(getContentPane(), null, btns, theme);
                for (Component c : getContentPane().getComponents()) {
                    if (c instanceof JPanel) {
                        for (Component inner : ((JPanel)c).getComponents()) {
                            if (inner instanceof JTextField) {
                                ((JTextField) inner).setOpaque(true);
                                ((JTextField) inner).setFont(new Font("Georgia", Font.PLAIN, 14));
                            }
                            if (inner instanceof JCheckBox) {
                                ((JCheckBox) inner).setOpaque(true);
                                ((JCheckBox) inner).setFont(new Font("Georgia", Font.PLAIN, 14));
                            }

                        }
                    }
                }
            }
        }

        static class SymbolDialog extends JDialog {
            private char selected = '\0';

            SymbolDialog(Frame owner, char current) {
                super(owner, "Choose Symbol", true);
                setLayout(new BorderLayout(10, 10));

                JPanel options = new JPanel(new GridLayout(0, 1));
                JRadioButton xBtn = new JRadioButton("Play as X");
                JRadioButton oBtn = new JRadioButton("Play as O");
                xBtn.setFont(new Font("Georgia", Font.PLAIN, 14));
                oBtn.setFont(new Font("Georgia", Font.PLAIN, 14));
                ButtonGroup group = new ButtonGroup();
                group.add(xBtn);
                group.add(oBtn);
                if (current == 'O') oBtn.setSelected(true);
                else xBtn.setSelected(true);

                options.add(xBtn);
                options.add(oBtn);

                add(options, BorderLayout.CENTER);

                JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
                JButton ok = new JButton("OK");
                JButton cancel = new JButton("Cancel");
                ok.setFont(new Font("Georgia", Font.ITALIC, 13));
                cancel.setFont(new Font("Georgia", Font.ITALIC, 13));
                buttons.add(ok);
                buttons.add(cancel);
                add(buttons, BorderLayout.SOUTH);

                ok.addActionListener(e -> {
                    selected = xBtn.isSelected() ? 'X' : 'O';
                    dispose();
                });
                cancel.addActionListener(e -> {
                    selected = '\0';
                    dispose();
                });

                setSize(320, 180);
                setLocationRelativeTo(owner);
            }

            char getSelectedSymbol() {
                return selected;
            }
        }

        static class ResultDialog extends JDialog {
            private boolean restart = false;

            ResultDialog(Frame owner, String message, String theme) {
                super(owner, "Result", true);
                setLayout(new BorderLayout(10, 10));
                JLabel msg = new JLabel(message, SwingConstants.CENTER);
                msg.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
                msg.setFont(new Font("Georgia", Font.BOLD, 16));
                add(msg, BorderLayout.CENTER);

                JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER));
                JButton restartBtn = new JButton("Restart");
                JButton quitBtn = new JButton("Quit");
                restartBtn.setFont(new Font("Georgia", Font.BOLD, 16));
                quitBtn.setFont(new Font("Georgia", Font.BOLD, 16));
                buttons.add(restartBtn);
                buttons.add(quitBtn);
                add(buttons, BorderLayout.SOUTH);

                restartBtn.addActionListener(e -> {
                    restart = true;
                    dispose();
                });
                quitBtn.addActionListener(e -> {
                    restart = false;
                    dispose();
                });

                JButton[][] btns = new JButton[1][2];
                btns[0][0] = restartBtn;
                btns[0][1] = quitBtn;
                ThemeManager.applyTheme(getContentPane(), null, btns, theme);

                restartBtn.setFont(new Font("Georgia", Font.BOLD, 16));
                quitBtn.setFont(new Font("Georgia", Font.BOLD, 16));
                msg.setForeground(msg.getForeground());

                setSize(480, 220);
                setLocationRelativeTo(owner);
            }

            boolean isRestart() {
                return restart;
            }
        }

        static class ThemeDialog extends JDialog {
            private String selected = null;

            ThemeDialog(Frame owner, String current) {
                super(owner, "Select Theme", true);
                setLayout(new BorderLayout());
                JPanel options = new JPanel(new GridLayout(3, 2, 8, 8));
                JRadioButton classic = new JRadioButton("Classic");
                JRadioButton dark = new JRadioButton("Dark");
                JRadioButton colorful = new JRadioButton("Colorful");
                JRadioButton neon = new JRadioButton("Neon");
                JRadioButton galaxy = new JRadioButton("Galaxy");
                JRadioButton dessert = new JRadioButton("Dessert");
                classic.setFont(new Font("Georgia", Font.PLAIN, 14));
                dark.setFont(new Font("Georgia", Font.PLAIN, 14));
                colorful.setFont(new Font("Georgia", Font.PLAIN, 14));
                neon.setFont(new Font("Georgia", Font.PLAIN, 14));
                galaxy.setFont(new Font("Georgia", Font.PLAIN, 14));
                dessert.setFont(new Font("Georgia", Font.PLAIN, 14));
                ButtonGroup group = new ButtonGroup();
                group.add(classic);
                group.add(dark);
                group.add(colorful);
                group.add(neon);
                group.add(galaxy);
                group.add(dessert);
                if ("Dark".equals(current)) dark.setSelected(true);
                else if ("Colorful".equals(current)) colorful.setSelected(true);
                else if ("Neon".equals(current)) neon.setSelected(true);
                else if ("Galaxy".equals(current)) galaxy.setSelected(true);
                else if ("Dessert".equals(current)) dessert.setSelected(true);
                else classic.setSelected(true);

                options.add(classic);
                options.add(dark);
                options.add(colorful);
                options.add(neon);
                options.add(galaxy);
                options.add(dessert);

                add(options, BorderLayout.CENTER);

                JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
                JButton ok = new JButton("OK");
                JButton cancel = new JButton("Cancel");
                ok.setFont(new Font("Georgia", Font.ITALIC, 13));
                cancel.setFont(new Font("Georgia", Font.ITALIC, 13));
                buttons.add(ok);
                buttons.add(cancel);
                add(buttons, BorderLayout.SOUTH);

                ok.addActionListener(e -> {
                    if (classic.isSelected()) selected = "Classic";
                    else if (dark.isSelected()) selected = "Dark";
                    else if (colorful.isSelected()) selected = "Colorful";
                    else if (neon.isSelected()) selected = "Neon";
                    else if (galaxy.isSelected()) selected = "Galaxy";
                    else if (dessert.isSelected()) selected = "Dessert";
                     dispose();
                });
                cancel.addActionListener(e -> {
                    selected = null;
                    dispose();
                });

                setSize(400, 220);
                setLocationRelativeTo(owner);
            }

            String getSelectedTheme() {
                return selected;
            }
        }
    }
}
